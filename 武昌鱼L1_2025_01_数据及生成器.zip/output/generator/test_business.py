"""Conservation and relationship tests for the reproducible business generator."""
import importlib.util
import unittest
from pathlib import Path


class BusinessTests(unittest.TestCase):
    def module(self):
        path = Path(__file__).with_name('business.py')
        self.assertTrue(path.exists(), 'business generator must be implemented')
        spec = importlib.util.spec_from_file_location('business', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_sample_has_closed_business_chain_and_verifiable_balances(self):
        m = self.module()
        tables = m.generate({'seed': 20251031, 'year': 2025, 'mode': 'sample'})
        self.assertEqual(len(tables['farms']), 1)
        self.assertEqual(len(tables['ponds']), 6)
        self.assertEqual(len([r for r in tables['cohorts'] if not r.get('parent_cohort_id')]), 12)
        failures = [r for r in m.validate_business(tables) if not r['passed']]
        self.assertEqual(failures, [])
        self.assertTrue(any(r['loss_count'] > 0 for r in tables['transfer_events']))
        self.assertTrue(any(r['movement_type'] == 'loss' for r in tables['inventory_movements']))
        self.assertTrue(all(r['outstanding_amount_cny'] == 0 for r in tables['settlements']))
        self.assertTrue(any(r['closing_quantity'] > 0 for r in tables['inventory_movements']))
        sale_harvests = {}
        harvest_sales = {}
        for r in tables['harvest_sale_allocations']:
            sale_harvests.setdefault(r['sale_id'], set()).add(r['harvest_id'])
            harvest_sales.setdefault(r['harvest_id'], set()).add(r['sale_id'])
        self.assertTrue(any(len(v) > 1 for v in sale_harvests.values()))
        self.assertTrue(any(len(v) > 1 for v in harvest_sales.values()))
        tx_settlements, settlement_txs = {}, {}
        for r in tables['cash_allocations']:
            if r.get('settlement_id'):
                tx_settlements.setdefault(r['cash_transaction_id'], set()).add(r['settlement_id'])
                settlement_txs.setdefault(r['settlement_id'], set()).add(r['cash_transaction_id'])
        self.assertTrue(any(len(v) > 1 for v in tx_settlements.values()))
        self.assertTrue(any(len(v) > 1 for v in settlement_txs.values()))

    def test_full_scale_and_determinism(self):
        m = self.module()
        cfg = {'seed': 20251031, 'year': 2025, 'mode': 'full'}
        tables = m.generate(cfg)
        self.assertGreaterEqual(len(tables['feeding_events']), 3000)
        self.assertLessEqual(len(tables['feeding_events']), 6000)
        self.assertEqual(tables, m.generate(cfg))
        self.assertEqual([r for r in m.validate_business(tables) if not r['passed']], [])

    def test_validator_catches_broken_fish_inventory_and_cash(self):
        m = self.module()
        tables = m.generate({'seed': 20251031, 'year': 2025, 'mode': 'sample'})
        tables['fish_daily_balance'][0]['closing_count'] += 1
        tables['inventory_movements'][0]['closing_quantity'] += 1
        tables['cash_allocations'][0]['amount_cny'] += 1
        failures = {r['check_id'] for r in m.validate_business(tables) if not r['passed']}
        self.assertIn('fish_count_conservation', failures)
        self.assertIn('inventory_conservation', failures)
        self.assertIn('cash_allocation_conservation', failures)

    def test_validator_detects_wrong_grade_and_expired_feed_despite_balanced_totals(self):
        m = self.module()
        tables = m.generate({'seed': 20251031, 'year': 2025, 'mode': 'sample'})
        tables['harvest_sale_allocations'][0]['grade'] = 'B'
        tables['feeding_events'][0]['expires_on'] = '2024-01-01'
        failures = {r['check_id'] for r in m.validate_business(tables) if not r['passed']}
        self.assertIn('harvest_grade_allocation_consistency', failures)
        self.assertIn('feed_batch_validity', failures)

    def test_sample_final_harvest_matches_terminal_daily_balance(self):
        m = self.module()
        tables = m.generate({'seed': 20251031, 'year': 2025, 'mode': 'sample'})
        last = {r['cohort_id']: r for r in tables['fish_daily_balance']}
        for h in tables['harvests']:
            if h['harvest_type'] == 'final':
                self.assertEqual(h['count'], last[h['cohort_id']]['harvest_count'])
                self.assertEqual(h['net_weight_kg'], last[h['cohort_id']]['harvest_weight_kg'])

    def test_low_oxygen_suspends_dawn_feed_and_reduces_daily_growth(self):
        m = self.module()
        tables = m.generate({'seed': 20251031, 'year': 2025, 'mode': 'full'})
        low = [r for r in tables['feeding_events'] if r['pond_id']=='P01' and r['occurred_at'][:10]=='2025-07-16']
        self.assertEqual(len(low), 1)
        self.assertGreaterEqual(low[0]['occurred_at'][11:16], '12:00')
        self.assertIn('low_oxygen', low[0]['adjustment_reason'])
        balances = {r['balance_date']:r for r in tables['fish_daily_balance'] if r['cohort_id']=='C01'}
        self.assertLess(balances['2025-07-16']['growth_weight_kg'], balances['2025-07-15']['growth_weight_kg']/2)

    def test_lot_status_separates_expired_feed_and_live_seed_has_no_shelf_life(self):
        m = self.module()
        tables = m.generate({'seed': 20251031, 'year': 2025, 'mode': 'sample'})
        self.assertTrue('inventory_lot_status' in tables, 'inventory lot statuses must be generated')
        self.assertTrue(any(r['usability_status']=='expired_pending_disposal' and r['closing_quantity']>0 for r in tables['inventory_lot_status']))
        for item in tables['purchase_items']:
            if item['product_id'] in ('PR03','PR04'):
                self.assertIsNone(item['manufacture_on'])
                self.assertIsNone(item['expires_on'])
                self.assertEqual(item['expiry_status'],'not_applicable_live_seed')

    def test_transfer_and_harvest_details_follow_physical_events(self):
        m = self.module()
        tables = m.generate({'seed': 20251031, 'year': 2025, 'mode': 'sample'})
        transfers={r['id']:r for r in tables['transfer_events']}
        harvests={r['id']:r for r in tables['harvests']}
        for r in tables['transfer_allocations']:
            self.assertGreaterEqual(r['occurred_at'],transfers[r['transfer_event_id']]['occurred_at'])
        for r in tables['disposal_events']:
            if r.get('transfer_event_id'):
                self.assertGreaterEqual(r['occurred_at'],transfers[r['transfer_event_id']]['occurred_at'])
        for r in tables['harvest_grade_items']:
            self.assertGreaterEqual(r['occurred_at'],harvests[r['harvest_id']]['occurred_at'])


if __name__ == '__main__':
    unittest.main()
