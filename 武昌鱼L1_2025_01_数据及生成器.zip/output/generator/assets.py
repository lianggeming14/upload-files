"""Reproducible GIS, media and document fixtures; never real diagnostic evidence.

Dependencies: numpy, Pillow, tifffile, reportlab, pypdf, imageio,
imageio-ffmpeg and PyMuPDF (PDF render verification).
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import subprocess
import wave
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

DISCLAIMER = '合成格式测试示例；非实景、非真实病害标签；不可用于诊断、诊断模型训练、生产用药或导航。'
DISCLAIMER_EN = 'SYNTHETIC FORMAT TEST - NOT FIELD EVIDENCE - NO DIAGNOSTIC LABELS'
RULE_VERSION = 'assets-1.0.0'


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _font(size=20):
    candidates = ['C:/Windows/Fonts/msyh.ttc', 'C:/Windows/Fonts/simsun.ttc',
                  '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']
    for item in candidates:
        if Path(item).exists():
            return ImageFont.truetype(item, size=size)
    return ImageFont.load_default()


def _pdf_font():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    name = 'FixtureCJK'
    if name not in pdfmetrics.getRegisteredFontNames():
        candidate = Path('C:/Windows/Fonts/simsun.ttc')
        if candidate.exists():
            pdfmetrics.registerFont(TTFont(name, str(candidate), subfontIndex=0))
        else:
            pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
            name = 'STSong-Light'
    return name


def _write_audio(path, script, index, backend='auto'):
    """Use installed Windows TTS when available; explicitly label tone fallback."""
    if os.name == 'nt' and backend != 'tone':
        command = '''$ErrorActionPreference='Stop'; Add-Type -AssemblyName System.Speech;
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer;
try {
  $voice = $synth.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.Name -eq 'zh-CN' } | Select-Object -First 1;
  if (-not $voice) { throw 'No zh-CN voice installed' };
  $synth.SelectVoice($voice.VoiceInfo.Name); $synth.Rate=0; $synth.Volume=90;
  $format = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono);
  $synth.SetOutputToWaveFile($env:ASSET_TTS_OUTPUT,$format);
  $synth.Speak($env:ASSET_TTS_SCRIPT);
  $synth.SetOutputToNull();
  Write-Output $voice.VoiceInfo.Name;
} finally { $synth.Dispose() }
'''
        env = os.environ.copy()
        env.update(ASSET_TTS_OUTPUT=str(path.resolve()), ASSET_TTS_SCRIPT=script)
        try:
            speech = subprocess.run(['powershell','-NoProfile','-NonInteractive','-Command',command],
                                    env=env,capture_output=True,timeout=60,check=True)
            voice = speech.stdout.decode('utf-8',errors='replace').strip()
            with wave.open(str(path),'rb') as handle:
                duration = handle.getnframes()/handle.getframerate()
            return {'audio_kind':'machine_synthesized_speech_not_field_recording',
                    'voice_name':voice,'tts_backend':'Windows System.Speech',
                    'transcription_method':'mock_transcription_from_script','duration_seconds':round(duration,6)}
        except (subprocess.SubprocessError,OSError,wave.Error):
            if backend == 'windows_speech_required':
                raise
    hz,duration=16000,2
    t=np.arange(hz*duration)/hz
    signal=(np.sin(2*np.pi*(330+index*55)*t)*.15*np.minimum(1,t*10)*np.minimum(1,(2-t)*10)*32767).astype('<i2')
    with wave.open(str(path),'wb') as handle:
        handle.setnchannels(1); handle.setsampwidth(2); handle.setframerate(hz); handle.writeframes(signal.tobytes())
    return {'audio_kind':'tone_not_speech','voice_name':None,'tts_backend':'none_tone_fallback',
            'transcription_method':'not_transcribed_authored_fixture','duration_seconds':2.0}


def _write_pdf(path, title, sections, identifier, version='1.0'):
    from reportlab.pdfgen import canvas
    from reportlab.lib.colors import HexColor
    font = _pdf_font()
    pdf = canvas.Canvas(str(path), pagesize=(595.28, 841.89), invariant=1,
                        pageCompression=1)
    pdf.setTitle(title)
    pdf.setAuthor('F01 fictional data fixture generator')
    pdf.setSubject(DISCLAIMER)
    page = 0
    y = 0

    def new_page():
        nonlocal page, y
        if page:
            pdf.showPage()
        page += 1
        pdf.setFillColor(HexColor('#14344c'))
        pdf.rect(0, 782, 596, 60, fill=1, stroke=0)
        pdf.setFillColor(HexColor('#ffffff'))
        pdf.setFont(font, 18)
        pdf.drawString(42, 807, title)
        pdf.setFont('Helvetica', 8)
        pdf.drawString(42, 790, f'{identifier}  |  v{version}  |  SYNTHETIC FIXTURE')
        pdf.saveState()
        pdf.setFillColor(HexColor('#eeeeee'))
        pdf.translate(96, 280)
        pdf.rotate(38)
        pdf.setFont('Helvetica-Bold', 40)
        pdf.drawString(0, 0, 'SYNTHETIC / NOT VALID')
        pdf.restoreState()
        pdf.setFillColor(HexColor('#a33c29'))
        pdf.setFont(font, 8)
        pdf.drawString(42, 53, DISCLAIMER)
        pdf.setFont('Helvetica', 8)
        pdf.drawString(42, 36, f'{identifier} | page {page} | Generated rule {RULE_VERSION}')
        y = 746

    new_page()
    for heading, body in sections:
        if y < 155:
            new_page()
        pdf.setFont(font, 12)
        pdf.setFillColor(HexColor('#155967'))
        pdf.drawString(42, y, heading)
        y -= 25
        pdf.setFont(font, 10.5)
        pdf.setFillColor(HexColor('#253540'))
        # Character-by-character measuring handles CJK without unsupported markup.
        for paragraph in body.split('\n'):
            line = ''
            for char in paragraph:
                if pdf.stringWidth(line + char, font, 10.5) > 510:
                    if y < 95:
                        new_page()
                        pdf.setFont(font, 10.5)
                        pdf.setFillColor(HexColor('#253540'))
                    pdf.drawString(42, y, line)
                    y -= 18
                    line = char
                else:
                    line += char
            if line:
                if y < 95:
                    new_page()
                    pdf.setFont(font, 10.5)
                    pdf.setFillColor(HexColor('#253540'))
                pdf.drawString(42, y, line)
                y -= 18
            y -= 7
        y -= 8
    pdf.save()


def _picture(theme, number, seed, frame=0, size=(640, 384)):
    rng = np.random.default_rng(seed + number * 997)
    im = Image.new('RGB', size, '#eef4f4')
    d = ImageDraw.Draw(im)
    d.rectangle((0, 0, size[0], 65), fill='#173e52')
    d.text((18, 12), '合成格式测试 / SYNTHETIC', font=_font(21), fill='white')
    d.text((18, 43), f'{theme} | fixture {number:03d} | frame {frame:02d}', font=_font(12), fill='#c9e2e6')
    w, h = size
    if theme in {'microscopy', 'histology'}:
        d.ellipse((150, 78, 490, 332), fill='#e5e5f0', outline='#74899b', width=3)
        for _ in range(26):
            x, y = int(rng.integers(195, 445)), int(rng.integers(110, 300))
            if ((x-320)/150)**2 + ((y-205)/108)**2 < 1:
                rx, ry = (9, 15) if theme == 'histology' else (5, 5)
                d.ellipse((x-rx, y-ry, x+rx, y+ry), fill=('#c59ab7' if theme == 'histology' else '#989fc4'), outline='#615c86')
        d.text((25, 285), 'Geometric marks only', font=_font(13), fill='#304957')
        d.text((25, 305), 'No pathogen or lesion label', font=_font(13), fill='#304957')
    elif theme in {'curve', 'production_chart'}:
        d.line((65, 95, 65, 310, 600, 310), fill='#405965', width=2)
        points = [(65+i*10, int(210-55*math.sin(i/7+number/3)-20*math.cos(i/3))) for i in range(53)]
        d.line(points, fill='#168b8a', width=3)
        d.text((75, 87), 'Illustrative index (no measured units)', font=_font(14), fill='#304957')
        for i in range(5):
            d.text((70+i*120, 315), f'{i*6:02d}:00', font=_font(12), fill='#304957')
    elif theme == 'water_test_strip':
        d.rounded_rectangle((85,160,555,245),radius=8,fill='#ffffff',outline='#95a8ac',width=2)
        for i,color in enumerate(['#dfc38f','#c0c787','#90b3a8','#9a9ec0','#bb99b3']):
            d.rectangle((105+i*85,180,155+i*85,225),fill=color,outline='#647e87')
        d.text((60,285),'Illustrative color patches - no test or concentration result',font=_font(13),fill='#304957')
    elif theme == 'drone':
        for row in range(2):
            for col in range(3):
                x, y = 55+col*190, 90+row*120
                d.rectangle((x, y, x+155, y+90), fill=('#6ab1bd' if (row+col+frame)%2 else '#7cc1bf'), outline='#d4b478', width=7)
                d.text((x+45, y+30), f'P{row*3+col+1:02d}', font=_font(19), fill='#173e52')
    elif theme in {'pond_preparation','seed_arrival','seed_unpacking','seed_stocking','growth_sample','mortality_disposal','fish_transfer','harvest','sorting','weighing','loading'}:
        labels = {'pond_preparation':['drain','dry','repair','refill'],
                  'seed_arrival':['transport','arrive','check','register'],
                  'seed_unpacking':['container','open','count','sample'],
                  'seed_stocking':['check','acclimate','release','record'],
                  'growth_sample':['sample','length','weight','estimate'],
                  'mortality_disposal':['discover','collect','contain','dispose'],
                  'fish_transfer':['source','count','move','destination'],
                  'harvest':['net','collect','grade','dispatch'],
                  'sorting':['mixed','small','medium','large'],
                  'weighing':['gross','tare','net','record'],
                  'loading':['container','load','secure','dispatch']}[theme]
        for i,label in enumerate(labels):
            x=30+i*153
            d.rounded_rectangle((x,125,x+125,270),radius=12,fill='#d5e7e8',outline='#74959f',width=2)
            d.text((x+12,145),f'{i+1:02d}',font=_font(30),fill='#157577')
            d.text((x+10,215),label,font=_font(15),fill='#203f4f')
            if i<3:
                d.polygon([(x+131,180),(x+144,189),(x+131,198)],fill='#be8758')
        d.text((28,300),'Process diagram only - no actual operation photographed',font=_font(13),fill='#304957')
    elif theme in {'gill', 'viscera'}:
        d.ellipse((150, 115, 490, 290), fill='#c5d5d7', outline='#4c7183', width=3)
        if theme == 'gill':
            for i in range(7):
                x = 245+i*16
                d.arc((x, 143, x+40, 265), 80, 280, fill='#b97f83', width=5)
        else:
            for i, color in enumerate(['#d3a093', '#cca985', '#b6ac94']):
                d.ellipse((220+i*48, 170, 285+i*48, 230), fill=color, outline='#796c65')
        d.text((25, 305), 'Anatomy-inspired geometry; no lesion or diagnosis', font=_font(13), fill='#304957')
    else:
        d.rectangle((20, 84, 620, 330), fill='#b1d8df')
        for i in range(6):
            cx = 90+(i*83+frame*9+number*7)%440
            cy = 130+(i*31+number*11)%155
            if theme == 'surfacing':
                cy = 112+(i%3)*12
            d.ellipse((cx-30, cy-13, cx+30, cy+13), fill='#7799a4', outline='#3d697c', width=2)
            d.polygon([(cx-27, cy), (cx-43, cy-17), (cx-43, cy+17)], fill='#7196a5')
            d.ellipse((cx+17, cy-6, cx+21, cy-2), fill='#183642')
            if theme == 'feeding':
                d.ellipse((cx, 100+(i%3)*5, cx+4, 104+(i%3)*5), fill='#9e7d47')
        if theme == 'water_color':
            d.rectangle((235, 125, 405, 275), fill=(50+number%25, 135+number%45, 100+number%35), outline='white', width=6)
    d.rectangle((0, h-35, w, h), fill='#fff0dc')
    d.text((12, h-28), '非实景 · 无真实病害标签 · 不用于诊断训练', font=_font(17), fill='#974425')
    return im


DOC_TOPICS = [
    ('塘口主数据登记规范', 'synthetic_enterprise_spec', '塘面积与几何边界', '登记面积、单位、测绘方法和几何来源；估计面积不得表示为现场实测。相同塘号跨版本保持身份，边界变化以新版本记录。', 'pond_id、area_mu、boundary_version、survey_method、precision_m'),
    ('苗种入场记录规范', 'synthetic_enterprise_spec', '苗种身份与投放', '原始商品名、物种、品系、产地和品牌分列。团头鲂学名仅用于物种识别，不因此取得地理标志资格。数量和总重应由各自记录口径解释。', 'species_name、scientific_name、origin_place、strain、gi_status'),
    ('投喂事件登记规范', 'synthetic_enterprise_spec', '饲料批次与事件', '投喂表头与投入品明细分别存储。每日累计量由事件汇总，采购未使用的数量留在库存。摄食强度仅是合成情境分类。', 'feeding_event_id、product_lot_id、quantity_kg、daily_total_kg'),
    ('水质测量对象登记规范', 'synthetic_enterprise_spec', '检测对象与单位', '总氨氮、非离子氨、亚硝酸盐和亚硝酸盐氮须保留各自测定对象。字段相似不授权合并；检出限及低于检出限标记分列。', 'analyte、basis、unit、method_id、detection_limit、below_detection_limit'),
    ('设备校准记录规范', 'synthetic_enterprise_spec', '原值与校正值', '传感器部署有起止时间，校准是单独事件。原值不覆盖，校正值记录公式版本。设备故障与真实环境异常分开。', 'device_id、deployment_id、calibration_id、raw_value、corrected_value'),
    ('巡塘语音与转写规范', 'synthetic_enterprise_spec', '声音与文字关系', 'WAV优先由系统中文语音引擎合成；若没有引擎则为明确标注的测试音调。文字由独立脚本生成，不是语音识别结果。专家旁白为虚构角色，不含真实专家身份。两个文件用pair_id建立格式关系。', 'audio_kind、pair_id、transcription_method、speaker_identity_status'),
    ('生长抽样估算规范', 'synthetic_enterprise_spec', '样本与总体', '抽样个体明细可以汇总均重和标准差，存塘生物量属于估算。体长与全长分别登记，不能把抽样尾数作存塘尾数。', 'sample_id、fish_no、body_length_cm、total_length_cm、weight_g、estimate_error_pct'),
    ('健康观察与送检规范', 'synthetic_enterprise_spec', '观察与诊断分离', '可疑行为不等于确诊。此包图像是几何示意，未包含真实病原图像或确诊标签；检测报告只能验证文件格式和关联链路。', 'case_id、observation_text、diagnosis_status、laboratory_report_id'),
    ('用药资料审核占位规范', 'synthetic_pending_review', '适用版本与待核状态', '未获得具体产品批准资料、适用对象和版本依据时，用量、疗程、休药期及预计可出塘日期保持待核。本文不是处方，不提供治疗建议。', 'product_version、approval_status、target_species_status、withdrawal_days_status'),
    ('转塘数量记录规范', 'synthetic_enterprise_spec', '同一事件两端', '转出、转入与损耗以同一转塘事件连接。父子鱼群关系不意味着复制鱼尾数，转入净数量应扣除明确登记的损耗。', 'transfer_event_id、source_cohort_id、destination_cohort_id、loss_count'),
    ('捕捞规格记录规范', 'synthetic_enterprise_spec', '毛净重和分级', '毛重、扣重、运输损耗和可售净重分列。一个捕捞批次可以分售；同一销售单可以承接多个捕捞批次，需有分配明细。', 'harvest_id、grade、gross_weight_kg、net_weight_kg、allocation_kg'),
    ('销售回款登记规范', 'synthetic_enterprise_spec', '结算和核销', '成交额、结算净额及已收款不是同一字段。分期回款通过核销关联结算单，销售扣费若已扣净额不得重复进入成本。', 'settlement_id、net_amount_cny、receipt_id、allocated_amount_cny'),
    ('期初库存计价规范', 'synthetic_enterprise_spec', '采购与耗用区分', '期初数量及金额单独记录，采购入库、领用、退库及报损各为独立流向。使用成本按声明的计价规则进入经营核算。', 'opening_quantity、movement_type、unit_cost_cny、closing_quantity'),
    ('共同费用分摊规范', 'synthetic_enterprise_spec', '归属期与分摊基数', '每笔共同费用保存期间及分摊方法，金额在受益塘口之间守恒。直接费用不再进行重复共同分摊。本文是合成核算案例。', 'cost_id、period_start、period_end、allocation_basis、allocation_ratio'),
    ('空间图层交付规范', 'synthetic_enterprise_spec', '坐标与版本', 'GeoJSON使用经纬度顺序和WGS84，所有坐标为虚构布局。GeoTIFF保存像素分辨率及地理标记；不能用于地籍、现场定位和路线导航。', 'crs、bbox、resolution_m、accuracy_m、capture_at、version'),
    ('虚构饲料产品说明样例', 'synthetic_product_sheet', '未上市虚构产品', '产品编号仅用于库存与投喂接口测试，不对应真实品牌。营养、保质期、适口性等字段若无生产资料则记录假设或待核，不构成推荐。', 'product_id、lot_id、protein_pct_status、shelf_life_status、label_version'),
    ('虚构传感器产品说明样例', 'synthetic_product_sheet', '接口量程格式', '本说明仅描述接口字段：通道编号、原始单位、时间戳和校准版本。示例量程不是设备性能承诺，实验室校准和现场部署需要独立核验。', 'channel_id、unit、resolution_status、calibration_protocol、firmware_version'),
    ('季节性水质研究示例', 'synthetic_research_note', '假设曲线与观测区分', '使用确定性季节项和日周期项构造可重复曲线，仅检验时序清洗和关联查询。模型未对真实武昌鱼池塘拟合，不能报告为实证结论。', 'simulation_seed、seasonal_term、daily_term、noise_term、parameter_basis'),
    ('气象网格对齐研究示例', 'synthetic_research_note', '再分析与现场天气', '公开样例的请求点和返回网格是两种位置。空气温度不是水温；设计材料的2026获取时间与2025模拟窗口分别保留，不能回填成现场观测。', 'requested_latitude、grid_latitude、weather_model、source_year、scenario_year'),
    ('市场价格路径研究示例', 'synthetic_research_note', '报价与假设路径', '只取得单日公开报价时，全年合成路径必须标为假设。原始商品名“鳊鱼”不自动映射团头鲂。市场报价和农场成交分开建表。', 'raw_species_name、mapping_status、quote_or_transaction、price_basis、path_assumption'),
]


def _pick(tables, preferences, index=0, pond_id=None):
    for table in preferences:
        if table not in tables:
            table = {'patrols':'patrol_events','parties':'partners','pond_preparation':'pond_preparations'}.get(table,table)
        rows = tables.get(table, [])
        if pond_id:
            matching = [r for r in rows if r.get('pond_id') == pond_id or (table == 'ponds' and r.get('id') == pond_id)]
            if matching:
                rows = matching
        if rows:
            return table, rows[index % len(rows)]
    return None, None


def generate_assets(out_dir: Path, cfg: dict, tables: dict) -> dict[str, list[dict]]:
    """Create independent files and manifests using only existing entity IDs."""
    out_dir = Path(out_dir)
    seed, year = int(cfg.get('seed', 20251031)), int(cfg.get('year', 2025))
    full = cfg.get('mode', 'full') == 'full'
    result = {k: [] for k in ('attachments', 'attachment_links', 'media_annotations', 'documents', 'document_versions', 'spatial_layer_registry')}
    for folder in ('gis', 'images', 'video', 'audio', 'transcripts', 'pdf', 'documents'):
        (out_dir / 'assets' / folder).mkdir(parents=True, exist_ok=True)
    farm_id = tables.get('farms', [{}])[0].get('id')
    pond_rows = tables.get('ponds', [])
    pond_ids = [r['id'] for r in pond_rows]
    base_time = f'{year}-06-15T08:00:00+08:00'
    run_id = cfg.get('generation_run_id', f'L1-{year}-{seed}-{cfg.get("mode", "full")}')

    def add(path, category, index, preferences=('ponds', 'farms'), pond_id=None, extra=None, annotation=True):
        relative = path.relative_to(out_dir).as_posix()
        ident = f'ATT{len(result["attachments"])+1:04d}'
        entity_table, entity = _pick(tables, preferences, index, pond_id)
        entity = entity or {}
        actual_pond = entity.get('pond_id') or (entity.get('id') if entity_table == 'ponds' else pond_id)
        if actual_pond not in pond_ids:
            actual_pond = None
        timestamp = next((entity[k] for k in ('occurred_at', 'observed_at', 'event_time', 'sampled_at', 'date', 'harvest_date', 'sale_date') if entity.get(k)), base_time)
        if len(str(timestamp)) == 10:
            timestamp = str(timestamp) + 'T08:00:00+08:00'
        suffix = path.suffix.lower()
        mime = {'.png': 'image/png', '.jpg': 'image/jpeg', '.tif': 'image/tiff', '.geojson': 'application/geo+json', '.pdf': 'application/pdf', '.mp4': 'video/mp4', '.wav': 'audio/wav', '.txt': 'text/plain'}[suffix]
        row = dict(id=ident, farm_id=farm_id, pond_id=actual_pond, cohort_id=entity.get('cohort_id'),
                   category=category, relative_path=relative, file_name=path.name, mime_type=mime,
                   file_size_bytes=path.stat().st_size, sha256=_sha(path), captured_at=timestamp,
                   recorded_at=timestamp, capture_device='deterministic_programmatic_fixture_generator',
                   language='zh-CN/en', license_status='original_synthetic_fixture_redistributable',
                   review_status='format_checked_only', origin_kind='synthetic_format_fixture', is_synthetic=True,
                   clinical_label_status='no_real_disease_labels', intended_use='format_linkage_tests_only',
                   usage_limitation=DISCLAIMER, generation_run_id=run_id, seed=seed,
                   rule_version=RULE_VERSION, scenario_id='F01_2025_closed_cycle',
                   width_px=None, height_px=None, duration_seconds=None, codec=None,
                   sample_rate_hz=None, channels=None, audio_kind=None, pair_id=None,
                   voice_name=None,tts_backend=None,transcription_method=None,speaker_identity_status=None)
        if extra:
            row.update(extra)
        result['attachments'].append(row)
        if entity_table:
            result['attachment_links'].append(dict(id=f'AL{len(result["attachment_links"])+1:04d}',
                attachment_id=ident, entity_table=entity_table, entity_id=entity['id'],
                relation_type='synthetic_format_example_for', evidence_status='not_field_evidence'))
        if annotation:
            result['media_annotations'].append(dict(id=f'MA{len(result["media_annotations"])+1:04d}',
                attachment_id=ident, annotation_type='fixture_scope', label=category,
                annotation_text=DISCLAIMER, annotation_basis='programmatically_drawn_or_generated',
                diagnosis_status='not_applicable_synthetic_format_test', diagnostic_training_allowed=False,
                reviewer='synthetic_data_generator', review_status='format_checked_only',
                version='1.0', frame_start=0 if suffix == '.mp4' else None,
                frame_end=11 if suffix == '.mp4' else None))
        return ident

    # Flat fictional layout: rectangle sizes derive from master-data area, not an independent size assumption.
    origins, rings, area_values = {}, {}, {}
    lat_scale = 111320.0
    lon_scale = lat_scale * math.cos(math.radians(30.10))
    for i, pond in enumerate(pond_rows):
        area = float(pond.get('area_m2') or float(pond.get('area_mu', 15)) * (2000/3))
        if pond.get('area_ha') and not pond.get('area_m2') and not pond.get('area_mu'):
            area = float(pond['area_ha']) * 10000
        cx = float(pond.get('longitude') or pond.get('center_longitude') or pond.get('centroid_longitude') or 114.6800+(i%3)*0.004)
        cy = float(pond.get('latitude') or pond.get('center_latitude') or pond.get('centroid_latitude') or 30.1000+(i//3)*0.004)
        dx, dy = math.sqrt(area*1.5)/lon_scale/2, math.sqrt(area/1.5)/lat_scale/2
        origins[pond['id']] = (cx, cy)
        rings[pond['id']] = [[cx-dx, cy-dy], [cx+dx, cy-dy], [cx+dx, cy+dy], [cx-dx, cy+dy], [cx-dx, cy-dy]]
        area_values[pond['id']] = area

    def feature(fid, geometry, table=None, entity_id=None, **properties):
        return dict(type='Feature', id=fid, geometry=geometry, properties=dict(
            id=fid, entity_table=table, entity_id=entity_id, is_synthetic=True,
            origin_kind='synthetic_layout', not_for_navigation=True, **properties))

    def polygon(box):
        x1, y1, x2, y2 = box
        return {'type': 'Polygon', 'coordinates': [[[x1,y1],[x2,y1],[x2,y2],[x1,y2],[x1,y1]]]}

    def spatial(name, features, kind, captured=base_time):
        path = out_dir/'assets'/'gis'/f'{name}.geojson'
        obj = dict(type='FeatureCollection', name=name, features=features, metadata=dict(
            crs='EPSG:4326', coordinate_order='longitude,latitude', source='synthetic_layout',
            captured_at=captured, version='1.0', accuracy_m=None,
            accuracy_status='not_surveyed_synthetic_layout', usage_limitation=DISCLAIMER))
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True)+'\n', encoding='utf-8')
        att = add(path, kind, 0, ('farms', 'ponds'), annotation=False)
        def flatten_coordinates(coords):
            if isinstance(coords[0],(int,float)):
                return [coords]
            return [point for nested in coords for point in flatten_coordinates(nested)]
        coordinates = [point for f in features for point in flatten_coordinates(f['geometry']['coordinates'])]
        bbox = ','.join(str(round(v,8)) for v in (min(p[0] for p in coordinates),min(p[1] for p in coordinates),max(p[0] for p in coordinates),max(p[1] for p in coordinates))) if coordinates else None
        result['spatial_layer_registry'].append(dict(id=f'SL{len(result["spatial_layer_registry"])+1:03d}',
            attachment_id=att, layer_name=name, geometry_kind=kind, crs='EPSG:4326',
            coordinate_order='longitude,latitude', captured_at=captured, version='1.0',
            resolution_m=None, resolution_degrees=None, accuracy_m=None,
            accuracy_status='not_surveyed_synthetic_layout', scale_status='not_applicable_vector',
            source='synthetic_layout', feature_count=len(features),
            bbox=bbox, coverage='F01 fictional farm and surroundings',
            relative_path=path.relative_to(out_dir).as_posix(), sha256=_sha(path),
            is_synthetic=True, usage_limitation=DISCLAIMER))

    pond_geometry_ids = {r['id']:r.get('geometry_id',f'GIS-{r["id"]}') for r in pond_rows}
    spatial('ponds', [feature(pond_geometry_ids[p], {'type': 'Polygon', 'coordinates':[ring]}, 'ponds', p,
                     pond_id=p, area_m2=area_values[p], area_basis='master_data_area_local_metric_rectangle') for p, ring in rings.items()], 'pond_boundary')
    water_states = []
    for p,ring in rings.items():
        cx,cy = origins[p]
        for month,factor,depth in [(6,.98,1.8),(9,.94,1.65)]:
            surface = [[cx+(x-cx)*factor,cy+(y-cy)*factor] for x,y in ring]
            water_states.append(feature(f'{p}_WATER_{month:02d}',{'type':'Polygon','coordinates':[surface]},'ponds',p,pond_id=p,
                captured_at=f'{year}-{month:02d}-15T08:00:00+08:00',pond_area_m2=area_values[p],pond_boundary_change_status='unchanged_no_renovation_between_dates',water_area_m2=round(area_values[p]*factor*factor,3),
                assumed_mean_water_depth_m=depth,water_level_datum='arbitrary_pond_bottom_not_geodetic',
                water_level_m=depth,measurement_kind='synthetic_assumption_not_observed'))
    spatial('water_surface_states',water_states,'time_varying_water_surface')
    spatial('farm_boundary', [feature('FARM_LAYOUT', polygon((114.678,30.098,114.690,30.106)), 'farms', farm_id)], 'farm_boundary')
    spatial('water_network', [feature('RIVER01', {'type':'LineString','coordinates':[[114.675,30.095],[114.675,30.112],[114.695,30.115]]}, water_type='fictional_river'),
                             feature('RES01', polygon((114.692,30.105,114.699,30.109)), water_type='fictional_lake')], 'water_network')
    intake = []
    for p,(cx,cy) in origins.items():
        for offset,label in [(-1,'intake'),(1,'outlet'),(0,'sampling_point')]:
            point_id = f'PT_{p}' if label=='sampling_point' else f'GIS-{p}-{label.upper()}'
            intake.append(feature(point_id, {'type':'Point','coordinates':[cx+offset*.0004,cy]}, 'ponds', p, pond_id=p, point_kind=label))
        intake.append(feature(f'GIS-{p}-FEED',polygon((cx-.00015,cy-.00015,cx+.00015,cy+.00015)),'ponds',p,pond_id=p,point_kind='feeding_area_layout'))
    spatial('intakes_outlets_sampling', intake, 'farm_water_points')
    devices = []
    for i, device in enumerate(tables.get('devices', [])):
        p = device.get('pond_id') or (pond_ids[i%len(pond_ids)] if pond_ids else None)
        cx,cy = origins.get(p,(114.68,30.10))
        devices.append(feature(f'DEVLOC{i+1:03d}', {'type':'Point','coordinates':[cx+(i%3)*.00015,cy]}, 'devices', device['id'], pond_id=p, device_kind=device.get('device_type') or device.get('kind') or 'device'))
    if not devices:
        devices = [feature(f'{p}_DEV_LAYOUT', {'type':'Point','coordinates':[cx,cy+.0001]}, 'ponds', p, point_kind='proposed_device_layout_only') for p,(cx,cy) in origins.items()]
    spatial('devices', devices, 'device_points')
    discoveries = []
    for table in ('health_cases','mortality_events','patrol_events','patrols'):
        for i,row in enumerate(tables.get(table, [])[:6]):
            p = row.get('pond_id')
            if p in origins:
                cx,cy = origins[p]
                discoveries.append(feature(f'{table}_{i}', {'type':'Point','coordinates':[cx,cy+.0001]}, table,row['id'], pond_id=p, diagnosis_status='not_applicable_synthetic_layout'))
    spatial('discovery_points', discoveries, 'discovery_points')
    spatial('land_use', [feature(f'LAND{i+1}',polygon((114.65+i*.015,30.075,114.664+i*.015,30.09)), land_use=k) for i,k in enumerate(('cropland','aquaculture','built_up','wetland'))], 'land_use')
    spatial('administrative_layout', [feature('ADMIN_SYNTHETIC',polygon((114.65,30.07,114.73,30.14)), administrative_name='虚构行政覆盖示意；非真实法定区划', official_code=None)], 'administrative_area')
    spatial('weather_grid', [feature(f'WXGRID{i:02d}',polygon((114.66+(i%3)*.02,30.08+(i//3)*.02,114.68+(i%3)*.02,30.10+(i//3)*.02)), model='synthetic_weather_grid_not_ERA5_observation', grid_resolution_degrees=.02,precipitation_scenario_mm=round(3.5+i*1.2,1),heat_scenario_air_temperature_c=round(33+i*.5,1)) for i in range(6)]+[feature('WXSTATION_LAYOUT',{'type':'Point','coordinates':[114.685,30.11]},station_kind='fictional_layout_not_actual_station',official_station_id=None)], 'weather_grid')
    spatial('risk_zones', [feature('FLOOD_TEST',polygon((114.67,30.095,114.678,30.113)), hazard='synthetic_flood_scenario_not_assessment'), feature('DROUGHT_TEST',polygon((114.693,30.098,114.708,30.112)), hazard='synthetic_drought_scenario_not_assessment'), feature('HEAT_TEST',polygon((114.68,30.098,114.691,30.108)), hazard='synthetic_heat_scenario_not_forecast')], 'hazard_scenarios')
    parties = []
    partner_table = 'partners' if 'partners' in tables else 'parties'
    for i,row in enumerate(tables.get(partner_table, [])):
        parties.append(feature(f'PARTYLOC{i+1:03d}', {'type':'Point','coordinates':[114.66+(i%5)*.012,30.115+(i//5)*.006]}, partner_table,row['id'], party_kind=row.get('partner_type') or row.get('party_type') or row.get('role') or 'fictional_counterparty'))
    if not parties:
        parties = [feature('EXTERNAL_LAYOUT',{'type':'Point','coordinates':[114.71,30.12]}, site_kind='market_layout_only_no_master_party')]
    parties.extend([feature('MARKET_LAYOUT',{'type':'Point','coordinates':[114.711,30.121]},site_kind='wholesale_market_layout_without_business_relationship'),feature('PROCESSING_LAYOUT',{'type':'Point','coordinates':[114.713,30.124]},site_kind='processing_plant_layout_without_business_relationship')])
    spatial('suppliers_customers_labs_markets', parties, 'counterparty_points')
    routes = []
    for i,dest in enumerate(parties):
        end = dest['geometry']['coordinates']
        distance = (abs((end[0]-114.68)*lon_scale)+abs((end[1]-30.10)*lat_scale))/1000
        routes.append(feature(f'ROUTE{i+1:02d}',{'type':'LineString','coordinates':[[114.68,30.10],[114.68,end[1]],end]}, **dict(destination_entity_table=dest['properties'].get('entity_table'),destination_entity_id=dest['properties'].get('entity_id'),distance_km=round(distance,3),duration_minutes=round(distance/30*60,1),distance_basis='fictional_manhattan_route_illustration')))
    spatial('transport_routes',routes,'transport_routes')

    # Real GeoTIFF tags: geographic WGS84, pixel-is-area, tie point and pixel scale.
    import tifffile
    for i,kind in enumerate(['orthomosaic', 'water_surface_june'] + (['water_surface_september'] if full else [])):
        width,height = 256,160
        xres,yres = .012/width,.008/height
        yy,xx = np.mgrid[:height,:width]
        arr = np.zeros((height,width,3),dtype=np.uint8)
        arr[:,:,0] = (95+xx//6+i*11)%255
        arr[:,:,1] = (150+yy//5+i*7)%255
        arr[:,:,2] = (90+(xx+yy)//12)%255
        for j in range(6):
            x,y = 22+(j%3)*78,24+(j//3)*66
            arr[y:y+45,x:x+58] = (65+i*9,140+i*10,174+i*6)
        geo_keys = (1,1,0,3,1024,0,1,2,1025,0,1,1,2048,0,1,4326)
        path = out_dir/'assets'/'gis'/f'{kind}.tif'
        tifffile.imwrite(path,arr,photometric='rgb',metadata=None,description=DISCLAIMER_EN,
            extratags=[(33550,'d',3,(xres,yres,0),False),(33922,'d',6,(0,0,0,114.678,30.106,0),False),(34735,'H',len(geo_keys),geo_keys,False)])
        att = add(path,kind,i,('farms','ponds'),extra={'width_px':width,'height_px':height,'captured_at':f'{year}-{9 if i==2 else 6:02d}-15T08:00:00+08:00'},annotation=False)
        result['spatial_layer_registry'].append(dict(id=f'SL{len(result["spatial_layer_registry"])+1:03d}', attachment_id=att, layer_name=kind,geometry_kind='raster',crs='EPSG:4326',coordinate_order='longitude,latitude',captured_at=f'{year}-{9 if i==2 else 6:02d}-15T08:00:00+08:00',version='1.0',resolution_m=round(xres*lon_scale,4),resolution_degrees=f'{xres},{yres}',accuracy_m=None,accuracy_status='not_surveyed_synthetic_layout',scale_status='synthetic_pixel_size_only',source='programmatic_RGB_grid_not_drone_or_satellite_capture',feature_count=None,bbox='114.678,30.098,114.690,30.106',coverage='F01 fictional farm',relative_path=path.relative_to(out_dir).as_posix(),sha256=_sha(path),is_synthetic=True,usage_limitation=DISCLAIMER))

    themes = ['fish_body','gill','viscera','microscopy','histology','water_color','curve','production_chart',
              'pond_preparation','seed_arrival','seed_unpacking','seed_stocking','growth_sample','mortality_disposal','fish_transfer','harvest','sorting','weighing','loading']
    image_count = 70 if full else 8
    for i in range(image_count+1):
        theme = 'water_test_strip' if i==image_count else themes[i%len(themes)]
        suffix = '.jpg' if i%3 == 1 else '.png'
        path = out_dir/'assets'/'images'/f'{i+1:03d}_{theme}{suffix}'
        im = _picture(theme,i+1,seed)
        im.save(path, quality=90, optimize=False) if suffix == '.jpg' else im.save(path, optimize=False)
        stage_tables = {'pond_preparation':('pond_preparations','ponds'),
                        'fish_body':('feeding_events','growth_samples','ponds'),
                        'water_color':('water_samples','water_observations','ponds'),
                        'water_test_strip':('water_samples','water_test_results','ponds'),
                        'curve':('water_observations','ponds'),
                        'production_chart':('harvests','sales','ponds'),
                        'seed_arrival':('stocking_events','purchases','ponds'),
                        'seed_unpacking':('stocking_events','purchases','ponds'),
                        'seed_stocking':('stocking_events','ponds'),
                        'growth_sample':('growth_samples','ponds'),
                        'mortality_disposal':('disposal_events','mortality_events','ponds'),
                        'fish_transfer':('transfer_events','ponds'),
                        'harvest':('harvests','ponds'),'sorting':('harvests','ponds'),
                        'weighing':('harvests','ponds'),'loading':('harvests','sales','ponds')}
        preferences = stage_tables.get(theme,('health_cases','growth_samples','ponds') if theme in ('gill','viscera','microscopy','histology') else ('patrols','feeding_events','ponds'))
        add(path,theme,i,preferences,extra={'width_px':im.width,'height_px':im.height})

    import imageio.v2 as imageio
    video_themes = ['underwater','feeding','surfacing','surveillance','drone','swimming']
    for i in range(12 if full else 6):
        theme = video_themes[i%6]
        path = out_dir/'assets'/'video'/f'{i+1:03d}_{theme}.mp4'
        with imageio.get_writer(str(path),format='FFMPEG',mode='I',fps=6,codec='libx264',quality=6,macro_block_size=None, ffmpeg_params=['-threads','1','-map_metadata','-1','-fflags','+bitexact','-flags:v','+bitexact']) as writer:
            for frame in range(12):
                writer.append_data(np.asarray(_picture(theme,i+100,seed,frame=frame)))
        video_preferences = ('feeding_events','patrols','ponds') if theme in ('feeding','underwater') else ('health_cases','patrols','ponds') if theme=='swimming' else ('patrols','ponds')
        add(path,theme,i,video_preferences,extra={'width_px':640,'height_px':384,'duration_seconds':2.0,'codec':'H.264'})

    for i in range(6 if full else 2):
        pair = f'PAIR{i+1:02d}'
        role = 'patrol' if i%2 == 0 else 'expert_narration'
        script = (f'这是第{i+1}段机器合成语音，属于格式测试，并非真实现场或真实专家录音。'
                  + ('虚构巡塘员检查记录时间、塘号、设备状态和观察说明。发现异常时登记事件并等待复核。' if role=='patrol' else '虚构专家旁白说明：可疑行为不等于确诊。本包图片为几何示意，不可用于诊断训练，也不是用药建议。'))
        path = out_dir/'assets'/'audio'/f'{pair}_{role}_synthetic.wav'
        audio_meta = _write_audio(path,script,i,cfg.get('tts_backend','auto'))
        audio_meta.update(codec='PCM signed 16 bit',sample_rate_hz=16000,channels=1,pair_id=pair,speaker_identity_status='fictional_role_no_real_person')
        add(path,f'synthetic_{role}_audio',i,('patrols','ponds'),extra=audio_meta)
        text_path = out_dir/'assets'/'transcripts'/f'{pair}_authored_test_script.txt'
        text_path.write_text(f'{DISCLAIMER}\n关联音频：{path.name}\n音频性质：{audio_meta["audio_kind"]}；引擎：{audio_meta["tts_backend"]}。\n转写方法：{audio_meta["transcription_method"]}。以下为独立编写的测试脚本，不是语音识别结果。\n脚本：{script}\n专家身份：虚构角色，无真实专家录音。\n',encoding='utf-8')
        add(text_path,'authored_script_not_asr_transcription',i,('patrols','ponds'),extra={'pair_id':pair,'transcription_method':audio_meta['transcription_method'],'speaker_identity_status':'fictional_role_no_real_person'})

    pdf_types = [('合成检测报告','lab_report',('diagnostic_tests','lab_results','health_cases','ponds')),
                 ('合成合同格式样例','contract',('sales','purchases','farms')),
                 ('合成发票格式样例','invoice',('cost_entries','sales','farms')),
                 ('处方字段占位示例（无效）','prescription_placeholder',('treatment_events','health_cases','ponds'))]
    for i in range(8 if full else 4):
        title,kind,prefs = pdf_types[i%4]
        path = out_dir/'assets'/'pdf'/f'{kind}_{i+1:02d}.pdf'
        table,entity = _pick(tables,prefs,i)
        ref = f'{table}/{entity["id"]}' if entity else '无适用业务实体'
        specific = {'lab_report':'检测方法、检出限和判定结果均为格式占位或待核。没有真实样本、检测机构资质或病原确诊结论。',
                    'contract':'买卖双方均为虚构主体。此页没有法律效力，不是已签署合同；未加盖印章，不包含真实银行卡号。',
                    'invoice':'票号为TEST前缀。此页不是税务发票，税号、金额与税率不作为报销或税务依据。',
                    'prescription_placeholder':'处方无效；未由执业兽医开具。药品、剂量、疗程、适用病害、休药期均为待核，不提供治疗建议。'}[kind]
        _write_pdf(path,title,[('1. 文件身份',f'文件编号 TEST-{kind.upper()}-{i+1:03d}。{DISCLAIMER}'),('2. 关联记录',f'本文件用于测试附件关联：{ref}。关联不意味着存在真实现场证据。'),('3. 主体内容',specific),('4. 审核与来源','作者为模拟数据生成器；审核状态仅为格式检查。无真实签名、无真实印章、无真实确诊标签。应在取得真实授权材料后另建记录，不覆盖此测试原件。')],f'TEST-{kind.upper()}-{i+1:03d}')
        add(path,kind,i,prefs)

    if full:
        path = out_dir/'assets'/'pdf'/'pond_preparation_voucher_01.pdf'
        table,record = _pick(tables,('pond_preparations','ponds'),0)
        reference=f'{table}/{record["id"]}' if record else 'no_applicable_record'
        _write_pdf(path,'合成清塘作业凭证',[
            ('1. 凭证身份',f'仅为清塘作业记录格式测试。{DISCLAIMER}'),
            ('2. 对应事件',f'关联{reference}。此页为规则生成的独立合成凭证，不是现场拍摄、签署或财务报销凭据。'),
            ('3. 作业内容示意','排水、晒塘、清淤、修整、注水及设备检查字段用于接口验证。实际工时、施工人员签名、验收章和真实付款资料均不适用。'),
            ('4. 审核边界','凭证编号 TEST-PREP-001；虚构F01数据工作组仅检查格式与事件链接。未引用未知再分发许可原件。')], 'TEST-PREP-001')
        add(path,'pond_preparation_voucher',0,('pond_preparations','ponds'))

    for i,(title,category,focus,detail,fields) in enumerate(DOC_TOPICS):
        doc_id = f'DOC{i+1:03d}'
        versions = ['1.0','1.1'] if i < (4 if full else 1) else ['1.0']
        latest_path,latest_att = None,None
        for version in versions:
            path = out_dir/'assets'/'documents'/f'{doc_id}_v{version}.pdf'
            sections = [
                ('1. 身份、目的与范围',f'本文件为虚构养殖场F01的数据管理全文样例，主题是“{focus}”。适用地区为湖北池塘场景的结构测试，模拟业务年度为{year}。它不是国家、行业或地方标准，也不是监管文件、真实产品说明或发表论文。{DISCLAIMER}'),
                ('2. 术语与数据原则',detail+'\n所有合成记录保留来源类型、随机种子、规则版本及运行编号。观测、估算、派生和人工假设分列，时间采用Asia/Shanghai并保留原始精度。未知值不能用零代替。'),
                ('3. 字段和处理要求',f'本主题字段示例：{fields}。\n录入时先检查主键，再解析单位和时间，关联不到对象的记录须显式隔离。所有引用字段使用已存在的业务ID；跨表分配保留明细而非文本拼接。'),
                ('4. 可复核测试案例',f'案例编号 {doc_id}-CASE-{version.replace(".","")}。创建一条与“{focus}”有关的合成记录，保存原始值和说明；读取后验证字段、来源与关联。将一个引用ID改为不存在的值时，应由验收器报告关联错误。此案例只证明处理规则，不证明任何现场结论。'),
                ('5. 验收、版本与适用边界',f'全文版本 {version}；发布者为虚构F01数据工作组。审核状态：合成文本，专业参数待核。许可状态：本任务原创合成示例，可随数据包分发。'+('本次修订新增：低于检出限、不适用和未收到材料三类状态须分别编码；历史记录维持原版本关联。' if version=='1.1' else '初始版本定义字段、对象关系和最低文件校验要求。')+'\n真实法规、标准和产品参数须另查对应有效版本。公开原件留存在输入目录；本PDF未复制或改写未知再分发许可的原件全文。'),
            ]
            _write_pdf(path,title,sections,doc_id,version)
            att = add(path,'synthetic_technical_document',i,('farms',),annotation=False)
            latest_path,latest_att = path,att
            result['document_versions'].append(dict(id=f'DV{i+1:03d}-{version}',document_id=doc_id,version=version,
                attachment_id=att,relative_path=path.relative_to(out_dir).as_posix(),sha256=_sha(path),
                published_at=f'{year}-01-01' if version=='1.0' else f'{year}-03-01',
                effective_from=f'{year}-01-01' if version=='1.0' else f'{year}-03-01',
                effective_until=f'{year}-02-28' if len(versions)>1 and version=='1.0' else None,
                status='superseded_synthetic' if version!=versions[-1] else 'current_synthetic',
                replaces_version_id=f'DV{i+1:03d}-1.0' if version=='1.1' else None,
                change_summary='explicit missingness states added' if version=='1.1' else 'initial synthetic full-text fixture',
                review_status='professional_content_pending_verification',page_reference='entire_document',
                origin_kind='synthetic_document',is_synthetic=True))
        result['documents'].append(dict(id=doc_id,title=title,document_type=category,
            publisher='虚构F01数据工作组（非真实发布机构）',language='zh-CN',
            current_version=versions[-1],current_version_id=f'DV{i+1:03d}-{versions[-1]}',
            published_at=f'{year}-01-01',applicable_region='湖北池塘虚构场景',
            applicable_mode='pond_synthetic_data_fixture',full_text_path=latest_path.relative_to(out_dir).as_posix(),
            attachment_id=latest_att,sha256=_sha(latest_path),source_url=None,
            source_status='original_synthetic_not_external_authority',license_status='original_synthetic_fixture_redistributable',
            authority_status='not_official_not_clinical',review_status='professional_content_pending_verification',
            origin_kind='synthetic_document',is_synthetic=True,usage_limitation=DISCLAIMER))
    return result


def validate_assets(out_dir: Path, tables: dict) -> list[dict]:
    """Open/decode every asset and check hashes, metadata and actual relationships."""
    import imageio.v2 as imageio
    import tifffile
    import fitz
    from pypdf import PdfReader
    out_dir = Path(out_dir).resolve()
    errors = {k: [] for k in ('asset_file_hashes','asset_decoders','asset_foreign_keys','asset_metadata','asset_unique_files','asset_document_versions','asset_spatial_references')}
    attachments = tables.get('attachments',[])
    ids = {key:{str(r['id']) for r in rows} for key,rows in tables.items() if isinstance(rows,list)}
    by_attachment = {r['id']:r for r in attachments}
    hashes = set()
    spatial_feature_ids = set()
    for row in attachments:
        rel = row['relative_path']
        path = (out_dir/rel).resolve()
        if not path.is_relative_to(out_dir) or not path.is_file():
            errors['asset_file_hashes'].append(f'{row["id"]}: missing or unsafe path {rel}')
            continue
        digest = _sha(path)
        if digest != row['sha256'] or path.stat().st_size != int(row['file_size_bytes']):
            errors['asset_file_hashes'].append(row['id'])
        if digest in hashes:
            errors['asset_unique_files'].append(row['id'])
        hashes.add(digest)
        if row.get('origin_kind') != 'synthetic_format_fixture' or row.get('clinical_label_status') != 'no_real_disease_labels':
            errors['asset_metadata'].append(f'{row["id"]}: missing synthetic provenance')
        for column,target in [('farm_id','farms'),('pond_id','ponds'),('cohort_id','cohorts')]:
            if row.get(column) and str(row[column]) not in ids.get(target,set()):
                errors['asset_foreign_keys'].append(f'{row["id"]}/{column}')
        try:
            suffix = path.suffix.lower()
            if suffix in ('.png','.jpg'):
                with Image.open(path) as im:
                    im.load()
                    assert im.size == (int(row['width_px']),int(row['height_px']))
            elif suffix == '.tif':
                with tifffile.TiffFile(path) as tif:
                    array = tif.asarray()
                    assert array.shape == (int(row['height_px']),int(row['width_px']),3)
                    assert tif.pages[0].tags[34735].value[-1] == 4326
                    assert 33550 in tif.pages[0].tags and 33922 in tif.pages[0].tags
            elif suffix == '.geojson':
                content = json.loads(path.read_text(encoding='utf-8'))
                assert content['type']=='FeatureCollection'
                assert content['metadata']['crs']=='EPSG:4326'
                def points(coords):
                    if isinstance(coords[0],(int,float)):
                        yield coords
                    else:
                        for c in coords:
                            yield from points(c)
                for f in content['features']:
                    spatial_feature_ids.add(str(f['id']))
                    assert f['type']=='Feature' and f['geometry']['type'] in ('Point','LineString','Polygon')
                    for x,y in points(f['geometry']['coordinates']):
                        assert -180<=x<=180 and -90<=y<=90
                    if f['geometry']['type']=='Polygon':
                        assert all(ring[0]==ring[-1] and len(ring)>=4 for ring in f['geometry']['coordinates'])
                    prop = f['properties']
                    if prop.get('entity_table') and str(prop.get('entity_id')) not in ids.get(prop['entity_table'],set()):
                        errors['asset_foreign_keys'].append(f'{row["id"]}/{f["id"]}')
            elif suffix=='.mp4':
                reader = imageio.get_reader(str(path),format='FFMPEG')
                count = 0
                try:
                    for frame in reader:
                        assert frame.shape[:2] == (int(row['height_px']),int(row['width_px']))
                        count += 1
                    assert count == 12
                    assert abs(float(reader.get_meta_data()['fps'])-6)<.01
                finally:
                    reader.close()
            elif suffix=='.wav':
                with wave.open(str(path),'rb') as audio:
                    assert audio.getframerate()==16000 and audio.getnchannels()==1 and audio.getsampwidth()==2
                    assert audio.getnframes()>0 and len(audio.readframes(audio.getnframes()))==audio.getnframes()*2
                    assert abs(audio.getnframes()/16000-float(row['duration_seconds']))<.001
                    assert row['audio_kind'] in ('tone_not_speech','machine_synthesized_speech_not_field_recording')
            elif suffix=='.pdf':
                pdf = PdfReader(str(path))
                text='\n'.join(page.extract_text() or '' for page in pdf.pages)
                assert 'SYNTHETIC' in text and len(text)>100
                with fitz.open(path) as doc:
                    for page in doc:
                        pix = page.get_pixmap(matrix=fitz.Matrix(.4,.4))
                        assert pix.width>100 and pix.height>100 and len(pix.samples)>1000
            elif suffix=='.txt':
                text=path.read_text(encoding='utf-8')
                assert any(method in text for method in ('not_transcribed_authored_fixture','mock_transcription_from_script'))
            else:
                raise ValueError('unrecognized format')
        except Exception as exc:
            errors['asset_decoders'].append(f'{row["id"]}: {type(exc).__name__}: {exc}')
    for table,rows in tables.items():
        if not isinstance(rows,list):
            continue
        for row in rows:
            for field in ('geometry_id','sample_point_id','position_id','discovery_point_id','discovery_location','feeding_area'):
                if row.get(field) and str(row[field]) not in spatial_feature_ids:
                    errors['asset_spatial_references'].append(f'{table}/{row["id"]}/{field}={row[field]}')
    for row in tables.get('attachment_links',[]):
        if row['attachment_id'] not in by_attachment or str(row['entity_id']) not in ids.get(row['entity_table'],set()):
            errors['asset_foreign_keys'].append(row['id'])
    for row in tables.get('media_annotations',[]):
        if row['attachment_id'] not in by_attachment:
            errors['asset_foreign_keys'].append(row['id'])
        if row['diagnosis_status']!='not_applicable_synthetic_format_test' or row['diagnostic_training_allowed'] not in (False,'False','false'):
            errors['asset_metadata'].append(row['id'])
    for row in tables.get('spatial_layer_registry',[]):
        att=by_attachment.get(row['attachment_id'])
        if not att or row['relative_path']!=att['relative_path'] or row['sha256']!=att['sha256'] or row['crs']!='EPSG:4326':
            errors['asset_metadata'].append(row['id'])
    versions = {r['id']:r for r in tables.get('document_versions',[])}
    for row in tables.get('documents',[]):
        version = versions.get(row['current_version_id'])
        if not version or version['document_id']!=row['id'] or version['version']!=row['current_version'] or version['relative_path']!=row['full_text_path']:
            errors['asset_document_versions'].append(row['id'])
    for row in versions.values():
        att=by_attachment.get(row['attachment_id'])
        if row['document_id'] not in ids.get('documents',set()) or not att or row['relative_path']!=att['relative_path'] or row['sha256']!=att['sha256']:
            errors['asset_document_versions'].append(row['id'])
        if row.get('replaces_version_id') and row['replaces_version_id'] not in versions:
            errors['asset_document_versions'].append(row['id'])
    return [dict(check_id=name,passed=not issues,checked_count=len(attachments),failure_count=len(issues),detail='; '.join(issues[:20]) if issues else 'All files decoded and requested constraints satisfied') for name,issues in errors.items()]
