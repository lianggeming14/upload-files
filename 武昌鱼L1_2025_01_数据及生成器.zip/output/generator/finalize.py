"""Summarize actual checks, hash final files and create a delivery ZIP."""
import csv,json,hashlib,zipfile,sys,importlib.metadata,os
from pathlib import Path
from collections import Counter
import run,business,environment

def finalize(root):
    root=Path(root).resolve()
    summary=json.loads((root/'reports/run_summary.json').read_text('utf-8'))
    independent=json.loads((root/'reports/independent_verification.json').read_text('utf-8'))
    coverage=json.loads((root/'reports/coverage_audit.json').read_text('utf-8'))
    assert not coverage['unreviewed_field_definitions'] and not coverage.get('foreign_key_errors',[]) and not coverage['primary_key_error_tables']
    xlsx=json.loads((root/'reports/xlsx_validation.json').read_text('utf-8'))
    assert not xlsx['errors']
    sample=json.loads((root/'sample/reports/run_summary.json').read_text('utf-8'))
    sample_verify=json.loads((root/'sample/reports/independent_verification.json').read_text('utf-8'))
    assert not summary['failed_checks'] and independent['passed'] and not sample['failed_checks'] and sample_verify['passed']
    import verify
    types=json.loads((root/'reports/serialization_types.json').read_text('utf-8'))
    t=verify.read_tables(root/'reference/baseline',types)
    cfg=json.loads((root/'scenario/config.json').read_text('utf-8'))
    def regen():
        x=business.generate(cfg);x.update(environment.generate(cfg,x));run.integrate(x,cfg);return x
    first=regen();second=regen()
    mismatches=[]
    for k,v in first.items():
        # Values reconstructed from mixed numeric CSV columns may be float vs int;
        # Python equality deliberately treats equivalent numeric values equally.
        cols=list(dict.fromkeys(c for r in v for c in r))
        normalized=lambda rows:[{c:r.get(c) for c in cols} for r in rows]
        if normalized(v)!=normalized(second[k]) or normalized(v)!=normalized(t[k]):mismatches.append(k)
    alt_cfg={**cfg,'seed':cfg['seed']+1}
    other=business.generate(alt_cfg);other.update(environment.generate(alt_cfg,other));run.integrate(other,alt_cfg)
    seed_changes=other['water_observations']!=first['water_observations']
    reproduction={'seed':cfg['seed'],'same_seed_two_runs_equal':not mismatches,'saved_csv_equal_to_regeneration':not mismatches,'checked_tables':list(first),'mismatches':mismatches,'alternate_seed_changes_random_observations':seed_changes,'scope':'Business uses deterministic scenario rules; seed drives stochastic environmental observations and dirty-input selection. All core tables regenerated twice; assets checked separately; XLSX metadata excluded'}
    run.dump(root/'reports/reproducibility.json',reproduction)
    assert not mismatches and seed_changes
    answers=list(csv.DictReader((root/'reference/answers/anomaly_ledger.csv').open(encoding='utf-8')))
    categories=Counter(r['anomaly_type'] for r in answers)
    gross=round(sum(r['gross_revenue_cny'] for r in t['sales']),2)
    costs=round(sum(r['amount_cny'] for r in t['cost_entries']),2)
    deductions=round(sum(r['amount_cny'] for r in t['settlement_deductions']),2)
    income=round(sum(r['amount_cny'] for r in t['cash_transactions'] if r.get('direction')=='receipt'),2)
    inventory=sum(r['closing_value_cny'] for r in t['inventory_lot_status']) if t.get('inventory_lot_status') and 'closing_value_cny' in t['inventory_lot_status'][0] else None
    files=Counter(Path(r.get('relative_path',r.get('path',''))).suffix for r in t['attachments'])
    lines=['# 武昌鱼知识库 L1 模拟数据验收报告','',f"版本 {run.VERSION}；随机种子 {cfg['seed']}；固定场景年 2025。运行顺序：小样生成与检查通过 → 全量生成 → CSV落盘独立读回 → 异常对照和负例测试。",'',
    f"实际交付1个虚构场、6口塘、{len(t['cohorts'])}个鱼群；{summary['tables']}张CSV基准表，业务/观测/索引 {summary['business_rows_excluding_provenance']:,} 行，加逐记录来源侧车共 {summary['baseline_rows']:,} 行。逐记录来源侧车不是新增业务事实。",'',
    '|类别|全量实际行数|','|---|---:|']
    for table in ['water_observations','weather_observations','water_samples','water_test_results','feeding_events','patrol_events','growth_samples','growth_individuals','fish_daily_balance','harvests','sales','harvest_sale_allocations','inventory_movements','cost_entries','cost_allocations','cash_transactions','attachments','documents','document_versions']:
        lines.append(f'|{table}|{len(t.get(table,[])):,}|')
    lines.extend(['',f"水质基准保留52,560个小时槽位；其中288个槽位因清塘无水明确记为空值/不适用，不假造水中实测。全年天气8,760行来自S07 ERA5单格点再分析，其余场内观测均是规则模拟。生长样本为有鱼月份66组、1,980尾，12月清塘后不再造采样。",'',
    f"全量生成检查 {summary['checks']} 项通过；独立磁盘读回检查 {independent['checks_count']} 项通过。小样 {sample['checks']} 项生成检查及 {sample_verify['checks_count']} 项独立检查通过。独立负例故意破坏鱼尾数、库存、销售分配和回款，各对应校验均检出。详见checks.json、independent_verification.json与sample/reports。",'',
    f"守恒覆盖：每日鱼尾数与生物量、转移两端及损耗、批次/产品库存数量金额、采购领用退库报损盘点、规格重量与销售分配、结算扣款、收付款核销及费用分摊。全年销售毛收入 {gross:,.2f} 元；总成本费用 {costs:,.2f} 元；扣除结算扣款及成本后的模拟利润 {gross-costs-deductions:,.2f} 元。结算扣款 {deductions:,.2f} 元仅在扣款表记录，未计入成本台账，计算利润扣除一次。",'',
    '账面期末库存按批次区分可用、已过期待报损、有效期待核。过期待报损金额仍保留在账面，未无痕平账；投喂没有使用过期饲料。设备电耗是运行估算，供电费用含全场其他负荷与固定费，不能只拿增氧机估计耗电反推电费。','',
    f"原始输入注入 {summary['injected_records']:,} 条记录，占可注入表记录 {summary['injection_ratio_eligible']:.2%}，占全部业务/观测/索引记录 {summary['injection_ratio_all_data_rows']:.2%}。另增重复行 {summary['duplicate_rows_added']} 条。抽样分母含表清单，答案有实际CSV物理行号和基准行号。文件乱序是整文件源格式变化，未计作逐行异常比例。",'',
    '|注入类型|记录数|','|---|---:|'])
    lines.extend(f'|{k}|{v}|' for k,v in sorted(categories.items()))
    lines.extend(['','异常表与模拟原始输入逐项比对，无未解释改动、无未实现异常。低氧环境事件、校准测量及干塘空槽属于场景事实，与卡值/漂移/缺失/错单位/乱序/延迟/外键错误分开。连续卡值与漂移各有8小时场景。L2清洗结果本次未实施。','',
    f"字段清单拆为 {coverage['requirements_total']} 个原子项，结构映射 {coverage['mapped_requirements']} 项（{coverage['structural_coverage_rate']:.2%}）；实际字段字典 {coverage['field_count']} 项。具体场景/样例覆盖 {coverage.get('scenario_example_requirements','见覆盖矩阵')}/{coverage.get('scenario_applicable_requirements','见覆盖矩阵')} 个适用项；条件不适用和未取得真实资料分列。结构覆盖不等于所有项都有真实资料；状态与缺口逐项保留在coverage_matrix.csv。",'',
    '|覆盖状态|原子项数|','|---|---:|'])
    lines.extend(f'|{k}|{v}|' for k,v in coverage['status_counts'].items())
    lines.extend(['',f"附件 {len(t['attachments'])} 个，格式分布：{dict(files)}。GeoJSON、GeoTIFF、图片、PDF、视频、音频与文档逐文件打开/解码并核对SHA-256；关联对象均可查询。图像、显微、切片、无人机、扫描件均为格式示意，非真实诊断证据。语音为TTS或显式降级音调，脚本文本是模拟转写，未执行真实ASR。",'',
    'XLSX是静态审核视图，CSV为全量交换基准。大表按首/中/末及关键场景抽样，确切行数与范围见工作簿索引及xlsx_validation.json；其余工作表按索引注明全量。没有将抽样工作簿称为全量时序。所有工作表已打开检查类型、维度和错误；抽样预览见review。','',
    '来源与限制：13个用户提供公开原件的SHA-256均匹配原台账。2026规程与指南用于事后设计2025虚构场景；RAS和罗非鱼只参考格式，不套用其数值分布。全年市场价格是显式假设，无连续历史成交验证。药品批准信息、适用对象与休药期缺有效产品依据时留空/待核，本版不施药；没有真实确诊标签或品牌地理标志资格。空间布局不代表实际测绘。并塘仅有可表达的关系结构，本版实际案例是分塘/转塘，不伪称并塘。','',
    '小样以较小鱼量和压缩源事件贯通完整年度闭环；主数据、每日派生鱼量余额和分配明细因基数/守恒保留必要行数，并非每表均强行限制10–30行。','',
    '复现：冻结的公开输入+场景配置+规则版本+种子即可离线重新生成。同种子两次核心表生成与已交付CSV读回内容一致；不同种子改变随机环境观测和异常选择，确定性业务规则保持不变。媒体跨平台字形/TTS与容器元数据可能不同，不承诺跨平台二进制哈希一致。未污染基准是生成器内部答案，不是现场真值。'])
    (root/'reports/验收报告.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    packages=['numpy','Pillow','tifffile','reportlab','pypdf','PyMuPDF','imageio','imageio-ffmpeg','openpyxl']
    (root/'requirements.txt').write_text('\n'.join(p+'=='+importlib.metadata.version(p) for p in packages)+'\n',encoding='utf-8')
    exclude={'__pycache__','node_modules'}
    paths=[]
    for folder,dirs,files_in in os.walk(root):
        dirs[:]=[d for d in dirs if d not in exclude and d!='test_preview']
        for name in files_in:
            p=Path(folder)/name
            if p.suffix=='.pyc' or name.startswith('.') or 'draft' in name or name in ['file_manifest.csv','delivery_manifest.json','catalog_review_data.json','current_fields.json']:continue
            paths.append(p)
    run.write_csv(root/'reports/file_manifest.csv',[dict(path=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=run.digest(p)) for p in sorted(paths)])
    run.dump(root/'reports/delivery_manifest.json',{'version':run.VERSION,'seed':cfg['seed'],'files':len(paths)+2,'source_weather_sha256':run.digest(root/'public_sources/era5_2025.json'),'generator_sha256':{p.name:run.digest(p) for p in sorted((root/'generator').glob('*.py'))},'checks_passed':True})
    archive=root.parent/'武昌鱼L1模拟数据_2025_v1.0.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in paths+[root/'reports/file_manifest.csv',root/'reports/delivery_manifest.json']:z.write(p,Path('output')/p.relative_to(root))
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None
    (archive.with_suffix('.sha256')).write_text(run.digest(archive)+'  '+archive.name+'\n',encoding='utf-8')
    print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'coverage':coverage['structural_coverage_rate'],'reproducibility':not mismatches},ensure_ascii=False))

if __name__=='__main__':finalize(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
