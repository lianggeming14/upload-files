"""Atomic source coverage, data dictionary, machine schema and XLSX review.

The CSV package remains authoritative. Coverage is resolved against real fields,
and unresolved requirements remain visible rather than being declared complete.
"""
from __future__ import annotations

import csv
import json
import re
import datetime as dt
import hashlib
import subprocess
import os
from pathlib import Path


# Ordered exactly like the bullets in the original field list. Explicit semantic
# splitting avoids disguising a paragraph-level mapping as field coverage.
ATOMS = {
"一、所有数据共同需要的通用字段": [
"记录ID|养殖场ID|塘口ID|养殖批次ID|操作事件ID",
"实际发生时间|记录时间|入库时间|数据更新日期",
"记录人|审核人|数据来源系统|设备或供应方",
"塘口位置|采样点位置|设备位置|经度|纬度|坐标系",
"指标值|单位|检测方法|量纲",
"图片链接|视频链接|检测报告链接|合同链接|发票链接",
"是否异常|是否缺失|是否估算|质量标记|修改原因",
"原始记录编号|来源页码|凭证号|版本|审核状态",
"投喂记录ID|用药记录ID|病害记录ID|销售记录ID|成本记录ID"],
"二、基础主数据/1. 养殖场与塘口": [
"养殖场名称|地址|经营主体|联系方式",
"塘口编号|塘口名称|塘口面积|平均水深|最大水深|有效养殖水体",
"池塘形状|底质|进排水条件|水源类型",
"增氧机配置|投饵机配置|水泵配置|传感器配置",
"塘口启用时间|塘口当前状态|历史维修记录|历史改造记录",
"塘口边界|进水口GIS|排水口GIS|设备位置GIS"],
"二、基础主数据/2. 养殖批次": [
"养殖批次编号|品种|品系|苗种来源",
"开始日期|预计出塘日期|实际结束日期",
"初始投放数量|初始投放重量|初始投放规格|初始投放密度",
"批次状态",
"分塘父子批次关系|并塘父子批次关系|转塘父子批次关系",
"对应技术规程|生产计划|负责人"],
"二、基础主数据/3. 基础字典": [
"鱼苗目录|饲料目录|药品目录|疫苗目录|动保产品目录",
"病害字典|症状字典|病原字典|检测项目字典",
"规格等级字典|品质等级字典|销售渠道字典",
"成本科目字典|收入类型字典|费用分摊方式字典",
"供应商主体|客户主体|收购商主体|物流企业主体|检测机构主体"],
"三、生产记录的详细内容/1. 清塘与放养前准备": [
"清塘日期|塘口|上一年度养殖批次",
"排干操作|晒塘操作|清淤操作|修整操作",
"消毒剂或生石灰名称|消毒剂用量|消毒剂使用方式",
"注水时间|水源|水位|水质检测结果",
"增氧设备检查|进排水设备检查",
"操作人|审核人|现场照片|相关凭证"],
"三、生产记录的详细内容/2. 苗种采购与投放记录": [
"投放日期|养殖批次|塘口",
"苗种品种|苗种品系|苗种供应商|苗种产地|苗种批次",
"苗种数量|苗种总重量|苗种平均规格|苗种规格分布",
"投放密度|苗种单价|苗种总成本",
"苗种健康状态|检验检疫或质量证明",
"运输方式|运输时长|运输死亡率",
"投放水温|投放溶氧|温差|缓苗处理",
"到场照片视频|开箱照片视频|投放过程照片视频"],
"三、生产记录的详细内容/3. 投喂记录": [
"投喂日期|投喂具体时间|塘口|养殖批次",
"饲料品牌|饲料类型|饲料批号|粒径",
"粗蛋白等营养指标|保质期",
"本次投喂量|每日累计投喂量",
"投喂方式",
"投喂设备|投喂区域|投喂频次",
"饲料单价|本次饲料成本",
"摄食强度|剩料情况|抢食行为",
"当天天气|当时水温|当时溶氧",
"调整投喂量原因|操作人员",
"摄食视频|水下视频|现场照片"],
"三、生产记录的详细内容/4. 水质监测记录": [
"监测时间|塘口|监测点|采样深度",
"水温|溶解氧|pH|氨氮|亚硝酸盐",
"硝酸盐|透明度|电导率|盐度|氧化还原电位|叶绿素",
"指标值|单位|检测方法|检测仪器",
"传感器编号|安装位置|校准日期",
"自动或人工检测|原始值|校正值",
"异常标记|数据缺失原因|复核结果",
"水色照片|检测试纸照片|实验室报告"],
"三、生产记录的详细内容/5. 日常巡塘记录": [
"巡塘时间|巡塘人|巡塘天气",
"鱼群游动行为|摄食行为|浮头行为|靠边行为",
"水色|透明度|气味|藻类|浮沫",
"死鱼数量|死鱼重量|死鱼规格|死鱼发现位置",
"增氧机运行状态|水泵运行状态|投饵机运行状态",
"异常情况描述|初步处理措施",
"现场照片|视频|音频|语音巡塘记录"],
"三、生产记录的详细内容/6. 生长采样记录": [
"采样日期|塘口|养殖批次|采样方法",
"样本数量|采样位置|样本照片",
"体长|全长|个体体重|分组统计",
"平均体重|最小体重|最大体重|体重标准差",
"各规格区间数量|各规格区间比例|规格达标率",
"生长阶段|健康状况|外观|整齐度",
"估算存塘数量|估算存塘重量|可售生物量",
"采样工具|记录人|估算方法|可信度"],
"三、生产记录的详细内容/7. 病害与健康记录": [
"发现时间|塘口|养殖批次|涉及数量",
"摄食下降症状|浮头症状|异常游动症状",
"体表病变|鳃病变|内脏病变",
"发病率|死亡数量|死亡速度|持续时间",
"初步判断|实验室诊断|病原检测结果",
"诊断状态",
"检测机构|报告编号|检测方法",
"病鱼照片|病鱼视频|显微图像|检测报告",
"处置措施|恢复情况|复发情况"],
"三、生产记录的详细内容/8. 用药与动保操作记录": [
"操作时间|塘口|批次|操作原因",
"药品或动保产品名称|批准或登记信息|生产批号",
"有效成分|用量|浓度|使用方法|疗程",
"使用对象|适用病害|禁忌|注意事项",
"起始日期|停止日期|休药期|预计可出塘日期",
"操作人|指导兽医或技术人员",
"药品采购成本|使用效果|不良反应",
"药品包装照片|处方|操作现场照片|操作凭证"],
"三、生产记录的详细内容/9. 水质调控与设备运行": [
"换水时间|加水时间|排水时间|水量",
"增氧机启动时间|增氧机停止时间|运行时长|耗电量",
"水质调节剂使用记录|微生态制剂使用记录",
"设备故障|设备维修|设备保养|设备替换|设备费用",
"自动设备控制指令|执行结果|异常报警",
"操作前水质|操作后水质|操作前鱼群状态|操作后鱼群状态"],
"三、生产记录的详细内容/10. 死亡与无害化处理": [
"死亡日期|死亡数量|死亡重量|死亡规格",
"可能原因|相关病害|环境异常",
"打捞方式|运输方式|无害化处理方式",
"处理单位|处理费用|相关证明",
"现场照片|处理记录"],
"三、生产记录的详细内容/11. 分塘、并塘与转塘": [
"原塘口|目标塘口|原批次|新批次",
"转移时间|转移数量|转移重量|转移规格",
"转移死亡|转移损耗",
"父子批次关系",
"操作人员|转移原因|现场记录"],
"三、生产记录的详细内容/12. 捕捞与出塘记录": [
"出塘批次|养殖批次|捕捞日期",
"捕捞方式|起捕数量|毛重|净重",
"各规格区间数量|各规格区间重量|各规格区间比例",
"品质等级|健康状态|药残或质量检测",
"捕捞损耗|运输损耗|折价|扣款",
"出塘去向",
"销售批次|收购方|运输车辆",
"捕捞图片视频|分拣图片视频|称重图片视频|装车图片视频"],
"四、GIS 与空间数据/1. 养殖场内部空间数据": [
"养殖场边界|塘口边界",
"水源|河道|进水口|排水口",
"采样点位置|传感器位置|增氧机位置|投饵机位置",
"病害发现位置|死鱼发现位置",
"无人机航拍|塘口正射影像",
"塘口面积时点变化|水位时点变化|水面时点变化"],
"四、GIS 与空间数据/2. 外部环境空间数据": [
"周边河流|周边湖泊|土地利用|行政区位",
"气象站位置|降雨网格|高温灾害网格",
"洪水风险区域|干旱风险区域",
"饲料厂位置|苗种场位置|检测机构位置|批发市场位置|加工厂位置",
"运输路线|运输距离|运输时间"],
"五、图像、视频及其他多模态数据": [
"鱼体照片|鳃照片|内脏照片|病害部位照片",
"显微病原图像|组织切片图像",
"正常摄食视频|异常游动视频|浮头视频",
"水下摄像|固定监控|无人机影像",
"巡塘语音|专家录音|自动转写文本",
"检测报告扫描件|处方扫描件|合同扫描件|发票扫描件",
"传感器曲线图|生产报表图"],
"六、市场、销售与经济数据/1. 行情价格观测": [
"品种|规格|品质|鲜活状态",
"行情时间|地区|市场|销售渠道",
"塘口价|收购价|批发价|零售价",
"报价或实际成交|成交量",
"是否含税|运费|包装|佣金",
"数据来源|采集时间|可信度",
"替代鱼种价格|饲料原料价格"],
"六、市场、销售与经济数据/2. 实际销售与结算": [
"销售批次|养殖批次|出塘批次",
"客户|渠道|合同|订单|结算单号",
"规格等级销量|品质等级销量|成交单价",
"毛收入|运输费|佣金|包装费|扣款",
"实际到手收入|到手单价",
"开票日期|回款日期|未回款金额|账期"],
"六、市场、销售与经济数据/3. 成本与费用凭证": [
"成本科目|成本金额|发生日期|供应商",
"对应塘口|对应养殖批次",
"直接成本或共同费用",
"共同费用分摊方式|共同费用分摊比例",
"合同|发票|付款凭证|审核状态"],
"七、技术文档与外部知识": [
"苗种技术规程|成鱼养殖技术规程|病害防控技术规程",
"国家标准|行业标准|地方标准|企业标准",
"饲料说明书|药品说明书|动保产品说明书",
"科研论文|试验报告|专家经验材料",
"政策规定|环保规定|食品安全规定|休药期规定",
"气象知识|灾害知识|物流知识|供需知识|原料行情知识"],
}

EXTRAS = {
"四、GIS 与空间数据/空间元数据": "采集时间|坐标参考系|比例尺|空间分辨率|来源|版本|精度|覆盖范围",
"五、图像、视频及其他多模态数据/附件元数据": "文件ID|关联塘口|关联批次|关联事件|拍摄时间|拍摄设备|文件类型|存储地址|标注内容|审核状态|文件校验值",
"七、技术文档与外部知识/文档元数据": "全文|标题|发布机构|版本|发布日期|适用地区|适用养殖模式|来源地址|页码|审核状态",
"补充关系/鱼群与塘口": "批次定义|入塘时间|离塘时间|主养或套养角色|一塘多批次|一批分塘",
"补充关系/出塘销售": "出塘批次|销售明细|鱼种|规格|分配净重|分批销售|合批销售",
"补充关系/采购库存": "采购明细|入库|领用|退库|报损|盘点调整|采购金额|实际消耗成本|期初库存|计价方法",
"补充关系/费用所属期间": "费用期间|分摊基数|受益塘口|受益批次|分摊金额",
"补充关系/收付款核销": "独立收付款|销售金额|费用扣除|结算净额|已收金额|未收金额|分期回款|一款多单",
"补充口径/合成身份": "origin_kind|is_synthetic|reference_source_id|generation_run_id|rule_version|seed|scenario_id|parameter_basis",
"补充口径/物种": "来源原名|规范名称|学名|鱼种代码|映射状态|映射依据|品系|产地|商品名|品牌|地理标志资格",
"补充口径/检测": "测定对象|表达基准|方法|单位|检出限|低于检出限标记",
"补充口径/时间": "实际发生时间|人工记录时间|上传时间|采集时间|入库时间|来源时区|时间精度|设备安装时间|设备拆除时间|设备校准时间|换机有效时间",
"补充口径/经济": "币种|价格单位|含税状态|运费承担方|佣金承担方|优惠|退货|扣款|避免重复扣除",
"补充口径/缺失": "未采集|未收到|检测失败|不适用|低于检出限|估算值",
"补充口径/文档附件": "授权或获取条件|语言|有效废止替代状态|文件真实存在状态|标注依据|诊断状态",
}

# Reviewed semantic definitions. Unknown columns are explicitly reported and
# never silently assigned a made-up meaning or an all-purpose text type.
FIELD_MEANINGS = dict(part.split("=",1) for part in """
id=本逻辑表的稳定主键
farm_id=养殖场标识
pond_id=塘口标识
cohort_id=鱼群养殖批次标识
species_id=规范物种标识
event_id=生产或业务事件标识
name=实体名称
operator_name=养殖场经营主体名称
address=地址
contact=联系方式
identity_status=身份真实性状态
longitude=经度
latitude=纬度
crs=坐标参考系
production_mode=养殖模式
timezone=适用时区
area_m2=塘口面积（平方米）
area_mu=塘口面积（亩）
mean_depth_m=平均水深
maximum_depth_m=最大水深
effective_volume_m3=有效养殖水体积
shape=塘口形状
bottom_type=池塘底质
inlet_condition=进水条件
outlet_condition=排水条件
water_source=水源类型
commissioned_on=塘口启用日期
current_status=塘口当前状态
geometry_id=对应空间要素标识
equipment_configuration=塘口设备配置说明
previous_cycle_id=上一养殖周期标识
previous_cycle_status=上一周期记录取得状态
standard_name=规范中文物种名称
scientific_name=物种学名
original_name=来源原始名称
species_code=规范鱼种代码
common_commercial_name=常见商品名称
mapping_status=物种名称映射状态
mapping_basis=物种名称映射依据
strain=品系名称
strain_status=品系资料取得状态
origin=原产地
brand=品牌名称
brand_status=品牌资料状态
geographical_indication_qualified=是否具备地理标志资格
geographical_indication_status=地理标志资格核实状态
default_role=物种默认主养或套养角色
parent_cohort_id=父鱼群批次标识
cohort_definition=本数据包的批次定义
role=主养或套养角色
start_date=养殖批次开始日期
expected_harvest_date=预计出塘日期
actual_end_date=批次实际结束日期
initial_count=初始投放尾数
initial_weight_kg=初始投放总重量
initial_mean_weight_g=初始投放平均个体重量
initial_density_fish_per_mu=初始投放密度
seed_origin=苗种来源地
original_commercial_name=原始商品名
status=该业务对象的状态（枚举见本表实际值）
technical_plan_id=所用技术计划标识
responsible_person_id=负责人标识
entered_at=进入塘口的有效时间
left_at=离开塘口的有效时间
entry_reason=入塘原因
exit_reason=离塘原因
occurred_at=实际发生时间
recorded_at=人工或源系统记录时间
uploaded_at=上传时间
ingested_at=入库时间
updated_at=最近更新时间
source_record_id=原始来源记录编号
recorder_id=记录人员标识
reviewer_id=审核人员标识
source_system=源系统名称
review_status=审核状态
quality_flag=质量标记
is_estimated=是否属于估算值或估算记录
source_timezone=来源时区
time_precision=来源时间精度
purchase_item_id=采购明细标识
product_id=投入品目录标识
seed_batch_id=苗种供应批次编号
supplier_id=供应商主体标识
count=鱼尾数
weight_kg=总重量
mean_weight_g=平均每尾重量
size_distribution=各规格区间分布
stocking_density_fish_per_mu=投放密度
unit_price_cny=每个所列单位的单价（人民币）
total_cost_cny=该业务总成本
transport_method=运输方式
transport_duration_hours=运输时长
transport_mortality_count=运输死亡尾数
transport_mortality_rate=运输死亡率
health_status=健康状态
quarantine_certificate_id=检疫或质量证明编号
quarantine_status=检疫资料取得状态
water_temperature_c=水温
dissolved_oxygen_mg_l=溶解氧浓度
temperature_difference_c=运输水与塘水温差
acclimation_method=缓苗处理方法
count_basis=尾数取得依据
weight_basis=重量取得依据
source_pond_id=转移来源塘口标识
source_cohort_id=转移来源鱼群批次标识
transferred_out_count=转出尾数（含转运损耗）
transferred_out_weight_kg=转出重量
received_count=目标塘实际接收尾数
received_weight_kg=目标塘实际接收重量
loss_count=转运损耗尾数
loss_weight_kg=转运损耗重量
reason=该项操作或事件原因
loss_cause=损耗原因
operation_person_id=操作人员标识
transfer_event_id=转塘事件标识
target_pond_id=目标塘口标识
target_cohort_id=目标鱼群批次标识
possible_cause=可能原因，非确诊结论
cause_status=原因确认状态
related_health_case_id=相关健康病例标识
discovery_location=发现位置说明
mortality_event_id=死亡事件标识
method=本表操作或采样方法
service_partner_id=服务或处置单位标识
cost_cny=本次成本（人民币）
certificate_id=证明文件编号
certificate_status=证明资料取得状态
balance_date=存塘守恒计算日期
opening_count=期初存塘尾数
stocked_count=当日投放尾数
transfer_in_count=当日转入尾数
transfer_out_count=当日转出尾数
mortality_count=当日死亡尾数
harvest_count=当日捕捞尾数
adjustment_count=显式盘点尾数调整
closing_count=期末存塘尾数
opening_biomass_kg=期初生物量
stocked_weight_kg=投放重量
transfer_in_weight_kg=转入重量
transfer_out_weight_kg=转出重量
mortality_weight_kg=死亡重量
harvest_weight_kg=捕捞重量
growth_weight_kg=规则估算的生长增重
biomass_adjustment_kg=生物量显式调整
closing_biomass_kg=期末估算生物量
closing_mean_weight_g=期末估算平均个体重量
feed_quantity_kg=当日投喂量
biomass_basis=生物量口径
growth_basis=生长估算依据
feed_to_growth_ratio_assumed=假设投料增重比
companion_growth_basis=套养鱼生长估算依据
estimate_error_kg=显式估算误差
product_batch_id=投入品生产或采购批号
quantity_kg=本次投入或投喂重量
daily_total_kg=本塘当日累计投喂量
feeding_method=投喂方式
device_id=设备标识
feeding_area=投喂区域
frequency_per_day=当日投喂次数
feeding_intensity=摄食强度
leftover_status=剩料情况
competition_behavior=抢食行为
weather_condition=天气情况
adjustment_reason=投喂调整原因
measurement_basis=数值测量或生成依据
aggregation_note=聚合与重复统计注意事项
nutrition_parameter_basis=营养参数来源依据
coarse_protein_pct=粗蛋白质量百分比（0至100）
particle_diameter_mm=饲料粒径
shelf_life_days=保质期天数
product_name=投入品名称
product_type=投入品类型
unit=数量或测量单位
assumed_unit_price_cny=假设单价（每个所列单位）
manufacturer=生产企业
registration_number=批准或登记编号
registration_status=批准登记资料核实状态
parameter_basis=参数依据
partner_type=主体类型
contact_status=联系方式资料状态
region=地区
currency=币种
invoice_number=发票编号
invoice_status=发票取得或开票状态
contract_number=合同编号
gross_amount_cny=毛金额
amount_cny=本记录金额（人民币）
tax_status=含税状态
received_on=采购到货日期
is_consumption_cost=采购金额是否已构成消耗成本
payment_status=付款状态
purchase_id=采购单标识
quantity=数量（单位由unit给定）
valuation_method=库存计价方法
manufacture_on=生产日期
expires_on=到期日期
movement_type=库存变动类型
quantity_delta=带正负号的库存数量变动
amount_delta_cny=带正负号的库存价值变动
opening_quantity=变动前库存数量
closing_quantity=变动后库存数量
opening_value_cny=变动前库存价值
closing_value_cny=变动后库存价值
source_type=关联来源对象类型
source_id=关联来源对象标识（与source_type联合解析）
movement_reason=库存变动原因
balance_type=期初余额类别
as_of=期初余额时点
harvest_type=捕捞类型（部分或最终出塘）
gross_weight_kg=毛重量
tare_weight_kg=皮重
net_weight_kg=净重量
saleable_weight_kg=可分配销售净重
harvest_loss_count=捕捞损耗尾数
harvest_loss_weight_kg=捕捞损耗重量
transport_loss_weight_kg=运输损耗重量
deduction_weight_kg=明确扣除重量
quality_grade=品质等级
residue_test_status=药残或质量检测状态
disposition=出塘去向
vehicle_id=运输车辆编号
weighing_basis=称重口径
harvest_id=出塘批次标识
grade=规格等级
weight_ratio=该规格占总重量比例（0至1）
customer_id=客户主体标识
channel=销售渠道
order_number=订单编号
freight_bearer=运费承担方
commission_bearer=佣金承担方
invoice_on=开票日期
live_status=鲜活状态
gross_revenue_cny=销售毛收入
return_weight_kg=退货重量
actual_trade=是否实际成交记录
quote_observation_id=参考行情观测标识
price_basis=成交价格生成依据
sale_id=销售批次标识
unit_price_cny_per_kg=成交单价（元每公斤）
discount_cny=优惠折价金额
species_mapping_status=该来源商品名的物种映射状态
harvest_grade_item_id=出塘规格明细标识
sale_item_id=销售规格明细标识
allocated_net_weight_kg=分配至销售明细的出塘净重
allocation_basis=分摊或分配基数
gross_sales_amount_cny=结算对应销售毛金额
deductions_amount_cny=结算扣款合计
net_amount_cny=结算净额
received_amount_cny=已收款金额
outstanding_amount_cny=未收款金额
actual_net_unit_price_cny_per_kg=实际到手单价（元每公斤）
payment_terms_days=账期天数
due_on=应收款到期日期
final_received_on=最终结清日期
profit_basis=利润核算口径
settlement_id=结算单标识
deduction_type=结算扣款类型
payer=费用承担方
recognition=扣款在利润中确认方式
cost_entry_id=成本记录标识
source_document_id=来源凭证标识
direction=收款或付款方向
counterparty_id=收付款对方主体标识
payment_method=收付款方式
bank_reference=支付流水凭证号
balance_scope=余额核算范围
cash_transaction_id=独立收付款流水标识
allocation_type=收付款核销对象类型
category=类别（枚举见本表实际值）
cost_type=直接成本或共同费用
period_start=费用归属期间开始日期
period_end=费用归属期间结束日期
settlement_deduction_id=结算扣款记录标识
profit_treatment=利润核算中纳入或排除方式
allocation_method=费用分摊方法
beneficiary_type=费用受益对象类型
allocation_basis_unit=分摊基数单位
allocation_ratio=费用分摊比例（0至1）
""".strip().splitlines())

FK_TARGETS = {
    "farm_id":"farms", "pond_id":"ponds", "source_pond_id":"ponds", "target_pond_id":"ponds",
    "cohort_id":"cohorts", "parent_cohort_id":"cohorts", "source_cohort_id":"cohorts", "target_cohort_id":"cohorts",
    "species_id":"species", "product_id":"products", "purchase_id":"purchases", "purchase_item_id":"purchase_items",
    "supplier_id":"partners", "customer_id":"partners", "service_partner_id":"partners", "counterparty_id":"partners",
    "transfer_event_id":"transfer_events", "mortality_event_id":"mortality_events", "related_health_case_id":"health_cases",
    "harvest_id":"harvests", "harvest_grade_item_id":"harvest_grade_items", "sale_id":"sales", "sale_item_id":"sale_items",
    "settlement_id":"settlements", "settlement_deduction_id":"settlement_deductions", "cash_transaction_id":"cash_transactions",
    "cost_entry_id":"cost_entries", "device_id":"devices", "quote_observation_id":"price_observations",
    "attachment_id":"attachments", "document_id":"documents", "document_version_id":"document_versions",
    "sample_id":"water_samples", "health_case_id":"health_cases", "case_id":"health_cases", "growth_sample_id":"growth_samples",
}

# Requirement mappings are explicit and table-qualified. A target is retained
# only when that exact column exists in the generated package.
MAP = {}


def mapping(section, table, lines):
    for line in lines.strip().splitlines():
        aliases, targets = line.split("=", 1)
        refs = [v if "." in v else table+"."+v for v in targets.split("+")]
        for alias in aliases.split("|"):
            MAP[(section, alias)] = refs


mapping("二、基础主数据/1. 养殖场与塘口", "ponds", """
养殖场名称=farms.name
地址=farms.address
经营主体=farms.operator_name
联系方式=farms.contact
塘口编号=id
塘口名称=name
塘口面积=area_m2+area_mu
平均水深=mean_depth_m
最大水深=maximum_depth_m
有效养殖水体=effective_volume_m3
池塘形状=shape
底质=bottom_type
进排水条件=inlet_condition+outlet_condition
水源类型=water_source
增氧机配置|投饵机配置|水泵配置|传感器配置=equipment_configuration
塘口启用时间=commissioned_on
塘口当前状态=current_status
历史维修记录|历史改造记录=device_maintenance.maintenance_type
塘口边界=geometry_id
""")
mapping("二、基础主数据/2. 养殖批次", "cohorts", """
养殖批次编号=id
品种=species_id
品系=strain
苗种来源=seed_origin
开始日期=start_date
预计出塘日期=expected_harvest_date
实际结束日期=actual_end_date
初始投放数量=initial_count
初始投放重量=initial_weight_kg
初始投放规格=initial_mean_weight_g
初始投放密度=initial_density_fish_per_mu
批次状态=status
分塘父子批次关系|并塘父子批次关系|转塘父子批次关系=parent_cohort_id+transfer_allocations.source_cohort_id+transfer_allocations.target_cohort_id
对应技术规程|生产计划=technical_plan_id
负责人=responsible_person_id
""")
mapping("三、生产记录的详细内容/2. 苗种采购与投放记录", "stocking_events", """
投放日期=occurred_at
养殖批次=cohort_id
塘口=pond_id
苗种品种=species_id
苗种品系=cohorts.strain
苗种供应商=supplier_id
苗种产地=cohorts.seed_origin
苗种批次=seed_batch_id
苗种数量=count
苗种总重量=weight_kg
苗种平均规格=mean_weight_g
苗种规格分布=size_distribution
投放密度=stocking_density_fish_per_mu
苗种单价=unit_price_cny
苗种总成本=total_cost_cny
苗种健康状态=health_status
检验检疫或质量证明=quarantine_certificate_id+quarantine_status
运输方式=transport_method
运输时长=transport_duration_hours
运输死亡率=transport_mortality_rate
投放水温=water_temperature_c
投放溶氧=dissolved_oxygen_mg_l
温差=temperature_difference_c
缓苗处理=acclimation_method
""")
mapping("三、生产记录的详细内容/3. 投喂记录", "feeding_events", """
投喂日期|投喂具体时间=occurred_at
塘口=pond_id
养殖批次=cohort_id
饲料品牌=products.brand
饲料类型=products.product_type
饲料批号=product_batch_id
粒径=particle_diameter_mm
粗蛋白等营养指标=coarse_protein_pct
保质期=shelf_life_days
本次投喂量=quantity_kg
每日累计投喂量=daily_total_kg
投喂方式=feeding_method
投喂设备=device_id
投喂区域=feeding_area
投喂频次=frequency_per_day
饲料单价=unit_price_cny
本次饲料成本=cost_cny
摄食强度=feeding_intensity
剩料情况=leftover_status
抢食行为=competition_behavior
当天天气=weather_condition
当时水温=water_temperature_c
当时溶氧=dissolved_oxygen_mg_l
调整投喂量原因=adjustment_reason
操作人员=recorder_id
""")
mapping("三、生产记录的详细内容/10. 死亡与无害化处理", "mortality_events", """
死亡日期=occurred_at
死亡数量=count
死亡重量=weight_kg
死亡规格=mean_weight_g
可能原因|环境异常=possible_cause+cause_status
相关病害=related_health_case_id
无害化处理方式=disposal_events.method
处理单位=disposal_events.service_partner_id
处理费用=disposal_events.cost_cny
相关证明=disposal_events.certificate_id+disposal_events.certificate_status
处理记录=disposal_events.id
""")
mapping("三、生产记录的详细内容/11. 分塘、并塘与转塘", "transfer_events", """
原塘口=source_pond_id
目标塘口=pond_id
原批次=source_cohort_id
新批次=cohort_id
转移时间=occurred_at
转移数量=transferred_out_count
转移重量=transferred_out_weight_kg
转移死亡=loss_count
转移损耗=loss_weight_kg
父子批次关系=cohorts.parent_cohort_id+transfer_allocations.source_cohort_id+transfer_allocations.target_cohort_id
操作人员=operation_person_id
转移原因=reason
现场记录=source_record_id
""")
mapping("三、生产记录的详细内容/12. 捕捞与出塘记录", "harvests", """
出塘批次=id
养殖批次=cohort_id
捕捞日期=occurred_at
捕捞方式=method
起捕数量=count
毛重=gross_weight_kg
净重=net_weight_kg
各规格区间数量=harvest_grade_items.count
各规格区间重量=harvest_grade_items.net_weight_kg
各规格区间比例=harvest_grade_items.weight_ratio
品质等级=quality_grade
健康状态=health_status
药残或质量检测=residue_test_status
捕捞损耗=harvest_loss_count+harvest_loss_weight_kg
运输损耗=transport_loss_weight_kg
折价=sale_items.discount_cny
扣款=settlement_deductions.amount_cny
出塘去向=disposition
销售批次=harvest_sale_allocations.sale_id
收购方=sales.customer_id
运输车辆=vehicle_id
""")
mapping("六、市场、销售与经济数据/2. 实际销售与结算", "sales", """
销售批次=id
养殖批次=harvest_sale_allocations.cohort_id
出塘批次=harvest_sale_allocations.harvest_id
客户=customer_id
渠道=channel
合同=contract_number
订单=order_number
结算单号=settlements.id
规格等级销量=sale_items.grade+sale_items.net_weight_kg
品质等级销量=sale_items.quality_grade+sale_items.net_weight_kg
成交单价=sale_items.unit_price_cny_per_kg
毛收入=gross_revenue_cny
运输费|佣金|包装费|扣款=settlement_deductions.deduction_type+settlement_deductions.amount_cny
实际到手收入=settlements.net_amount_cny
到手单价=settlements.actual_net_unit_price_cny_per_kg
开票日期=invoice_on
回款日期=cash_transactions.occurred_at+settlements.final_received_on
未回款金额=settlements.outstanding_amount_cny
账期=settlements.payment_terms_days
""")
mapping("六、市场、销售与经济数据/3. 成本与费用凭证", "cost_entries", """
成本科目=category
成本金额=amount_cny
发生日期=occurred_at
供应商=purchases.supplier_id
对应塘口=pond_id
对应养殖批次=cohort_id
直接成本或共同费用=cost_type
共同费用分摊方式=allocation_method
共同费用分摊比例=cost_allocations.allocation_ratio
合同=purchases.contract_number
发票=purchases.invoice_number+purchases.invoice_status
付款凭证=cash_transactions.bank_reference
审核状态=review_status
""")
mapping("补充关系/鱼群与塘口", "pond_cohort_occupancy", """
批次定义=cohorts.cohort_definition
入塘时间=entered_at
离塘时间=left_at
主养或套养角色=role
一塘多批次|一批分塘=pond_id+cohort_id+entered_at+left_at
""")
mapping("补充关系/出塘销售", "harvest_sale_allocations", """
出塘批次=harvest_id
销售明细=sale_item_id
鱼种=species_id
规格=grade
分配净重=allocated_net_weight_kg
分批销售|合批销售=harvest_id+sale_id
""")
mapping("补充关系/采购库存", "inventory_movements", """
采购明细=purchase_items.id
入库|领用|退库|报损|盘点调整=movement_type+quantity_delta
采购金额=purchases.amount_cny
实际消耗成本=feeding_events.cost_cny+cost_entries.amount_cny
期初库存=opening_balances.quantity+opening_balances.amount_cny
计价方法=valuation_method
""")
mapping("补充关系/费用所属期间", "cost_allocations", """
费用期间=period_start+period_end
分摊基数=allocation_basis
受益塘口=pond_id
受益批次=cohort_id
分摊金额=amount_cny
""")
mapping("补充关系/收付款核销", "settlements", """
独立收付款=cash_transactions.id
销售金额=gross_sales_amount_cny
费用扣除=deductions_amount_cny
结算净额=net_amount_cny
已收金额=received_amount_cny
未收金额=outstanding_amount_cny
分期回款|一款多单=cash_allocations.cash_transaction_id+cash_allocations.settlement_id
""")
mapping("补充口径/物种", "species", """
来源原名=original_name
规范名称=standard_name
学名=scientific_name
鱼种代码=species_code
映射状态=mapping_status
映射依据=mapping_basis
品系=strain+strain_status
产地=origin
商品名=common_commercial_name
品牌=brand+brand_status
地理标志资格=geographical_indication_qualified+geographical_indication_status
""")
mapping("补充口径/经济", "sales", """
币种=currency
价格单位=sale_items.unit_price_cny_per_kg
含税状态=tax_status
运费承担方=freight_bearer
佣金承担方=commission_bearer
优惠=sale_items.discount_cny
退货=return_weight_kg
扣款=settlement_deductions.amount_cny
避免重复扣除=cost_entries.profit_treatment+settlement_deductions.recognition
""")

FIELD_MEANINGS.update(dict(part.split("=",1) for part in """
observed_at=观测时间
air_temperature_c=参考气象网格空气温度（非塘水温）
relative_humidity_pct=相对湿度百分比（0至100）
precipitation_mm=小时降水量
shortwave_w_m2=短波辐射通量
wind_speed_km_h=风速
grid_id=气象再分析网格标识
grid_latitude=返回网格纬度
grid_longitude=返回网格经度
requested_latitude=API请求点纬度
requested_longitude=API请求点经度
model=设备型号或天气模型（按所属表解释）
spatial_resolution_degree=网格角度分辨率
reference_source_id=参考来源登记标识
origin_kind=数据来源类别（合成、再分析或派生等）
is_synthetic=是否合成记录
device_type=设备类型
rated_power_kw=额定功率
position_id=设备空间位置要素标识
installed_at=设备安装有效起始时间
removed_at=设备拆除或有效期截止时间
effective_end_exclusive=有效期终点是否不含该时刻
position_description=设备安装位置说明
started_at=操作或有效期开始时间
ended_at=操作或有效期结束时间
reference_ph=校准标准溶液pH值
offset_ph=pH校准偏移量
result=本表操作执行或检测结果
operator_id=操作人员代码
previous_cohort_id=前一养殖周期批次标识
previous_cohort_status=前一周期批次资料状态
operation=操作类型或组合操作说明
disinfectant_product_id=清塘消毒投入品标识
disinfectant_status=消毒参数资料及适用性状态
dose_kg=投入品用量（公斤）
application_method=施用方式
refill_at=重新注水时间
water_level_m=水位或水深
water_test_status=水质检测状态
equipment_check=增氧及进排水设备检查结论
repair_cost_yuan=维修费用（人民币）
sample_point_id=采样或监测点标识
depth_m=采样深度
temperature_c=水温
do_mg_l=溶解氧浓度
ph=pH校正后值
raw_ph=pH原始读数
ph_correction=pH校正偏移
measurement_context=测量环境（池塘或校准过程）
environment_condition=环境状态（与设备质量问题分开）
missing_reason=缺失原因
weather_id=相关小时天气观测标识
swimming=鱼群游动行为
feeding_behavior=摄食行为
bank_gathering=是否靠边聚集
water_color=水色
transparency_cm=透明度
odor=气味
algae=藻类状况
foam=浮沫状况
dead_count=巡塘发现死鱼尾数
dead_weight_kg=巡塘发现死鱼重量
dead_size_g=巡塘死鱼平均规格
discovery_point_id=异常发现空间点标识
aerator_status=增氧机运行状态
pump_status=水泵运行状态
feeder_status=投饵机运行状态
exception_description=异常情况描述
action=采取的处置措施
duration_h=运行时长
energy_kwh=设备耗电量
energy_basis=耗电估计及成本口径
command_id=自动控制指令标识
planned_at=控制计划时间
issued_at=控制指令下发时间
executed_at=控制指令执行时间
command=控制指令内容
alarm=异常报警内容
sampled_at=采样时间
sampler_id=采样人员代码
received_at=样品接收时间
lab_name=检测机构名称
sampling_method=采样方法
sample_id=所属采样事件标识（依所属表关联）
analyte_code=测定对象代码，区分TAN及亚硝酸盐氮表达基准
value=检测数值；低于检出限或失败保留空值
raw_value=未经转换的检测原始值或限定符
corrected_value=校正后的检测数值
expression_basis=检测对象表达基准
instrument_id=检测仪器编号
detection_limit=检出限（单位同结果unit）
result_status=结果报告、低于检出限或失败状态
verified_by=检测结果复核人员代码
reported_at=报告出具时间
inflow_m3=进水体积
outflow_m3=排水体积
dose_status=用量是否适用或资料待核状态
do_before_mg_l=操作前溶解氧
do_after_mg_l=操作后溶解氧
fish_before=操作前鱼群状态
fish_after=操作后鱼群状态
fault=设备故障描述
replacement_device_id=替换后设备标识
cost_yuan=费用金额（人民币）
cost_status=费用确认或已包含口径
discovered_at=健康异常发现时间
affected_count=涉及鱼尾数
incidence_rate=涉及尾数占存塘尾数比例（0至1）
death_count=相关死亡尾数
mortality_per_day=每日死亡速度
duration_days=持续天数
diagnosis_status=疑似、已确诊或已排除诊断状态
preliminary_judgment=初步判断，不能等同确诊
description=该对象的描述
recovery=后续恢复情况
recurrence=是否复发
case_id=相关健康病例标识
behavior=行为症状
skin_description=体表观察描述
gill_description=鳃观察描述
viscera_description=内脏观察描述
diagnosis_basis=诊断或标注依据
report_number=检测报告编号
pathogen_code=病原字典代码
stopped_at=停止日期时间
operation_reason=操作原因
approval_number=药品批准或登记编号
manufacturer_lot=产品生产批号
active_ingredient=有效成分
dose=产品用量（未有依据时留空）
concentration=使用浓度（未有依据时留空）
course_days=疗程或非药物观察天数
target_species=适用对象
target_disease=适用病害或待核对象
contraindications=禁忌事项
precautions=注意事项
withdrawal_days=休药期天数
withdrawal_status=休药期适用及证据状态
earliest_harvest_date=按有依据休药期计算的最早出塘日期
product_parameter_status=产品参数核实状态
advisor_id=指导兽医或技术人员代码
purchase_cost_yuan=产品采购成本（人民币）
effect=使用或处置效果
adverse_reaction=不良反应
execution_status=实际施用或非药物操作状态
original_product_name=行情来源原商品名
freshness=鲜活状态
market_id=行情市场标识
price_yuan_per_kg=价格（元每公斤）
observation_kind=报价或实际成交的观测类别
transaction_volume_kg=已获知成交量
volume_status=成交量取得状态
tax_included=价格是否含税
freight_included=价格是否含运费
packaging_included=价格是否含包装费
commission_included=价格是否含佣金
collected_at=数据采集时间
credibility=数据可信度或适用边界
domain=字典业务域
code=字典代码
label=字典中文标签
body_length_cm=鱼体长（不含尾鳍）
total_length_cm=鱼全长（含尾鳍）
weight_g=个体重量
appearance=个体外观
sample_size=样本尾数
min_weight_g=样本最小个体重量
max_weight_g=样本最大个体重量
std_weight_g=样本个体重量标准差
grade_pass_rate=规格达标比例（0至1）
growth_stage=生长阶段
estimated_count=估算存塘尾数
estimated_biomass_kg=估算存塘生物量
estimated_saleable_kg=估算可售生物量
estimate_method=估算方法
estimate_relative_error=显式估算相对误差
confidence_level=可信度说明（非未经验证的统计置信度）
tool=采样工具
uniformity_cv=体重变异系数，用于描述整齐度
proportion=规格数量比例（0至1）
""".strip().splitlines()))

mapping("三、生产记录的详细内容/1. 清塘与放养前准备", "pond_preparations", """
清塘日期=occurred_at
塘口=pond_id
上一年度养殖批次=previous_cohort_id+previous_cohort_status
排干操作|晒塘操作|清淤操作|修整操作=operation
消毒剂或生石灰名称=disinfectant_product_id+products.product_name
消毒剂用量=dose_kg+disinfectant_status
消毒剂使用方式=application_method
注水时间=refill_at
水源=water_source
水位=water_level_m
水质检测结果=water_test_status
增氧设备检查|进排水设备检查=equipment_check
操作人=operator_id
审核人=reviewer_id
""")
mapping("三、生产记录的详细内容/4. 水质监测记录", "water_observations", """
监测时间=observed_at
塘口=pond_id
监测点=sample_point_id
采样深度=depth_m
水温=temperature_c
溶解氧=do_mg_l
pH=ph
氨氮|亚硝酸盐|硝酸盐|透明度|电导率|盐度|氧化还原电位|叶绿素=water_test_results.analyte_code+water_test_results.value+water_test_results.expression_basis
指标值=water_test_results.value
单位=water_test_results.unit
检测方法=water_test_results.method
检测仪器=water_test_results.instrument_id
传感器编号=device_id
安装位置=device_installations.position_description
校准日期=device_calibrations.started_at
自动或人工检测=method+water_samples.sampling_method
原始值=raw_ph+water_test_results.raw_value
校正值=ph+water_test_results.corrected_value
异常标记=quality_flag+environment_condition
数据缺失原因=missing_reason+water_test_results.missing_reason
复核结果=review_status+water_test_results.verified_by
""")
mapping("三、生产记录的详细内容/5. 日常巡塘记录", "patrol_events", """
巡塘时间=occurred_at
巡塘人=operator_id
巡塘天气=weather_id
鱼群游动行为|浮头行为=swimming
摄食行为=feeding_behavior
靠边行为=bank_gathering
水色=water_color
透明度=transparency_cm
气味=odor
藻类=algae
浮沫=foam
死鱼数量=dead_count
死鱼重量=dead_weight_kg
死鱼规格=dead_size_g
死鱼发现位置=discovery_point_id
增氧机运行状态=aerator_status
水泵运行状态=pump_status
投饵机运行状态=feeder_status
异常情况描述=exception_description
初步处理措施=action
""")
mapping("三、生产记录的详细内容/6. 生长采样记录", "growth_samples", """
采样日期=sampled_at
塘口=pond_id
养殖批次=cohort_id
采样方法=sampling_method
样本数量=sample_size
采样位置=sample_point_id
体长=growth_individuals.body_length_cm
全长=growth_individuals.total_length_cm
个体体重=growth_individuals.weight_g
分组统计=mean_weight_g+std_weight_g
平均体重=mean_weight_g
最小体重=min_weight_g
最大体重=max_weight_g
体重标准差=std_weight_g
各规格区间数量=growth_grade_items.count
各规格区间比例=growth_grade_items.proportion
规格达标率=grade_pass_rate
生长阶段=growth_stage
健康状况=growth_individuals.health_status
外观=growth_individuals.appearance
整齐度=uniformity_cv
估算存塘数量=estimated_count
估算存塘重量=estimated_biomass_kg
可售生物量=estimated_saleable_kg
采样工具=tool
记录人=operator_id
估算方法=estimate_method
可信度=confidence_level+estimate_relative_error
""")
mapping("三、生产记录的详细内容/7. 病害与健康记录", "health_cases", """
发现时间=discovered_at
塘口=pond_id
养殖批次=cohort_id
涉及数量=affected_count
摄食下降症状|浮头症状|异常游动症状=case_observations.behavior
体表病变=case_observations.skin_description
鳃病变=case_observations.gill_description
内脏病变=case_observations.viscera_description
发病率=incidence_rate
死亡数量=death_count
死亡速度=mortality_per_day
持续时间=duration_days
初步判断=preliminary_judgment
实验室诊断=diagnostic_tests.result+diagnostic_tests.diagnosis_status
病原检测结果=diagnostic_tests.pathogen_code+diagnostic_tests.result
诊断状态=diagnosis_status
检测机构=diagnostic_tests.lab_name
报告编号=diagnostic_tests.report_number
检测方法=diagnostic_tests.method
处置措施=action
恢复情况=recovery
复发情况=recurrence
""")
mapping("三、生产记录的详细内容/8. 用药与动保操作记录", "treatment_events", """
操作时间|起始日期=started_at
塘口=pond_id
批次=cohort_id
操作原因=operation_reason
药品或动保产品名称=product_name+product_parameter_status
批准或登记信息=approval_number+product_parameter_status
生产批号=manufacturer_lot+product_parameter_status
有效成分=active_ingredient+product_parameter_status
用量=dose+product_parameter_status
浓度=concentration+product_parameter_status
使用方法=method
疗程=course_days
使用对象=target_species
适用病害=target_disease
禁忌=contraindications
注意事项=precautions
停止日期=stopped_at
休药期=withdrawal_days+withdrawal_status
预计可出塘日期=earliest_harvest_date+withdrawal_status
操作人=operator_id
指导兽医或技术人员=advisor_id
药品采购成本=purchase_cost_yuan
使用效果=effect
不良反应=adverse_reaction
""")
mapping("三、生产记录的详细内容/9. 水质调控与设备运行", "water_operations", """
换水时间|加水时间|排水时间=started_at+operation
水量=inflow_m3+outflow_m3
增氧机启动时间=device_operations.started_at
增氧机停止时间=device_operations.ended_at
运行时长=device_operations.duration_h
耗电量=device_operations.energy_kwh
水质调节剂使用记录|微生态制剂使用记录=product_id+dose_kg+dose_status
设备故障=device_maintenance.fault
设备维修|设备保养=device_maintenance.operation
设备替换=device_maintenance.replacement_device_id
设备费用=device_maintenance.cost_yuan+device_maintenance.cost_status
自动设备控制指令=control_commands.command+control_commands.planned_at+control_commands.issued_at
执行结果=control_commands.executed_at+control_commands.result
异常报警=control_commands.alarm
操作前水质=do_before_mg_l
操作后水质=do_after_mg_l
操作前鱼群状态=fish_before
操作后鱼群状态=fish_after
""")
mapping("六、市场、销售与经济数据/1. 行情价格观测", "price_observations", """
品种=original_product_name+species_id+species_mapping_status
规格=grade
品质=quality_grade
鲜活状态=freshness
行情时间=observed_at
地区=region
市场=market_id
销售渠道=channel
塘口价|收购价|批发价|零售价=channel+price_yuan_per_kg
报价或实际成交=observation_kind
成交量=transaction_volume_kg+volume_status
是否含税=tax_included
运费=freight_included
包装=packaging_included
佣金=commission_included
数据来源=reference_source_id+origin_kind
采集时间=collected_at
可信度=credibility
替代鱼种价格|饲料原料价格=original_product_name+product_type+price_yuan_per_kg
""")
mapping("补充口径/检测", "water_test_results", """
测定对象=analyte_code
表达基准=expression_basis
方法=method
单位=unit
检出限=detection_limit
低于检出限标记=result_status
""")

FIELD_MEANINGS.update(dict(part.split("=",1) for part in """
table=所属逻辑表名称
record_id=所属逻辑表内记录主键
generation_run_id=本次可复现生成运行标识
rule_version=生成规则版本
seed=随机种子
scenario_id=场景标识
source_record_number=来源原始记录编号
source_page=来源原文页码
source_page_status=来源页码适用及取得状态
missing_status=缺失状态说明或对应字段状态的索引
modification_reason=修改原因；未修改时可空
water_observation_id=关联小时水质观测标识
is_fictional=是否虚构主体
year=场景年份
mode=计划或生成模式
technical_document_id=技术依据文件或配置标识
end_date=结束日期
event_table=事件所在逻辑表
event_record_id=事件表内记录主键
maintenance_history_status=塘口维修改造历史状态
maintenance_history_note=塘口维修改造历史说明
size_basis=转移平均规格计算依据
recovery_method=死鱼打捞方式
feed_brand=投喂饲料品牌
batch_manufacture_on=所用饲料批次生产日期
batch_expires_on=所用饲料批次到期日期
relative_path=相对于数据包根目录的实际文件路径
file_name=原文件名称
mime_type=媒体内容类型
file_size_bytes=实际文件字节数
sha256=实际文件SHA-256校验值
captured_at=采集拍摄或合成文件对应时间
capture_device=采集设备或程序化生成器
language=文件语言
license_status=授权和再分发条件
clinical_label_status=临床或疾病标签证据状态
intended_use=文件预定用途
usage_limitation=适用边界与使用限制
width_px=图像宽度
height_px=图像高度
duration_seconds=音视频时长
codec=音视频编码
sample_rate_hz=音频采样率
channels=音频通道数
audio_kind=音频内容类别（人声或测试信号）
pair_id=音频与配对文本组标识
attachment_id=附件文件索引标识
entity_table=附件关联实体所在逻辑表
entity_id=附件关联实体表内主键
relation_type=附件与业务对象关联类型
evidence_status=附件能否作为实际现场证据的状态
annotation_type=标注类型
annotation_text=标注内容
annotation_basis=标注依据
diagnostic_training_allowed=是否允许用作诊断训练标签
reviewer=审核主体或程序名称
version=数据或文件版本
frame_start=标注起始视频帧
frame_end=标注结束视频帧
layer_name=空间图层名称
geometry_kind=空间几何或栅格类型
coordinate_order=坐标轴顺序
resolution_m=空间分辨率（米）
resolution_degrees=空间分辨率（经纬度角）
accuracy_m=空间定位精度（米）
accuracy_status=定位精度核实状态
scale_status=比例尺适用状态
source=图层来源
feature_count=矢量空间要素数
bbox=覆盖边界包络（西南东北经纬度）
coverage=图层覆盖范围说明
document_id=技术文档实体标识
published_at=文档发布日期
effective_from=版本生效日期
effective_until=版本失效日期
replaces_version_id=被本版本替代的版本标识
change_summary=版本变更说明
page_reference=来源或适用页码说明
title=技术文档标题
document_type=技术文档类型
publisher=发布机构
current_version=当前版本号
current_version_id=当前文档版本标识
applicable_region=适用地区
applicable_mode=适用养殖模式
full_text_path=实际全文文件路径
source_url=外部来源地址；本地原创合成可不适用
source_status=文档来源身份状态
authority_status=文档权威性与适用性状态
""".strip().splitlines()))
FK_TARGETS.update({'water_observation_id':'water_observations','weather_id':'weather_observations','command_id':'control_commands','technical_plan_id':'production_plans','current_version_id':'document_versions','replaces_version_id':'document_versions',**{k:'persons' for k in ['recorder_id','reviewer_id','operator_id','advisor_id','sampler_id','verified_by','responsible_person_id','operation_person_id']}})

mapping("一、所有数据共同需要的通用字段","record_provenance","""
记录ID=record_id
养殖场ID=farm_id
塘口ID=pond_id
养殖批次ID=cohort_id
操作事件ID=event_registry.event_record_id
实际发生时间=occurred_at
记录时间=recorded_at
入库时间=ingested_at
数据更新日期=updated_at
记录人=recorder_id
审核人=reviewer_id
数据来源系统=source_system
设备或供应方=water_observations.device_id+stocking_events.supplier_id
塘口位置=ponds.geometry_id
采样点位置=water_samples.sample_point_id
设备位置=devices.position_id
经度=farms.longitude
纬度=farms.latitude
坐标系=farms.crs
指标值=water_test_results.value
单位=water_test_results.unit
检测方法=water_test_results.method
量纲=water_test_results.unit+water_test_results.expression_basis
图片链接|视频链接|检测报告链接|合同链接|发票链接=attachments.relative_path+attachments.category+attachment_links.entity_table+attachment_links.entity_id
是否异常=water_observations.quality_flag+water_observations.environment_condition
是否缺失=missing_status
是否估算=is_estimated
质量标记=water_observations.quality_flag
修改原因=modification_reason
原始记录编号=source_record_number
来源页码=source_page+source_page_status
凭证号=cash_transactions.bank_reference
版本=rule_version
审核状态=review_status
投喂记录ID=feeding_events.id
用药记录ID=treatment_events.id
病害记录ID=health_cases.id
销售记录ID=sales.id
成本记录ID=cost_entries.id
""")
for atom in EXTRAS['补充口径/合成身份'].split('|'):
    MAP[('补充口径/合成身份',atom)]=['record_provenance.'+atom]
mapping("补充口径/时间","record_provenance","""
实际发生时间=occurred_at
人工记录时间=recorded_at
上传时间=uploaded_at
采集时间=price_observations.collected_at
入库时间=ingested_at
来源时区=source_timezone
时间精度=time_precision
设备安装时间=device_installations.installed_at
设备拆除时间=device_installations.removed_at
设备校准时间=device_calibrations.started_at
换机有效时间=device_installations.installed_at+device_installations.removed_at+device_maintenance.replacement_device_id
""")
mapping("二、基础主数据/3. 基础字典","dictionaries","""
鱼苗目录|饲料目录=products.product_type+products.product_name
药品目录|疫苗目录|动保产品目录=domain+code+label+status
病害字典|症状字典|病原字典|检测项目字典|规格等级字典|品质等级字典|销售渠道字典|成本科目字典|收入类型字典|费用分摊方式字典=domain+code+label
供应商主体|客户主体|收购商主体|物流企业主体|检测机构主体=partners.partner_type+partners.name
""")
for atom in EXTRAS['补充口径/缺失'].split('|'):
    MAP[('补充口径/缺失',atom)]=['dictionaries.domain','dictionaries.code','dictionaries.label']
mapping("五、图像、视频及其他多模态数据/附件元数据","attachments","""
文件ID=id
关联塘口=pond_id
关联批次=cohort_id
关联事件=attachment_links.entity_table+attachment_links.entity_id
拍摄时间=captured_at
拍摄设备=capture_device
文件类型=mime_type
存储地址=relative_path
标注内容=media_annotations.annotation_text
审核状态=review_status
文件校验值=sha256
""")
mapping("七、技术文档与外部知识/文档元数据","documents","""
全文=full_text_path
标题=title
发布机构=publisher
版本=current_version+document_versions.version
发布日期=published_at
适用地区=applicable_region
适用养殖模式=applicable_mode
来源地址=source_url+full_text_path+source_status
页码=document_versions.page_reference
审核状态=review_status
""")
mapping("四、GIS 与空间数据/空间元数据","spatial_layer_registry","""
采集时间=captured_at
坐标参考系=crs
比例尺=scale_status
空间分辨率=resolution_m+resolution_degrees
来源=source
版本=version
精度=accuracy_m+accuracy_status
覆盖范围=bbox+coverage
""")
mapping("补充口径/文档附件","attachments","""
授权或获取条件=license_status+documents.license_status
语言=language+documents.language
有效废止替代状态=document_versions.status+document_versions.replaces_version_id
文件真实存在状态=relative_path+sha256+file_size_bytes
标注依据=media_annotations.annotation_basis
诊断状态=media_annotations.diagnosis_status+clinical_label_status
""")
mapping("三、生产记录的详细内容/11. 分塘、并塘与转塘","transfer_events","转移规格=mean_weight_g+size_basis")
mapping("三、生产记录的详细内容/10. 死亡与无害化处理","disposal_events","打捞方式=recovery_method\n运输方式=transport_method")
mapping("二、基础主数据/1. 养殖场与塘口","ponds","历史维修记录|历史改造记录=maintenance_history_status+maintenance_history_note")

# Asset categories express FORMAT examples. Their presence never proves that a
# picture is a field photograph, a pathogen is diagnosed, or a text is an ASR result.
MEDIA_CATEGORIES = {
    '鱼体照片':['fish_body'],'鳃照片':['gill'],'内脏照片':['viscera'],'病害部位照片':['gill','viscera'],
    '显微病原图像':['microscopy'],'组织切片图像':['histology'],'正常摄食视频':['feeding'],
    '异常游动视频':['swimming'],'浮头视频':['surfacing'],'水下摄像':['underwater'],
    '固定监控':['surveillance'],'无人机影像':['drone'],'巡塘语音':['patrol_tts_speech','patrol_speech'],
    '专家录音':['expert_tts_speech','expert_speech'],'自动转写文本':['automatic_transcription'],
    '检测报告扫描件':['lab_report'],'处方扫描件':['prescription_placeholder'],'合同扫描件':['contract'],'发票扫描件':['invoice'],
    '传感器曲线图':['curve'],'生产报表图':['production_chart']
}
GIS_FIELDS = {
    '养殖场边界':('farm_boundary','geometry'),'塘口边界':('ponds','geometry'),
    '水源':('water_network','geometry'),'河道':('water_network','geometry'),'进水口':('intakes_outlets_sampling','geometry'),
    '排水口':('intakes_outlets_sampling','geometry'),'采样点位置':('intakes_outlets_sampling','geometry'),
    '传感器位置':('devices','geometry'),'增氧机位置':('devices','geometry'),'投饵机位置':('devices','geometry'),
    '病害发现位置':('discovery_points','geometry'),'死鱼发现位置':('discovery_points','geometry'),
    '塘口面积时点变化':('water_surface_states','properties.pond_area_m2'),
    '水位时点变化':('water_surface_states','properties.water_level_m'),'水面时点变化':('water_surface_states','geometry'),
    '周边河流':('water_network','geometry'),'周边湖泊':('water_network','geometry'),'土地利用':('land_use','properties.land_use'),
    '行政区位':('administrative_layout','properties.administrative_name'),'气象站位置':('weather_grid','geometry'),
    '降雨网格':('weather_grid','properties.precipitation_scenario_mm'),'高温灾害网格':('weather_grid','properties.heat_scenario_air_temperature_c'),
    '洪水风险区域':('risk_zones','properties.hazard'),'干旱风险区域':('risk_zones','properties.hazard'),
    '饲料厂位置':('suppliers_customers_labs_markets','geometry'),'苗种场位置':('suppliers_customers_labs_markets','geometry'),
    '检测机构位置':('suppliers_customers_labs_markets','geometry'),'批发市场位置':('suppliers_customers_labs_markets','geometry'),
    '加工厂位置':('suppliers_customers_labs_markets','geometry'),'运输路线':('transport_routes','geometry'),
    '运输距离':('transport_routes','properties.distance_km'),'运输时间':('transport_routes','properties.duration_minutes'),
    '进水口GIS':('intakes_outlets_sampling','geometry'),'排水口GIS':('intakes_outlets_sampling','geometry'),'设备位置GIS':('devices','geometry')
}
FIELD_MEANINGS.update(dict(part.split('=',1) for part in """
centroid_longitude=塘口几何中心经度
centroid_latitude=塘口几何中心纬度
suspended_session_count=因环境事件暂停的投喂次数
suspended_session_local_time=暂停投喂的本地时间
related_environment_scenario=对应环境事件场景标识
environment_value_basis=投喂上下文环境数值来源
inventory_selection_policy=领用饲料库存批次选择规则
lot_opening_quantity=本投入品批次变动前库存数量
lot_closing_quantity=本投入品批次变动后库存数量
lot_opening_value_cny=本投入品批次变动前库存价值
lot_closing_value_cny=本投入品批次变动后库存价值
recognition_method=成本费用确认方式
expense_contract_start=费用合同覆盖期间开始日
expense_contract_end=费用合同覆盖期间结束日
renovation_status=塘口改造状态
cost_basis=费用依据与是否已纳入其它成本说明
technical_document_path=技术依据配置或文件相对路径
url=来源网页或接口地址
local_path=来源原件或配置在数据包内的路径
access_conditions=来源获取与使用条件
retrieved_at=原件获取时间
use_boundary=公开来源的适用边界
voice_name=语音合成引擎的声音名称
tts_backend=语音合成引擎名称
transcription_method=配对文本产生方式；mock不等于实际语音识别
speaker_identity_status=说话者身份状态；虚构角色不等于真实专家
expiry_status=有效期资料或是否到期状态
usability_status=期末库存可用状态（账面有货不等于可用）
available_quantity=在所列适用条件下可用库存数量
expiry_assessment=到期评估说明
disposal_status=库存报废或处置状态
valuation_basis=库存价值口径
source_inventory_movement_id=用于确定期末批次状态的库存流水标识
mortality_event_ids=当次巡塘关联死亡事件标识列表
population_denominator=发病涉及比例计算所用存塘尾数分母
denominator_basis=发病涉及比例的分母来源依据
purchase_time_basis=采购单记账时点口径；可晚于实物到货时间
transaction_time_basis=采购明细时间属于单据记账而非货物到场
""".strip().splitlines()))
FIELD_MEANINGS.update({'weather_observations.model':'天气再分析模型或明确季节性假设模型','devices.model':'虚构设备型号','cost_entries.category':'成本科目','attachments.category':'附件内容与格式测试类别','media_annotations.label':'合成文件主题标签；非确诊标签','dictionaries.label':'字典代码中文名称','sources.title':'参考来源名称','products.assumed_unit_price_cny':'每个产品unit单位的假设单价（人民币）'})
FIELD_MEANINGS.update({'purchases.received_at':'采购货物实物到货时间（区别于采购单据记账时间）','persons.role':'人员职责（记录员或审核员）','water_test_results.method':'水质检测方法','diagnostic_tests.method':'诊断检测方法','treatment_events.method':'施用或非药物处置方法','water_observations.method':'水质监测方法','device_calibrations.method':'设备校准方法','disposal_events.method':'无害化处理方式','harvests.method':'捕捞方式'})
FK_TARGETS['reference_source_id']='sources'
FK_TARGETS['source_inventory_movement_id']='inventory_movements'
MEDIA_CATEGORIES['巡塘语音']=['synthetic_patrol_audio']
MEDIA_CATEGORIES['专家录音']=['synthetic_expert_narration_audio']

EVENT_MEDIA_RULES = {
    ('1. 清塘与放养前准备','现场照片'):(['pond_preparation','preparation_scene'],['pond_preparations']),
    ('1. 清塘与放养前准备','相关凭证'):(['pond_preparation_voucher','preparation_voucher','contract'],['pond_preparations']),
    ('2. 苗种采购与投放记录','到场照片视频'):(['seed_arrival','arrival'],['stocking_events']),
    ('2. 苗种采购与投放记录','开箱照片视频'):(['seed_unpacking','unpacking'],['stocking_events']),
    ('2. 苗种采购与投放记录','投放过程照片视频'):(['stocking','seed_stocking'],['stocking_events']),
    ('3. 投喂记录','摄食视频'):(['feeding'],['feeding_events']),
    ('3. 投喂记录','水下视频'):(['underwater'],['feeding_events','ponds']),
    ('3. 投喂记录','现场照片'):(['fish_body','feeding_scene'],['feeding_events']),
    ('4. 水质监测记录','水色照片'):(['water_color'],['water_samples','water_observations','ponds','feeding_events']),
    ('4. 水质监测记录','检测试纸照片'):(['water_test_strip','test_strip'],['water_samples','water_test_results']),
    ('4. 水质监测记录','实验室报告'):(['lab_report'],['water_test_results','water_samples','diagnostic_tests']),
    ('5. 日常巡塘记录','现场照片'):(['patrol_scene','fish_body','water_color'],['patrol_events','ponds']),
    ('5. 日常巡塘记录','视频'):(['surveillance','surfacing','swimming'],['patrol_events','ponds']),
    ('5. 日常巡塘记录','音频'):(['patrol_tone_placeholder','patrol_tts_speech','patrol_speech','synthetic_patrol_audio'],['patrol_events','ponds']),
    ('5. 日常巡塘记录','语音巡塘记录'):(['patrol_tts_speech','patrol_speech','synthetic_patrol_audio'],['patrol_events','ponds']),
    ('6. 生长采样记录','样本照片'):(['growth_sample','fish_body'],['growth_samples']),
    ('7. 病害与健康记录','病鱼照片'):(['gill','viscera','fish_body'],['health_cases']),
    ('7. 病害与健康记录','病鱼视频'):(['health_swimming','swimming','surfacing'],['health_cases']),
    ('7. 病害与健康记录','显微图像'):(['microscopy'],['health_cases']),
    ('7. 病害与健康记录','检测报告'):(['lab_report'],['diagnostic_tests','health_cases']),
    ('8. 用药与动保操作记录','药品包装照片'):(['drug_packaging_placeholder'],['treatment_events']),
    ('8. 用药与动保操作记录','处方'):(['prescription_placeholder'],['treatment_events']),
    ('8. 用药与动保操作记录','操作现场照片'):(['treatment_scene'],['treatment_events']),
    ('8. 用药与动保操作记录','操作凭证'):(['treatment_voucher','prescription_placeholder'],['treatment_events']),
    ('10. 死亡与无害化处理','现场照片'):(['disposal_scene','mortality_disposal'],['mortality_events','disposal_events']),
    ('12. 捕捞与出塘记录','捕捞图片视频'):(['harvest','harvest_scene'],['harvests']),
    ('12. 捕捞与出塘记录','分拣图片视频'):(['sorting','harvest_sorting'],['harvests','harvest_grade_items']),
    ('12. 捕捞与出塘记录','称重图片视频'):(['weighing','harvest_weighing'],['harvests','harvest_grade_items']),
    ('12. 捕捞与出塘记录','装车图片视频'):(['loading','harvest_loading'],['harvests']),
}


def apply_asset_coverage(row,tables,out_dir):
    section,atom=row['source_section'],row['atomic_field']; cats=None; entity_tables=None
    if section=='五、图像、视频及其他多模态数据': cats=MEDIA_CATEGORIES.get(atom,[])
    if section.startswith('三、'):
        pair=(section.split('/',1)[1],atom)
        if pair in EVENT_MEDIA_RULES: cats,entity_tables=EVENT_MEDIA_RULES[pair]
    if atom in {'无人机航拍','塘口正射影像'}:
        cats=['drone'] if atom=='无人机航拍' else ['orthomosaic']
    if cats is not None:
        links=tables.get('attachment_links',[])
        matches=[r for r in tables.get('attachments',[]) if r.get('category') in cats and (not entity_tables or any(a.get('attachment_id')==r.get('id') and a.get('entity_table') in entity_tables for a in links))]
        existing=[r for r in matches if (out_dir/r['relative_path']).is_file()]
        row.update(target_files='reference/baseline/attachments.csv;reference/baseline/attachment_links.csv;reference/baseline/media_annotations.csv',target_fields='attachments.category;attachments.relative_path;attachment_links.entity_table;attachment_links.entity_id;media_annotations.annotation_basis',scenario_id='F01_2025_closed_cycle',basis='具体附件category与事件关联共同核对；所有匹配文件真实存在',example_record_ids=';'.join(r['id'] for r in existing[:6]),asset_paths=';'.join(r['relative_path'] for r in existing[:6]),structural_coverage=bool(existing))
        if existing:
            row.update(status='合成格式样例',semantic_boundary='仅程序化示意/TTS/测试文件。非真实现场照片、扫描、专家证据或确诊标签。',gap='已覆盖文件格式与关联；真实现场内容及专业标签待取得。')
        else:
            row.update(status='待取得资料',gap='没有同时满足类别与事件关联的有效文件：'+','.join(cats))
    if (section.startswith('四、') and '/空间元数据' not in section) or (section=='二、基础主数据/1. 养殖场与塘口' and atom.endswith('GIS')):
        if atom in GIS_FIELDS:
            layer,field=GIS_FIELDS[atom];path=out_dir/'assets'/'gis'/(layer+'.geojson')
            features=json.loads(path.read_text('utf-8')).get('features',[]) if path.exists() else []
            def has_field(f):
                val=f
                for part in field.split('.'):
                    if not isinstance(val,dict) or part not in val:return False
                    val=val[part]
                return val is not None
            matching=[f for f in features if has_field(f)]
            predicates={
                '进水口':lambda p:p.get('point_kind')=='intake','进水口GIS':lambda p:p.get('point_kind')=='intake',
                '排水口':lambda p:p.get('point_kind')=='outlet','排水口GIS':lambda p:p.get('point_kind')=='outlet',
                '采样点位置':lambda p:p.get('point_kind')=='sampling_point',
                '传感器位置':lambda p:p.get('device_kind')=='multiparameter_sensor',
                '增氧机位置':lambda p:p.get('device_kind')=='aerator','投饵机位置':lambda p:p.get('device_kind')=='feeder',
                '病害发现位置':lambda p:p.get('entity_table')=='health_cases','死鱼发现位置':lambda p:p.get('entity_table')=='mortality_events',
                '周边河流':lambda p:p.get('water_type')=='fictional_river','河道':lambda p:p.get('water_type')=='fictional_river',
                '周边湖泊':lambda p:p.get('water_type')=='fictional_lake','气象站位置':lambda p:'station_kind' in p,
                '洪水风险区域':lambda p:'flood' in p.get('hazard',''),'干旱风险区域':lambda p:'drought' in p.get('hazard',''),
                '饲料厂位置':lambda p:p.get('party_kind')=='feed_supplier','苗种场位置':lambda p:p.get('party_kind')=='seed_supplier',
                '检测机构位置':lambda p:p.get('party_kind')=='laboratory','批发市场位置':lambda p:'wholesale_market' in p.get('site_kind',''),
                '加工厂位置':lambda p:'processing_plant' in p.get('site_kind',''),
            }
            if atom in predicates:matching=[f for f in matching if predicates[atom](f.get('properties',{}))]
            row.update(target_files='reference/baseline/spatial_layer_registry.csv;assets/gis/'+layer+'.geojson',target_fields='spatial_layer_registry.relative_path;spatial_layer_registry.layer_name',asset_fields='features[].'+field,asset_paths='assets/gis/'+layer+'.geojson',example_record_ids=';'.join(str(f.get('id')) for f in matching[:6]),structural_coverage=bool(matching),status='合成空间格式样例' if matching else '待补空间字段',gap='坐标、风险、路线与水位为虚构布局或假设，非实测、非风险评估。' if matching else '指定图层或子字段不存在',semantic_boundary='通过明确GeoJSON嵌套路径承载；CSV仅保存索引，不用经纬度代替几何。')
    if section=='七、技术文档与外部知识':
        keywords={'苗种技术规程':'苗种','成鱼养殖技术规程':'投喂','病害防控技术规程':'健康','企业标准':'规范','饲料说明书':'饲料','药品说明书':'用药','动保产品说明书':'用药','科研论文':'研究','试验报告':'研究','气象知识':'气象','供需知识':'市场','原料行情知识':'市场'}
        kw=keywords.get(atom);docs=[d for d in tables.get('documents',[]) if kw and kw in d.get('title','') and (out_dir/d['full_text_path']).is_file()]
        row.update(target_files='reference/baseline/documents.csv;reference/baseline/document_versions.csv',target_fields='documents.title;documents.document_type;documents.full_text_path;documents.authority_status;document_versions.page_reference',example_record_ids=';'.join(d['id'] for d in docs[:4]),asset_paths=';'.join(d['full_text_path'] for d in docs[:4]),structural_coverage=bool(docs),status='合成文档格式样例' if docs else '待取得资料',gap='全文是原创合成数据规范/研究示例，不能当作真实技术规程、发表论文、产品说明或权威法规。' if docs else '本版未提供该类权威或合成全文；保留此原子项待取得。')
        if atom=='地方标准':
            source=next((s for s in tables.get('sources',[]) if s['id']=='S01'),None)
            if source and (out_dir/source['local_path']).exists():
                row.update(target_files='reference/baseline/sources.csv',target_fields='sources.id;sources.title;sources.url;sources.local_path;sources.access_conditions;sources.version',asset_paths=source['local_path'],example_record_ids='S01',structural_coverage=True,status='已取得公开样例',gap='仅有表式和技术参考；不是生产流水。2026标准仅为2025虚构场景的后续设计依据；未确认开放再分发许可。')
    return row


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def build_requirements(source_dir, out_dir):
    source_file = source_dir / "武昌鱼养殖知识库数据源与字段清单.md"
    source_lines = source_file.read_text(encoding="utf-8").splitlines()
    section, subsection = "", ""
    original = {}
    for line_no, line in enumerate(source_lines, 1):
        if line.startswith("## "):
            section, subsection = line[3:], ""
        elif line.startswith("### "):
            subsection = line[4:]
        elif line.startswith("- ") and section:
            key = section + ("/" + subsection if subsection else "")
            original.setdefault(key, []).append((line_no, line[2:]))
    requirements = []
    for section, atom_lines in ATOMS.items():
        originals = original.get(section, [])
        if len(originals) != len(atom_lines):
            raise ValueError(f"Source bullets changed: {section}: {len(originals)} != {len(atom_lines)}")
        for (line_no, line), atom_line in zip(originals, atom_lines):
            for atom in atom_line.split("|"):
                requirements.append({"requirement_id":f"REQ{len(requirements)+1:04d}","source_file":source_file.name,"source_section":section,"source_line":line_no,"original_item":line,"atomic_field":atom})
    for section, atoms in EXTRAS.items():
        file_name = source_file.name if section[0] in "四五七" else "L1数据清单审阅与模拟数据建议.md"
        for atom in atoms.split("|"):
            requirements.append({"requirement_id":f"REQ{len(requirements)+1:04d}","source_file":file_name,"source_section":section,"source_line":"","original_item":atoms.replace("|","、"),"atomic_field":atom})
    write_json(out_dir / "schemas" / "coverage_requirements.json", requirements)
    return requirements


def columns_of(rows):
    return list(dict.fromkeys(k for r in rows for k in r))


def infer_type(values, column):
    vals = [v for v in values if v is not None and v != ""]
    if not vals:
        explicit = {"withdrawal_days":"integer","course_days":"integer","dose":"number","concentration":"number","dead_size_g":"number","earliest_harvest_date":"date","effective_until":"date","removed_at":"datetime","left_at":"datetime"}
        if column in explicit:
            return explicit[column]
        if column.endswith(("_kg","_g","_m","_m2","_m3","_yuan","_cny","_mg_l")):
            return "number"
        if column.endswith(("_count","_bytes","_px","_hz","_seconds")):
            return "integer"
        return "string"
    if all(isinstance(v,bool) for v in vals):
        return "boolean"
    if all(isinstance(v,int) and not isinstance(v,bool) for v in vals):
        return "integer"
    if all(isinstance(v,(int,float)) and not isinstance(v,bool) for v in vals):
        return "number"
    if all(isinstance(v,str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}",v) for v in vals):
        return "date"
    if all(isinstance(v,str) and re.match(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}",v) for v in vals):
        return "datetime"
    return "string"


def field_unit(table, col, rows):
    explicit={'feature_count':'个','suspended_session_count':'次','frequency_per_day':'次/日','frame_start':'frame','frame_end':'frame','channels':'channel','year':'year','seed':'1（无量纲整数）','population_denominator':'尾'}
    if col in explicit:return explicit[col]
    if col in ("value","corrected_value","raw_value","detection_limit","quantity","quantity_delta","opening_quantity","closing_quantity","available_quantity","lot_opening_quantity","lot_closing_quantity","unit_price_cny","assumed_unit_price_cny"):
        units=sorted({str(r.get('unit')) for r in rows if r.get('unit')})
        return ("CNY/" if col in ("unit_price_cny","assumed_unit_price_cny") else "")+(";".join(units) if units else "见关联产品unit或本表单位字段")
    if col in ("longitude","latitude","centroid_longitude","centroid_latitude","grid_longitude","grid_latitude","requested_longitude","requested_latitude","spatial_resolution_degree"):
        return "degree"
    if col in ("ph","raw_ph","ph_correction","reference_ph","offset_ph"):
        return "pH（无量纲）"
    if col in ("count","sample_size","estimated_count","mortality_per_day") or col.endswith('_count'):
        return "尾/日" if col=='mortality_per_day' else "尾"
    if col.endswith(("_ratio","_rate","_relative_error")) or col in ("proportion","uniformity_cv"):
        return "1（比例0–1）"
    for suffix,unit in [("_cny_per_kg","CNY/kg"),("_yuan_per_kg","CNY/kg"),("_fish_per_mu","尾/亩"),("_w_m2","W/m²"),("_km_h","km/h"),("_mg_l","mg/L"),("_cny","CNY"),("_yuan","CNY"),("_pct","%（0–100）"),("_kg","kg"),("_g","g"),("_m3","m³"),("_m2","m²"),("_mu","亩"),("_cm","cm"),("_mm","mm"),("_m","m"),("_kwh","kWh"),("_kw","kW"),("_hours","h"),("_h","h"),("_days","day"),("_c","°C"),("_bytes","byte"),("_px","px"),("_hz","Hz"),("_seconds","s")]:
        if col.endswith(suffix): return unit
    return "不适用（标识/分类/说明）"


def value_kind(table, col):
    if col=='id' or col.endswith(('_id','_at','_date','_on')) or col in {'origin_kind','is_synthetic','rule_version','generation_run_id','seed','scenario_id','source_timezone','time_precision','source_system','review_status','quality_flag','missing_reason','missing_status','record_id','table'}:
        return "原始元数据（生成记录的标识、时间、来源或质量说明）"
    if table in ("fish_daily_balance","harvest_sale_allocations","cost_allocations","cash_allocations","settlements") or col in {"daily_total_kg","cost_cny","total_cost_cny","weight_ratio","allocation_ratio","mean_weight_g","min_weight_g","max_weight_g","std_weight_g","grade_pass_rate","uniformity_cv","proportion","sha256","file_size_bytes"}:
        return "派生（以模拟业务或实际生成文件计算）"
    if col.startswith('estimated_') or col in {'estimate_error_kg','estimate_relative_error','energy_kwh','closing_biomass_kg','growth_weight_kg'}:
        return "估算（模拟场景假设，非现场真值）"
    if table in ("water_observations","water_test_results","growth_individuals","patrol_events","case_observations","price_observations") and infer_type([],col)!="datetime":
        return "观测字段（场内值均为规则模拟）"
    if table=='weather_observations':
        return "外部再分析或规则模拟（逐行origin_kind区分）"
    return "原始（生成器业务记录或元数据，非真实现场记录）"


def relation_for(table, col, tables):
    if col=='sample_id':
        target='growth_samples' if table in {'growth_individuals','growth_grade_items'} else 'water_samples'
    else: target=FK_TARGETS.get(col)
    if target and target in tables:
        return {'field':col,'references':{'table':target,'field':'id'},'nullable':True}
    return None


def build_dictionary(tables, coverage):
    dictionary=[]; schema={"schema_version":"1.0","encoding":"UTF-8 (schemas CSV may include BOM)","delimiter":",","null_value":"","timezone":"Asia/Shanghai","authoritative_format":"CSV","csv_scope":"reference/baseline","provenance":"record_provenance joins by table + record_id where applicable","tables":{}}
    unknown=[]; key_errors=[]
    source_atoms={}
    for req in coverage:
        for ref in req.get('target_fields','').split(';'):
            if ref: source_atoms.setdefault(ref,[]).append(req['atomic_field'])
    for table,rows in tables.items():
        cols=columns_of(rows); fields={}; fks=[]
        ids=[str(r.get('id')) for r in rows]
        if len(ids)!=len(set(ids)) or any(r.get('id') in (None,'') for r in rows): key_errors.append(table)
        for col in cols:
            values=[r.get(col) for r in rows]; dtype=infer_type(values,col)
            nnull=sum(v is None or v=='' for v in values)
            meaning=FIELD_MEANINGS.get(table+'.'+col,FIELD_MEANINGS.get(col))
            if meaning is None:
                meaning="语义待补充审核："+col;unknown.append(table+'.'+col)
            required="必填且全表唯一" if col=='id' else ("此类记录存在时必填" if not nnull else "条件必填：适用且取得资料时填写；空值依据配套状态/原因或record_provenance解释")
            enum=[]
            if dtype=='boolean': enum=[False,True]
            elif dtype=='string' and (col.endswith(('_status','_type','_kind','_basis','_grade')) or col in {'role','status','grade','channel','domain','code','unit','currency','movement_type','direction','analyte_code','observation_kind','quality_flag','measurement_context','environment_condition'}):
                enum=sorted({str(v) for v in values if v not in (None,'')})
                if len(enum)>60: enum=[]
            relation=relation_for(table,col,tables)
            relation_text=""
            if relation:
                fks.append(relation);relation_text=relation['references']['table']+'.id'
            elif col in {'entity_id','source_id','record_id'}:
                relation_text="多态关联：与同记录entity_table/source_type/table_name共同解析；禁止单独猜测外键"
            elif col=='event_id': relation_text="业务事件关联标识；可为本表主键或关联事件；非单一父表外键"
            elif col in {'recorder_id','reviewer_id','operator_id','advisor_id','sampler_id','verified_by','responsible_person_id','operation_person_id'}:
                relation_text="dictionaries.code WHERE domain='staff'（若来源为虚构人员）；条件适用"
            checks=["非空" if col=='id' or not nnull else "空值不能替换为0",f"可解析为{dtype}"]
            if col=='id': checks.append('主键唯一')
            if relation: checks.append('非空值必须存在于'+relation_text)
            if col in {'proportion','allocation_ratio','weight_ratio','grade_pass_rate','incidence_rate','transport_mortality_rate'}: checks.append('0 <= value <= 1')
            if col in {'coarse_protein_pct','relative_humidity_pct'}: checks.append('0 <= value <= 100')
            if col=='sha256': checks.append('64位十六进制且与文件字节摘要一致')
            if dtype in {'date','datetime'}: checks.append('ISO8601；时间顺序按业务有效期校验')
            entry={'table':table,'column':col,'source_field_name':col,'target_field_name':col,'original_source_items':';'.join(dict.fromkeys(source_atoms.get(table+'.'+col,[]))), 'chinese_meaning':meaning,'data_type':dtype,'required_condition':required,'unit':field_unit(table,col,rows),'enum_values':json.dumps(enum,ensure_ascii=False) if enum else '', 'enum_scope':'本版生成值集合，非通用行业强制枚举' if enum else '', 'relation':relation_text,'value_kind':value_kind(table,col),'validation_rules':'; '.join(checks),'value_source':'生成器业务规则及scenario参数；外部观测以origin_kind/reference_source_id区分','nullable':bool(nnull),'null_count':nnull,'non_null_count':len(rows)-nnull,'definition_status':'reviewed' if col in FIELD_MEANINGS or table+'.'+col in FIELD_MEANINGS else 'pending'}
            dictionary.append(entry)
            base='string' if dtype in {'date','datetime'} else dtype
            fs={'type':[base,'null'] if nnull else base,'description':meaning,'unit':entry['unit'],'required_condition':required,'source_field':col,'value_kind':entry['value_kind'],'checks':checks}
            if dtype in {'date','datetime'}: fs['format']='date' if dtype=='date' else 'date-time'
            if enum: fs['enum']=enum+([None] if nnull else [])
            fields[col]=fs
        schema['tables'][table]={'path':f'reference/baseline/{table}.csv','row_count':len(rows),'primary_key':['id'],'foreign_keys':fks,'columns':fields,'required':[c for c in cols if c=='id' or all(r.get(c) not in (None,'') for r in rows)]}
    return dictionary,schema,unknown,key_errors


def build_coverage(requirements,tables,out_dir):
    available={t:set(columns_of(rows)) for t,rows in tables.items()}
    result=[]
    for req in requirements:
        section,atom=req['source_section'],req['atomic_field']; refs=MAP.get((section,atom),[])
        existing=[x for x in refs if x.split('.',1)[0] in available and x.split('.',1)[1] in available[x.split('.',1)[0]]]
        missing=[x for x in refs if x not in existing]
        row={**req,'target_files':';'.join(dict.fromkeys('reference/baseline/'+x.split('.',1)[0]+'.csv' for x in existing)),'target_fields':';'.join(existing),'scenario_id':'F01_2025_closed_cycle','basis':'原清单定义 + 显式生成规则；不代表2025真实生产记录','status':'由规则模拟' if existing and not missing else ('部分覆盖' if existing else '待补字段或资料'),'structural_coverage':bool(existing and not missing),'semantic_boundary':'所有场内数据为虚构场景。条件空值不等于0。','gap':';'.join(missing) if missing else ('' if existing else '尚无逐项可核对字段映射；不以泛化描述代替该原子项')}
        if section=='三、生产记录的详细内容/8. 用药与动保操作记录' and atom in {'药品或动保产品名称','批准或登记信息','生产批号','有效成分','用量','浓度','休药期','预计可出塘日期','禁忌','注意事项'} and existing:
            row.update(status='条件不适用/产品依据待核',gap='本版未实际施药。无具体有效产品说明与处方依据，参数保留空值或待核，不构成处方。')
        if section=='三、生产记录的详细内容/9. 水质调控与设备运行' and atom in {'水质调节剂使用记录','微生态制剂使用记录','设备替换'} and existing:
            row.update(status='条件不适用',gap='场景未发生该投入或设备替换；保留可空字段与状态，未虚构施用。')
        if atom=='并塘父子批次关系' and existing: row.update(status='关系结构覆盖/本版无并塘',gap='有父子批次和转移关联，未生成并塘事件；不可把分塘冒称并塘。')
        if existing and not row['status'].startswith('条件不适用') and all(all(r.get(ref.split('.',1)[1]) in (None,'') for r in tables[ref.split('.',1)[0]]) for ref in existing):
            row.update(status='字段已定义/资料未取得',gap='本版全部为空；资料缺失或不适用需由相应状态说明。')
        row=apply_asset_coverage(row,tables,out_dir)
        if section=='六、市场、销售与经济数据/1. 行情价格观测' and atom in {'塘口价','收购价','批发价','零售价'}:
            expected={'塘口价':'pond_gate','收购价':'acquisition','批发价':'wholesale','零售价':'retail'}[atom]
            if not any(r.get('channel')==expected for r in tables.get('price_observations',[])):
                row.update(status='字段已定义/场景未覆盖',gap='行情channel未包含'+expected,structural_coverage=False)
        row['scenario_example_coverage']=row['structural_coverage']
        if row['status']=='字段已定义/资料未取得':row['scenario_example_coverage']=False
        # A schema can express a record even when its professional source
        # material is absent. Keep these dimensions separate and never turn
        # schema availability into a claim that the missing file exists.
        target_refs=[x for x in row.get('target_fields','').split(';') if x]
        row['structural_coverage']=bool(target_refs) and all('.' in x and x.split('.',1)[0] in available and x.split('.',1)[1] in available[x.split('.',1)[0]] for x in target_refs)
        row['source_material_status']='公开原件已取得，按许可边界使用' if row['status']=='已取得公开样例' else ('真实资料待取得；仅合成格式样例' if '格式样例' in row['status'] else ('资料待取得' if row['status']=='待取得资料' else '模拟业务记录或条件空值，非真实现场材料'))
        if section=='三、生产记录的详细内容/8. 用药与动保操作记录' and atom in {'药品包装照片','操作现场照片'}:
            row.update(status='条件不适用',scenario_example_coverage=None,gap='本场景没有实际施药，故无真实药品包装或施药现场附件；索引与关联字段已定义，未编造无意义施药。',source_material_status='本场景不适用')
        if section=='一、所有数据共同需要的通用字段' and atom=='修改原因':
            row.update(status='条件不适用',scenario_example_coverage=None,gap='未污染基准没有人工修订；字段保留为空。注入修改另见reference/answers独立台账。',source_material_status='基准未修改，不适用')
        if row['status'].startswith('条件不适用'):
            row['scenario_example_coverage']=None
        result.append(row)
    return result


def prepare_review(out_dir,tables,dictionary,coverage):
    types={(r['table'],r['column']):r['data_type'] for r in dictionary}
    specs=[]
    extras={'coverage_matrix':coverage,'field_dictionary':dictionary}
    all_tables={**tables,**extras}
    for i,(table,rows) in enumerate(all_tables.items(),1):
        if not rows: continue
        selected=rows; sampling='全量；与CSV行顺序一致'
        if table in {'water_observations','weather_observations','record_provenance'} and len(rows)>180:
            idx=sorted(set(list(range(60))+list(range(max(0,len(rows)//2-30),min(len(rows),len(rows)//2+30)))+list(range(len(rows)-60,len(rows)))))
            if table=='water_observations':
                idx=sorted(set(idx)|{j for j,r in enumerate(rows) if r.get('environment_condition') not in (None,'routine') or r.get('measurement_context')=='calibration' or r.get('missing_reason')})
            selected=[rows[j] for j in idx];sampling='确定性抽样：首60行、中间60行、末60行；无放回'
            if table=='water_observations':sampling+='；另含全部非例行环境、校准和明确缺失记录'
        cols=columns_of(rows)
        stypes={c:types.get((table,c),infer_type([r.get(c) for r in selected],c)) for c in cols}
        specs.append({'table':table,'sheet_name':f'{i:02d}_'+table[:27],'total_rows':len(rows),'rows':selected,'columns':cols,'types':stypes,'sampling':sampling,'csv_path':('schemas/'+table+'.csv') if table in extras else f'reference/baseline/{table}.csv'})
    path=out_dir/'review'/'catalog_review_data.json';write_json(path,{'sheets':specs})
    return path,specs


def make_review(out_dir,tables,dictionary,coverage):
    data_path,specs=prepare_review(out_dir,tables,dictionary,coverage)
    runtime=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node'
    node=runtime/'bin/node.exe'; modules=runtime/'node_modules'
    builder=Path(__file__).with_name('catalog_review.mjs')
    engine='artifact-tool'
    runtime_available=os.name=='nt' and node.is_file() and (modules/'@oai/artifact-tool').is_dir()
    if runtime_available:
        junction=builder.parent/'node_modules'
        if not junction.exists():
            subprocess.run(['powershell','-NoProfile','-Command',f"New-Item -ItemType Junction -Path '{junction}' -Target '{modules}' | Out-Null"],check=True,capture_output=True,text=True)
        marker=Path.home()/'.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.1026.10807/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs'
        marker_state=out_dir/'review'/'.authoring_marked'
        if not marker_state.exists() and marker.is_file():
            subprocess.run([str(node),str(marker),'--operation-kind','create','--expected-output-count','1','--output-format','xlsx'],check=True)
            marker_state.write_text('create xlsx\n',encoding='utf-8')
        proc=subprocess.run([str(node),'--max-old-space-size=8192',str(builder),str(data_path),str(out_dir/'review')],capture_output=True,text=True,encoding='utf-8')
        (out_dir/'reports'/'xlsx_build.log').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8')
        if proc.returncode:
            raise RuntimeError('Artifact tool workbook build failed; see reports/xlsx_build.log')
    else:
        engine='openpyxl (bundled artifact runtime unavailable on this host)'
        make_review_fallback(out_dir,specs)
    repairs=repair_review_export(out_dir,specs)
    return validate_review_export(out_dir,specs,engine,repairs)


def validate_review_export(out_dir,specs,engine='artifact-tool plus targeted openpyxl export repair',repairs=None):
    from openpyxl import load_workbook
    workbook=load_workbook(out_dir/'review'/'L1_review.xlsx',read_only=True,data_only=False)
    errors=[]
    value_cells_checked=0
    for spec in specs:
        ws=workbook[spec['sheet_name']]
        if list(next(ws.iter_rows(values_only=True)))!=spec['columns']:errors.append(spec['table']+': header mismatch')
        # Artifact exports may omit the optional worksheet <dimension> metadata.
        # Count decoded rows rather than mistaking read-only max_row=None for loss.
        decoded_rows=0
        spot_positions={2,len(spec['rows'])//2+2,len(spec['rows'])+1}
        for row in ws.iter_rows(max_col=len(spec['columns'])):
            decoded_rows+=1
            if any(c.data_type=='f' or c.data_type=='e' for c in row):errors.append(spec['table']+': unexpected formula/error')
            if decoded_rows in spot_positions and decoded_rows>1:
                expected_row=spec['rows'][decoded_rows-2]
                for col,cell in zip(spec['columns'],row):
                    expected=expected_row.get(col);actual=cell.value;value_cells_checked+=1
                    if expected in (None,''):
                        equal=actual in (None,'')
                    elif spec['types'][col] in {'date','datetime'}:
                        intended=dt.datetime.fromisoformat(str(expected)).replace(tzinfo=None)
                        equal=actual==intended
                    elif isinstance(expected,(int,float)) and not isinstance(expected,bool):
                        equal=isinstance(actual,(int,float)) and abs(actual-expected)<=max(1e-8,abs(expected)*1e-12)
                    else:equal=actual==expected
                    if not equal:errors.append(f"{spec['table']}!{cell.coordinate}: read-back value differs")
        if decoded_rows!=len(spec['rows'])+1:errors.append(spec['table']+': decoded row count mismatch')
    workbook.close()
    audit={'engine':engine+' author; openpyxl read-only validation','sheet_count':len(specs)+1,'errors':errors,'all_sheets_opened':True,'representative_cells_compared_to_csv':value_cells_checked,'static_review':True,'formula_count':0,'targeted_export_repairs':repairs or {},'sampled_tables':[{'table':s['table'],'total_rows':s['total_rows'],'review_rows':len(s['rows']),'sampling':s['sampling']} for s in specs if len(s['rows'])<s['total_rows']]}
    write_json(out_dir/'reports'/'xlsx_validation.json',audit)
    if errors: raise AssertionError(errors)
    return audit


def repair_review_export(out_dir,specs):
    """Correct demonstrated artifact export coercion, using the original values.

    Authorized targeted repair: artifact converted a 16:00 source timestamp to
    next-day 00:00, rounded some timestamps down 1ms, and auto-coerced a mixed-
    precision ISO string column to datetime. Preserve sheets/styles and rewrite
    all temporal and text columns from the authoritative review specification.
    """
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment
    from openpyxl.utils import get_column_letter
    path=out_dir/'review'/'L1_review.xlsx'
    wb=load_workbook(path)
    changes=[];temporal_cells=0;text_cells=0;heights_changed=0
    for spec in specs:
        ws=wb[spec['sheet_name']]
        for i,row in enumerate(spec['rows'],2):
            maximum_lines=1
            for j,col in enumerate(spec['columns'],1):
                expected=row.get(col);kind=spec['types'][col];cell=ws.cell(i,j)
                if kind in {'date','datetime'} and expected not in (None,''):
                    intended=dt.datetime.fromisoformat(str(expected)).replace(tzinfo=None)
                    temporal_cells+=1
                    if cell.value!=intended:
                        changes.append({'table':spec['table'],'cell':cell.coordinate,'field':col,'before':str(cell.value),'after':str(intended),'repair':'restore_source_wall_clock_exactly'})
                    cell.value=intended
                    cell.number_format='yyyy-mm-dd' if kind=='date' else 'yyyy-mm-dd hh:mm'
                elif kind=='string' and expected not in (None,''):
                    text_cells+=1
                    if cell.value!=str(expected) or cell.data_type!='s':
                        changes.append({'table':spec['table'],'cell':cell.coordinate,'field':col,'before':str(cell.value),'after':str(expected),'repair':'restore_literal_text_without_datetime_coercion'})
                    cell.value=str(expected);cell.data_type='s';cell.number_format='@'
                if kind=='string' and expected not in (None,''):
                    width=float(ws.column_dimensions[get_column_letter(j)].width or 18)
                    units=max(sum(2 if ord(ch)>255 else 1 for ch in line) for line in str(expected).splitlines())
                    line_count=max(1,int((units+max(8,width-2)-1)//max(8,width-2)))
                    maximum_lines=max(maximum_lines,line_count)
                    cell.alignment=Alignment(horizontal=cell.alignment.horizontal,vertical='center',wrap_text=True)
            required_height=min(409,max(18,maximum_lines*15+4))
            if (ws.row_dimensions[i].height or 18)<required_height:
                ws.row_dimensions[i].height=required_height;heights_changed+=1
    # Fit the index's long sampling descriptions as well.
    index=wb['审核索引']
    for row in index.iter_rows(min_row=10):
        lines=max([1]+[int((len(str(c.value or ''))+55)//56) for c in row])
        index.row_dimensions[row[0].row].height=max(22,lines*15+4)
        for cell in row:cell.alignment=Alignment(vertical='center',wrap_text=True)
    wb.save(path)
    verification=load_workbook(path,read_only=True,data_only=False)
    all_date_errors=[];all_text_errors=[]
    for spec in specs:
        for i,cells in enumerate(verification[spec['sheet_name']].iter_rows(min_row=2,max_col=len(spec['columns'])),0):
            source_row=spec['rows'][i]
            for col,cell in zip(spec['columns'],cells):
                expected=source_row.get(col);kind=spec['types'][col]
                if expected in (None,''):continue
                if kind in {'date','datetime'} and cell.value!=dt.datetime.fromisoformat(str(expected)).replace(tzinfo=None):all_date_errors.append(f"{spec['table']}!{cell.coordinate}")
                if kind=='string' and (cell.value!=str(expected) or cell.data_type!='s'):all_text_errors.append(f"{spec['table']}!{cell.coordinate}")
    verification.close()
    audit={'reason':'Demonstrated artifact export timezone shift, millisecond rounding and automatic ISO text conversion; targeted source-value restore authorized.','temporal_cells_checked':temporal_cells,'text_cells_checked':text_cells,'changed_cells':len(changes),'changed_columns':len({(c['table'],c['field']) for c in changes}),'changed_row_heights':heights_changed,'date_errors_after_repair':all_date_errors,'text_errors_after_repair':all_text_errors,'changes':changes}
    write_json(out_dir/'reports'/'xlsx_export_repairs.json',audit)
    if all_date_errors or all_text_errors:raise AssertionError('Post-repair temporal/text comparison failed')
    render_verified_preview(wb,specs,out_dir)
    wb.close()
    return {k:v for k,v in audit.items() if k!='changes'}


def render_verified_preview(wb,specs,out_dir):
    """Static previews drawn from the repaired saved cell values and row heights.

    Original artifact renders remain available; these clearly labeled read-back
    previews verify repaired temporal columns and wrapping without re-exporting
    the multi-million-cell workbook through the engine that caused coercion.
    """
    from PIL import Image,ImageDraw,ImageFont
    folder=out_dir/'review'/'verified_previews';folder.mkdir(parents=True,exist_ok=True)
    fonts=[Path('C:/Windows/Fonts/msyh.ttc'),Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')]
    font_path=next((p for p in fonts if p.exists()),None)
    font=ImageFont.truetype(str(font_path),13) if font_path else ImageFont.load_default()
    def render(ws,name,start_col=1,end_col=6,end_row=7):
        end_row=min(end_row,ws.max_row);end_col=min(end_col,ws.max_column)
        widths=[max(130,int((ws.column_dimensions[__import__('openpyxl').utils.get_column_letter(j)].width or 18)*7)) for j in range(start_col,end_col+1)]
        heights=[max(32,int((ws.row_dimensions[i].height or 18)*1.33)) for i in range(1,end_row+1)]
        im=Image.new('RGB',(sum(widths)+2,sum(heights)+26),'white');draw=ImageDraw.Draw(im)
        draw.text((5,3),name+' — saved workbook read-back',font=font,fill='#25364B')
        y=25
        for i,h in enumerate(heights,1):
            x=0
            for offset,w in enumerate(widths):
                cell=ws.cell(i,start_col+offset);value=cell.value
                bg='#244564' if i==1 else ('#E8F2F8' if i%2==0 else '#FFFFFF')
                draw.rectangle((x,y,x+w,y+h),fill=bg)
                if isinstance(value,dt.datetime):text=value.strftime('%Y-%m-%d' if 'hh' not in cell.number_format else '%Y-%m-%d %H:%M')
                elif value is None:text=''
                else:text=str(value)
                lines=[];line=''
                for char in text:
                    if char=='\n' or draw.textlength(line+char,font=font)>w-12:
                        lines.append(line);line='' if char=='\n' else char
                    else:line+=char
                if line or not lines:lines.append(line)
                for n,line in enumerate(lines):
                    if (n+1)*17+4<=h:draw.text((x+5,y+4+n*17),line,font=font,fill='white' if i==1 else '#25364B')
                x+=w
            y+=h
        im.save(folder/(name+'.png'))
    for spec in specs:render(wb[spec['sheet_name']],spec['sheet_name'])
    water=next(s for s in specs if s['table']=='water_test_results')
    render(wb[water['sheet_name']],'water_test_results_reported_at',11,15)
    sources=next(s for s in specs if s['table']=='sources')
    render(wb[sources['sheet_name']],'sources_literal_timestamps',5,8)


def make_review_fallback(out_dir,specs):
    """Portable equivalent when the optional Codex artifact runtime is absent.

    No formula engine is needed: this is a static audit view of authoritative CSVs.
    The saved workbook is reopened and checked by the common validation routine.
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font,PatternFill,Alignment
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table,TableStyleInfo
    wb=Workbook();index=wb.active;index.title='审核索引';index.sheet_view.showGridLines=False
    index.append(['L1 模拟数据审核视图']);index.append(['CSV为主版本；本工作簿为静态视图。场内记录均为合成。'])
    index.append(['逻辑表','工作表','完整行数','审核行数','抽样口径','CSV路径'])
    for i,spec in enumerate(specs,1):
        ws=wb.create_sheet(spec['sheet_name']);ws.sheet_view.showGridLines=False;ws.freeze_panes='B2'
        ws.append(spec['columns'])
        for row in spec['rows']:
            vals=[]
            for c in spec['columns']:
                v=row.get(c)
                if isinstance(v,str) and v and spec['types'][c] in {'date','datetime'}:
                    v=dt.datetime.fromisoformat(v).replace(tzinfo=None)
                vals.append(v)
            ws.append(vals)
        for j,c in enumerate(spec['columns'],1):
            width=min(38,max(18,len(c)*.85));ws.column_dimensions[get_column_letter(j)].width=width
            for cell in list(ws.columns)[j-1]:
                cell.font=Font(name='Arial',size=10,color='25364B');cell.alignment=Alignment(vertical='center',wrap_text=True)
                if cell.row==1:
                    cell.fill=PatternFill('solid',fgColor='244564');cell.font=Font(name='Arial',size=10,bold=True,color='FFFFFF')
                elif spec['types'][c]=='date':cell.number_format='yyyy-mm-dd'
                elif spec['types'][c]=='datetime':cell.number_format='yyyy-mm-dd hh:mm'
                elif spec['types'][c]=='integer':cell.number_format='#,##0'
                elif spec['types'][c]=='number':cell.number_format='#,##0.####'
                elif isinstance(cell.value,str):cell.data_type='s';cell.number_format='@'
        ws.row_dimensions[1].height=36
        for row in ws.iter_rows(min_row=2):
            lines=max([1]+[(sum(2 if ord(ch)>255 else 1 for ch in str(c.value or ''))//int(ws.column_dimensions[c.column_letter].width)+1) for c in row])
            ws.row_dimensions[row[0].row].height=min(180,max(18,lines*14))
        tab=Table(displayName='L1T'+str(i),ref=f'A1:{get_column_letter(ws.max_column)}{ws.max_row}')
        tab.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True);ws.add_table(tab)
        index.append([spec['table'],spec['sheet_name'],spec['total_rows'],len(spec['rows']),spec['sampling'],spec['csv_path']])
    for j,width in enumerate([34,32,14,14,58,70],1):index.column_dimensions[get_column_letter(j)].width=width
    index.freeze_panes='C4'
    for cell in index[3]:cell.fill=PatternFill('solid',fgColor='244564');cell.font=Font(name='Arial',size=10,bold=True,color='FFFFFF')
    wb.save(out_dir/'review'/'L1_review.xlsx')
    write_json(out_dir/'review'/'xlsx_authoring_audit.json',{'engine':'openpyxl fallback','sheet_count':len(specs)+1,'render_status':'portable fallback does not claim native Excel rendering','limitation':'Optional artifact runtime absent. Reopen/dimension/type validation performed; inspect in Excel for host font rendering.'})


def build_catalog(out_dir:Path,cfg:dict,tables:dict)->dict:
    out_dir=Path(out_dir);root=Path(__file__).resolve().parents[2]
    (out_dir/'reports').mkdir(parents=True,exist_ok=True)
    source_dir=Path(__file__).resolve().parents[1]/'public_sources'/'attachment'
    if not (source_dir/'武昌鱼养殖知识库数据源与字段清单.md').exists():source_dir=root/'source'/'L1模拟数据交接包'
    reqs=build_requirements(source_dir,out_dir)
    coverage=build_coverage(reqs,tables,out_dir)
    write_csv(out_dir/'schemas'/'coverage_matrix.csv',coverage)
    dictionary,schema,unknown,key_errors=build_dictionary(tables,coverage)
    write_csv(out_dir/'schemas'/'field_dictionary.csv',dictionary)
    write_json(out_dir/'schemas'/'schema.json',schema)
    fk_errors=[]
    for table,desc in schema['tables'].items():
        for fk in desc['foreign_keys']:
            target=fk['references']['table'];ids={str(r['id']) for r in tables[target]}
            bad=[{'table':table,'record_id':r['id'],'field':fk['field'],'value':r.get(fk['field']),'target':target} for r in tables[table] if r.get(fk['field']) not in (None,'') and str(r[fk['field']]) not in ids]
            fk_errors.extend(bad)
    for table,table_col,id_col in [('attachment_links','entity_table','entity_id'),('record_provenance','table','record_id'),('event_registry','event_table','event_record_id')]:
        if table not in tables:continue
        schema['tables'][table]['polymorphic_foreign_keys']=[{'table_field':table_col,'id_field':id_col,'target_field':'id'}]
        ids_by_table={t:{str(r['id']) for r in rows} for t,rows in tables.items()}
        for r in tables[table]:
            if str(r.get(id_col)) not in ids_by_table.get(r.get(table_col),set()):fk_errors.append({'table':table,'record_id':r['id'],'field':id_col,'value':r.get(id_col),'target':r.get(table_col)})
    write_json(out_dir/'schemas'/'schema.json',schema)
    example_count=sum(r['scenario_example_coverage'] is True for r in coverage)
    applicable_count=sum(r['scenario_example_coverage'] is not None for r in coverage)
    audit={'requirements_total':len(reqs),'mapped_requirements':sum(r['structural_coverage'] for r in coverage),'structural_coverage_rate':round(sum(r['structural_coverage'] for r in coverage)/len(reqs),6),'scenario_example_requirements':example_count,'scenario_applicable_requirements':applicable_count,'scenario_example_coverage_rate':round(example_count/applicable_count,6),'conditional_not_applicable_requirements':len(reqs)-applicable_count,'coverage_definitions':{'structural_coverage':'每个原子项已映射到存在的精确CSV列；不证明该类真实材料已取得','scenario_example_coverage':'本版确有该类模拟业务/可打开格式样例及关联；None表示场景条件不适用','source_material_status':'公开原件、合成样例、真实资料待取得分别记录；合成样例不是现场真值'},'field_count':len(dictionary),'actual_field_count':sum(len(columns_of(v)) for v in tables.values()),'all_actual_fields_in_dictionary':True,'unreviewed_field_definitions':unknown,'primary_key_error_tables':key_errors,'foreign_key_errors':fk_errors,'gaps':[r for r in coverage if r['gap']],'status_counts':{s:sum(r['status']==s for r in coverage) for s in sorted({r['status'] for r in coverage})},'coverage_is_not_real_field_evidence':True}
    write_json(out_dir/'reports'/'coverage_audit.json',audit)
    if not cfg.get('skip_xlsx'):
        audit['xlsx']=make_review(out_dir,tables,dictionary,coverage)
        write_json(out_dir/'reports'/'coverage_audit.json',audit)
    return audit


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    req = build_requirements(root / "source" / "L1模拟数据交接包", root / "output")
    print(f"Atomic requirements: {len(req)}")
