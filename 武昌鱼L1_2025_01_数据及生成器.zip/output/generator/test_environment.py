import unittest
import environment

class EnvironmentTests(unittest.TestCase):
    def test_full_hour_grid_and_no_false_lab_sensor(self):
        t=environment.generate({'seed':20251031,'year':2025,'mode':'full'}, {})
        self.assertEqual(len(t['water_observations']),52560)
        self.assertEqual(len({(x['pond_id'],x['observed_at']) for x in t['water_observations']}),52560)
        self.assertNotIn('ammonia',t['water_observations'][0])
        self.assertTrue(all(x['diagnosis_status']!='confirmed' for x in t['health_cases']))
    def test_raw_injection_answers_are_separate(self):
        base={'water_observations':[{'id':str(i),'temperature_c':20,'do_mg_l':6,'ph':7,'observed_at':'2025-07-01T00:00:00+08:00','recorded_at':'2025-07-01T00:01:00+08:00'} for i in range(1000)]}
        raw,answers=environment.make_raw(base,{'seed':42,'anomaly_ratio':0.03})
        self.assertEqual(len({x['record_id'] for x in answers}),30)
        self.assertEqual(base['water_observations'][0]['temperature_c'],20)
        self.assertNotIn('expected',str(raw))

if __name__=='__main__': unittest.main()
