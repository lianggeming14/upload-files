import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';

const input = JSON.parse(await fs.readFile(process.argv[2], 'utf8'));
const out = process.argv[3];
await fs.mkdir(path.join(out, 'previews'), {recursive: true});
const workbook = Workbook.create();
const index = workbook.worksheets.add('审核索引');
index.showGridLines = false;
index.getRange('A2').values = [['L1 模拟数据审核视图']];
index.getRange('A2').format.font = {name:'Arial', size:15, bold:true, color:'#172B4D'};
index.getRange('A4').values = [['CSV 为主版本；本工作簿为静态审核视图。所有场内记录为合成。']];
index.getRange('A5').values = [['数据窗口：2025-01-01 至 2025-12-31；时区：Asia/Shanghai。']];
index.getRange('A6').values = [['超大时序与记录溯源使用确定性抽样。完整记录见索引所列 CSV。']];
const header = ['逻辑表','工作表','完整行数','审核行数','抽样口径','CSV 路径'];
const rows = [];
const sheetAudit = [];
function columnName(n) {let x=n,s='';while(x){x--;s=String.fromCharCode(65+x%26)+s;x=Math.floor(x/26);}return s;}
for (let i = 0; i < input.sheets.length; i++) {
  const spec = input.sheets[i];
  const sheet = workbook.worksheets.add(spec.sheet_name);
  sheet.showGridLines = false;
  const data = [spec.columns, ...spec.rows.map(row => spec.columns.map((col, j) => {
    const value = row[col] ?? null;
    if (typeof value === 'string' && value.startsWith('=')) return "'" + value;
    if (value && spec.types[col] === 'date') return new Date(value + 'T00:00:00Z');
    // Excel has no timezone type. Preserve the source wall-clock representation;
    // its timezone remains explicit in CSV/schema rather than shifting by UTC.
    if (value && spec.types[col] === 'datetime') return new Date(value.replace(' ', 'T').replace(/(?:[+-]\d{2}:\d{2}|Z)$/,'')+'Z');
    return value;
  }))];
  sheet.getRangeByIndexes(0,0,data.length,spec.columns.length).values = data;
  const used = sheet.getRangeByIndexes(0,0,data.length,spec.columns.length);
  used.format.font = {name:'Arial',size:10,color:'#25364B'};
  used.format.verticalAlignment = 'center';
  used.format.rowHeight = 18;
  const head = sheet.getRangeByIndexes(0,0,1,spec.columns.length);
  head.format.fill = '#244564';
  head.format.font = {name:'Arial',size:10,bold:true,color:'#FFFFFF'};
  head.format.wrapText = true;
  head.format.rowHeight = 36;
  head.format.horizontalAlignment = 'center';
  for (let j = 0; j < spec.columns.length; j++) {
    const col = spec.columns[j];
    const rg = sheet.getRangeByIndexes(0,j,data.length,1);
    rg.format.columnWidth = Math.min(38, Math.max(18, col.length * 0.85));
    const body = sheet.getRangeByIndexes(1,j,Math.max(1,data.length-1),1);
    if (spec.types[col] === 'date') body.setNumberFormat('yyyy-mm-dd');
    else if (spec.types[col] === 'datetime') body.setNumberFormat('yyyy-mm-dd hh:mm');
    else if (spec.types[col] === 'integer') body.setNumberFormat('#,##0');
    else if (spec.types[col] === 'number') body.setNumberFormat('#,##0.####');
    else body.setNumberFormat('@');
    if (spec.types[col] === 'string') body.format.wrapText = true;
  }
  if (['coverage_matrix','field_dictionary','documents','document_versions','media_annotations','sources','attachments','record_provenance'].includes(spec.table)) {
    sheet.getRangeByIndexes(1,0,data.length-1,spec.columns.length).format.rowHeight = spec.table==='coverage_matrix'?84:54;
  }
  sheet.freezePanes.freezeRows(1);
  sheet.freezePanes.freezeColumns(1);
  if (data.length > 1) {
    const table = sheet.tables.add(`A1:${columnName(spec.columns.length)}${data.length}`, true, `L1T${i+1}`);
    table.showFilterButton = true;
  }
  rows.push([spec.table,spec.sheet_name,spec.total_rows,spec.rows.length,spec.sampling,spec.csv_path]);
  sheetAudit.push({table:spec.table,sheet_name:spec.sheet_name,rows:spec.rows.length,columns:spec.columns.length});
}
index.getRangeByIndexes(8,0,rows.length+1,header.length).values = [header,...rows];
index.getRangeByIndexes(8,0,1,header.length).format = {fill:'#244564',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},rowHeight:28};
index.getRangeByIndexes(9,0,rows.length,header.length).format.font = {name:'Arial',size:10,color:'#25364B'};
index.getRangeByIndexes(9,0,rows.length,header.length).format.rowHeight = 22;
index.getRange(`A1:A${rows.length+9}`).format.columnWidth = 34;
index.getRange(`B1:B${rows.length+9}`).format.columnWidth = 31;
index.getRange(`C1:D${rows.length+9}`).format.columnWidth = 13;
index.getRange(`E1:E${rows.length+9}`).format.columnWidth = 58;
index.getRange(`F1:F${rows.length+9}`).format.columnWidth = 70;
index.freezePanes.freezeRows(9);
index.tabColor = '#244564';
workbook.recalculate();
const inspected = await workbook.inspect({kind:'table',range:'审核索引!A9:F14',include:'values',tableMaxRows:6,tableMaxCols:6});
await fs.writeFile(path.join(out,'catalog_inspection.ndjson'),inspected.ndjson);
const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(path.join(out,'L1_review.xlsx'));
const renderFailures=[];
for (const name of ['审核索引',...input.sheets.map(s=>s.sheet_name)]) {
  try {
    const image = await workbook.render({sheetName:name,range:name==='审核索引'?'A2:F14':'A1:F7',scale:1,format:'png'});
    await fs.writeFile(path.join(out,'previews',name+'.png'),new Uint8Array(await image.arrayBuffer()));
  } catch(e) {renderFailures.push({sheet:name,error:String(e).slice(0,300)});}
}
await fs.writeFile(path.join(out,'xlsx_authoring_audit.json'),JSON.stringify({engine:'@oai/artifact-tool',sheet_count:sheetAudit.length+1,sheets:sheetAudit,render_failures:renderFailures},null,2));
console.log(JSON.stringify({xlsx:path.join(out,'L1_review.xlsx'),sheets:sheetAudit.length+1,render_failures:renderFailures.length}));
