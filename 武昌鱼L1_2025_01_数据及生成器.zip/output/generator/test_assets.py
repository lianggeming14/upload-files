"""Integration checks catch missing files, fake formats and broken attachment links."""
import importlib.util
import tempfile
import unittest
from pathlib import Path


class AssetsTests(unittest.TestCase):
    def module(self):
        path = Path(__file__).with_name('assets.py')
        self.assertTrue(path.exists(), 'assets generator must be implemented')
        spec = importlib.util.spec_from_file_location('assets', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def fixture(self):
        return {
            'farms': [{'id': 'F01'}],
            'ponds': [{'id': f'P{i:02d}', 'farm_id': 'F01'} for i in range(1, 7)],
            'patrols': [{'id': 'PAT01', 'pond_id': 'P01', 'farm_id': 'F01', 'occurred_at': '2025-05-10T06:00:00+08:00'}],
            'health_cases': [{'id': 'HC01', 'pond_id': 'P01', 'farm_id': 'F01'}],
            'sales': [{'id': 'SALE01', 'farm_id': 'F01'}],
        }

    def test_sample_files_are_real_and_repeatable(self):
        m = self.module()
        cfg = {'seed': 20251031, 'year': 2025, 'mode': 'sample'}
        with tempfile.TemporaryDirectory() as first, tempfile.TemporaryDirectory() as second:
            base = self.fixture()
            a = m.generate_assets(Path(first), cfg, base)
            b = m.generate_assets(Path(second), cfg, base)
            self.assertEqual(a, b, 'same seed and inputs must yield identical manifests and file hashes')
            self.assertEqual([r for r in m.validate_assets(Path(first), {**base, **a}) if not r['passed']], [])
            suffixes = {Path(r['relative_path']).suffix for r in a['attachments']}
            self.assertTrue({'.geojson', '.tif', '.png', '.jpg', '.mp4', '.wav', '.txt', '.pdf'} <= suffixes)
            self.assertGreaterEqual(len(a['documents']), 20)
            self.assertTrue(all(r['diagnosis_status'] == 'not_applicable_synthetic_format_test' for r in a['media_annotations']))

    def test_validator_detects_corrupt_files_and_dangling_links(self):
        m = self.module()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            base = self.fixture()
            data = m.generate_assets(root, {'seed': 20251031, 'year': 2025, 'mode': 'sample'}, base)
            target = next(r for r in data['attachments'] if r['relative_path'].endswith('.png'))
            (root / target['relative_path']).write_bytes(b'not-a-png')
            data['attachment_links'][0]['entity_id'] = 'MISSING'
            base['ponds'][0]['geometry_id'] = 'MISSING_SPATIAL_FEATURE'
            failures = {r['check_id'] for r in m.validate_assets(root, {**base, **data}) if not r['passed']}
            self.assertIn('asset_file_hashes', failures)
            self.assertIn('asset_decoders', failures)
            self.assertIn('asset_foreign_keys', failures)
            self.assertIn('asset_spatial_references', failures)


if __name__ == '__main__':
    unittest.main()
