"""Run the reproducible L1 scenario, sample gate, exports and acceptance checks."""
from __future__ import annotations
import argparse,csv,json,hashlib,shutil,sys,copy,platform
from pathlib import Path
from datetime import datetime,timedelta
from collections import Counter,defaultdict
import business,environment

ROOT=Path(__file__).resolve().parents[1]
VERSION='L1-1.0.0'
def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def write_csv(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    cols=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols,lineterminator='\n'); w.writeheader(); w.writerows(rows)
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def column_type(rows,col):
    kinds={type(r[col]).__name__ for r in rows if r.get(col) is not None}
    if not kinds:return 'str'
    if kinds<={'int','float'}:return 'float' if 'float' in kinds else 'int'
    return next(iter(kinds)) if len(kinds)==1 else 'str'
def check(name,ok,detail):return {'check_id':name,'passed':bool(ok),'detail':detail}

def integrate(t,cfg):
    # Join environmental context to business events without changing quantity ledgers.
    for r in t['water_observations']:
        if '2025-01-05T08:00:00+08:00'<=r['observed_at']<'2025-01-07T08:00:00+08:00':
            for key in ['temperature_c','do_mg_l','ph','raw_ph']:r[key]=None
            r['measurement_context']='pond_dry_preparation';r['missing_reason']='not_applicable_no_water';r['quality_flag']='planned_non_observation_slot'
    obs={(r['pond_id'],r['observed_at'][:13]):r for r in t['water_observations']}
    for r in t['feeding_events']:
        r['device_id']='F'+r['pond_id'][1:]; r['feeding_area']='PT_'+r['pond_id']
        w=obs.get((r['pond_id'],r['occurred_at'][:13]))
        if w:
            r['water_temperature_c']=w['temperature_c'];r['dissolved_oxygen_mg_l']=w['do_mg_l'];r['water_observation_id']=w['id'];r['weather_id']=w['weather_id']
            r['environment_value_basis']='joined_synthetic_sensor_observation'
    for r in t['devices']:
        r['position_id']='PT_'+r['pond_id']
    for table,rows in t.items():
        for r in rows:
            for k in ['operator_id','sampler_id','advisor_id','verified_by']:
                if r.get(k) in ['STAFF01','STAFF02']:r[k]=r[k].replace('STAFF','PERSON')
            if r.get('reviewer_id')=='STAFF02':r['reviewer_id']='PERSON02'
    t['persons']=[dict(id='PERSON01',name='模拟记录员',role='recorder',is_fictional=True),dict(id='PERSON02',name='模拟审核员',role='reviewer',is_fictional=True)]
    manifest=json.loads((ROOT/'public_sources/attachment/sample_manifest.json').read_text('utf-8'))
    t['sources']=[]
    for sid in sorted({r['source_id'] for r in manifest['files']}):
        entries=[r for r in manifest['files'] if r['source_id']==sid]
        t['sources'].append(dict(id=sid,title=entries[0]['source_kind'],url=entries[0]['requested_url'],origin_kind=entries[0]['source_kind'],is_synthetic=False,local_path='public_sources/attachment/public_samples/'+entries[0]['relative_path'],access_conditions=entries[0]['note'],retrieved_at=entries[0]['retrieved_at_utc'],use_boundary='format_reference_not_local_measurement',version='attachment_snapshot_2026-10-31'))
    weather=json.loads((ROOT/'public_sources/weather_download.json').read_text('utf-8'))
    t['sources'].extend([dict(id='S07',title='Open-Meteo ERA5 2025 hourly',url=weather['url'],origin_kind='weather_reanalysis',is_synthetic=False,local_path='public_sources/era5_2025.json',access_conditions=weather['license'],retrieved_at='2026-10-31',use_boundary='external_grid_not_pond_station',version='ERA5_snapshot_2026-10-31'),dict(id='A01',title='本地明确模拟假设',url=None,origin_kind='scenario_assumption',is_synthetic=True,local_path='scenario/assumptions.json',access_conditions='synthetic_generated_for_this_task',retrieved_at=None,use_boundary='not_real_observation_or_prescription',version=VERSION)])
    t['production_plans']=[dict(id='PLAN-SYNTH-2025',farm_id='F01',year=2025,mode='ordinary_pond_polyculture',technical_document_path='scenario/assumptions.json',responsible_person_id='PERSON02',start_date='2025-01-01',end_date='2025-12-31',status='synthetic_cycle_closed')]
    # Daily aggregate is derived from actual feeding events; never independent random data.
    daily=defaultdict(float)
    for r in t['feeding_events']:daily[r['pond_id'],r['occurred_at'][:10]]+=r['quantity_kg']
    for r in t['feeding_events']:r['daily_total_kg']=round(daily[r['pond_id'],r['occurred_at'][:10]],3)
    balance={(r['cohort_id'],r['balance_date']):r for r in t['fish_daily_balance']}
    for r in t['health_cases']:
        b=balance.get((r['cohort_id'],r['discovered_at'][:10]))
        if b:
            r['population_denominator']=b['closing_count'];r['incidence_rate']=round(r['affected_count']/b['closing_count'],8)
            r['denominator_basis']='same_day_ledger_closing_count_synthetic'
    mortal=defaultdict(list)
    for r in t['mortality_events']:mortal[r['pond_id'],r['occurred_at'][:10]].append(r)
    for r in t['patrol_events']:
        deaths=mortal.get((r['pond_id'],r['occurred_at'][:10]),[]) if r['occurred_at'][11:13]=='18' else []
        if deaths:
            r['dead_count']=sum(v.get('count',v.get('dead_count',0)) for v in deaths)
            r['dead_weight_kg']=round(sum(v.get('weight_kg',v.get('dead_weight_kg',0)) for v in deaths),3)
            r['mortality_event_ids']=';'.join(v['id'] for v in deaths)
        if r['occurred_at']<'2025-01-10T09:00:00+08:00' or r['occurred_at']>'2025-11-20T09:00:00+08:00':
            r['swimming']='not_applicable_empty_pond';r['feeding_behavior']='not_applicable_empty_pond';r['bank_gathering']=None
    # All 12 production event types are discoverable through a typed registry.
    event_tables=['pond_preparations','stocking_events','feeding_events','water_samples','patrol_events','growth_samples','health_cases','treatment_events','water_operations','device_operations','mortality_events','disposal_events','transfer_events','harvests']
    t['event_registry']=[dict(id=table+':'+r['id'],event_table=table,event_record_id=r['id'],pond_id=r.get('pond_id'),cohort_id=r.get('cohort_id'),occurred_at=next((r[k] for k in ['occurred_at','sampled_at','started_at','discovered_at'] if r.get(k)),None)) for table in event_tables for r in t.get(table,[])]

def add_provenance(t,cfg):
    rows=[]
    for table,data in list(t.items()):
        for r in data:
            external=table=='weather_observations' and r.get('origin_kind')=='weather_reanalysis'
            when=next((r[k] for k in ['occurred_at','observed_at','sampled_at','started_at','discovered_at'] if r.get(k)),None)
            derived=table in ['fish_daily_balance','cost_allocations','harvest_sale_allocations','growth_samples','event_registry']
            rows.append(dict(id=table+':'+str(r['id']),table=table,record_id=r['id'],farm_id=r.get('farm_id','F01') if table not in ['weather_observations','price_observations','documents','document_versions','species','dictionaries'] else None,pond_id=r.get('pond_id'),cohort_id=r.get('cohort_id'),origin_kind='weather_reanalysis' if external else ('derived_simulation' if derived else 'rule_simulation'),is_synthetic=not external,reference_source_id='S07' if external else ('S05' if table=='price_observations' else 'A01'),generation_run_id=cfg['generation_run_id'],rule_version=VERSION,seed=cfg['seed'],scenario_id='F01_2025_'+cfg['mode'],parameter_basis='source_file_ERA5' if external else 'scenario/assumptions.json',source_system='Open-Meteo' if external else 'SIM_'+table,source_record_number=r['id'],occurred_at=when,recorded_at=r.get('recorded_at',when),uploaded_at=r.get('uploaded_at',when),ingested_at=r.get('ingested_at',when),updated_at=r.get('updated_at',when),source_timezone='Asia/Shanghai',time_precision='hour' if table in ['weather_observations','water_observations'] else 'minute',recorder_id=None if external else 'PERSON01',reviewer_id=None if external else 'PERSON02',review_status='synthetic_checked' if not external else 'external_structure_checked',source_page=None,source_page_status='not_applicable_tabular',is_estimated=derived,missing_status='see_field_status_or_schema',modification_reason=None))
    t['record_provenance']=rows
    # A catalog entry about an external source is metadata, never a synthetic observation.
    for r in rows:
        if r['table']=='sources' and r['record_id']!='A01':
            r.update(origin_kind='external_source_metadata',is_synthetic=False,reference_source_id=r['record_id'],parameter_basis='public_sources/attachment/sample_manifest.json' if r['record_id']!='S07' else 'public_sources/weather_download.json',source_system='source_catalog',recorder_id=None,reviewer_id=None,review_status='external_metadata_checked')

def validate(t,cfg):
    checks=business.validate_business({k:t[k] for k in business.TABLES})
    for x in checks:
        if 'passed' not in x:x['passed']=x.get('ok',x.get('status')=='pass')
    for table,rows in t.items():
        ids=[r['id'] for r in rows]; checks.append(check('pk_'+table,len(ids)==len(set(ids)),f'{len(rows)} rows'))
        checks.append(check('utf8_'+table,not any('\ufffd' in str(v) for r in rows for v in r.values()),'no Unicode replacement characters'))
    expected=52560 if cfg['mode']=='full' else 6*15*24
    w=t['water_observations'];checks.append(check('water_hour_grid',len(w)==expected and len({(r['pond_id'],r['observed_at']) for r in w})==expected,f'{len(w)} expected {expected}'))
    checkrefs={'pond_id':'ponds','cohort_id':'cohorts','species_id':'species','device_id':'devices','weather_id':'weather_observations','sample_id':None,'case_id':'health_cases','attachment_id':'attachments','sale_id':'sales','sale_item_id':'sale_items','harvest_id':'harvests','product_id':'products'}
    for field,target in checkrefs.items():
        if not target or target not in t:continue
        ids={r['id'] for r in t[target]}; failures=[]
        for table,rows in t.items():
            if table in ['dictionaries']:continue
            for r in rows:
                if r.get(field) not in [None,''] and r[field] not in ids: failures.append(f"{table}:{r['id']}:{r[field]}")
        checks.append(check('fk_'+field,not failures,failures[:15]))
    installs={r['device_id']:r for r in t['device_installations']}
    checks.append(check('sensor_installation_time',all(installs[r['device_id']]['installed_at']<=r['observed_at']<installs[r['device_id']]['removed_at'] for r in w),'inclusive start exclusive end'))
    checks.append(check('no_unfounded_confirmed_disease',all(r['diagnosis_status']!='confirmed' for r in t['health_cases']),'all synthetic suspected/excluded'))
    checks.append(check('no_unfounded_GI',all(not r['geographical_indication_qualified'] for r in t['species']),'species does not grant brand qualification'))
    checks.append(check('analyte_basis',all(r['expression_basis']=='as_N' for r in t['water_test_results'] if r['analyte_code'].endswith('as_N')),'TAN/NO2-N/NO3-N distinct'))
    checks.append(check('LOD_null',all(r['value'] is None for r in t['water_test_results'] if r['result_status'] in ['below_detection_limit','detection_failed']),'below detection limit and failures not zero'))
    individuals=defaultdict(list)
    for r in t.get('growth_individuals',[]):individuals[r['sample_id']].append(r)
    checks.append(check('growth_sample_totals',all(r['sample_size']==len(individuals[r['id']]) and abs(r['mean_weight_g']-sum(v['weight_g'] for v in individuals[r['id']])/r['sample_size'])<.001 for r in t.get('growth_samples',[])),'30 individuals per active-month group; no samples after empty pond'))
    for table in ['feeding_events','stocking_events','harvests','sales','cash_transactions']:
        checks.append(check('year_window_'+table,all(str(r['occurred_at']).startswith('2025-') for r in t[table]),'business completed in scenario year'))
    return checks

def validate_dirty(base,raw,answers):
    affected={(a['table'],a['record_id']) for a in answers}; found=set(); duplicate_count=0
    for table,rows in raw.items():
        b={r['id']:r for r in base[table]}; counts=Counter(r['id'] for r in rows)
        for r in rows:
            if r['id'] not in b or r!=b[r['id']] or counts[r['id']]>1:found.add((table,r['id']))
        duplicate_count+=sum(n-1 for n in counts.values())
    return [check('dirty_exact_answer_correspondence',found==affected,{'affected_records':len(affected),'observed_changed_records':len(found),'unexplained':list(found-affected)[:10],'unrealized':list(affected-found)[:10]}),check('raw_has_no_answer_columns',not any(any(k in r for k in ['baseline_value','injected_value','expected_action','anomaly_type']) for rows in raw.values() for r in rows),'answers exist only in reference/answers')],duplicate_count

def execute(out,cfg,review=True):
    import assets,catalog
    out.mkdir(parents=True,exist_ok=True)
    if out.resolve()!=ROOT.resolve():
        shutil.copytree(ROOT/'public_sources',out/'public_sources',dirs_exist_ok=True)
        (out/'scenario').mkdir(exist_ok=True)
        shutil.copy2(ROOT/'scenario/assumptions.json',out/'scenario/assumptions.json')
    cfg={**cfg,'generation_run_id':f"{VERSION}-{cfg['mode']}-{cfg['seed']}",'weather_path':str(ROOT/'public_sources/era5_2025.json')}
    t=business.generate(cfg);t.update(environment.generate(cfg,t));integrate(t,cfg)
    t.update(assets.generate_assets(out,cfg,t));add_provenance(t,cfg)
    checks=validate(t,cfg)+assets.validate_assets(out,t)
    raw,answers=environment.make_raw({k:v for k,v in t.items() if k!='record_provenance'},cfg)
    dc,duplicates=validate_dirty({k:v for k,v in t.items() if k!='record_provenance'},raw,answers);checks+=dc
    # Source input sidecars identify synthetic origin without carrying quality answers.
    write_csv(out/'synthetic_raw/source_registry.csv',[dict(id=k,table=k,origin_kind='weather_reanalysis' if k=='weather_observations' and t[k][0]['origin_kind']=='weather_reanalysis' else 'synthetic_input',generation_run_id=cfg['generation_run_id'],seed=cfg['seed'],rule_version=VERSION,timezone='Asia/Shanghai') for k in raw])
    for k,rows in t.items():write_csv(out/'reference/baseline'/f'{k}.csv',rows)
    for k,rows in raw.items():write_csv(out/'synthetic_raw'/f'{k}.csv',rows)
    write_csv(out/'reference/answers/anomaly_ledger.csv',answers)
    # Explicit unit/header mapping is source-format documentation, never row-level answers.
    write_csv(out/'schemas/source_column_mapping.csv',[dict(source_file='water_observations.csv',source_column=k,target_column=v,source_unit=u,target_unit=tu,transform=tr) for k,v,u,tu,tr in [('temperature_c','temperature_c','degC or explicit temperature_c_unit','degC','if degF: (value-32)/1.8'),('observed_at','observed_at','ISO8601 or local datetime','ISO8601+08:00','parse with Asia/Shanghai default'),('raw_ph','raw_ph','pH','pH','preserve raw value; calibration context separate')]])
    # One real legacy header/units feed export; views are not extra business events.
    legacy=[{'本地流水号':r['id'],'投喂时间':r['occurred_at'].replace('T',' ').replace('+08:00',''),'塘号':r['pond_id'],'饲料数量斤':round(r['quantity_kg']*2,3),'源记录ID':r['id']} for r in raw['feeding_events'][:30]]
    write_csv(out/'synthetic_raw/source_views/feeding_legacy.csv',legacy)
    dump(out/'scenario/config.json',{k:v for k,v in cfg.items() if k!='weather_path'})
    dump(out/'reports/checks.json',checks)
    dump(out/'reports/row_counts.json',{k:len(v) for k,v in t.items()})
    dump(out/'reports/serialization_types.json',{k:{col:column_type(rows,col) for col in dict.fromkeys(c for r in rows for c in r)} for k,rows in t.items()})
    if review: catalog.build_catalog(out,cfg,t)
    eligible=sum(len(t[k]) for k in ['water_observations','feeding_events','patrol_events','price_observations','water_test_results','sales','sale_items'])
    summary={'mode':cfg['mode'],'seed':cfg['seed'],'rule_version':VERSION,'tables':len(t),'baseline_rows':sum(map(len,t.values())),'business_rows_excluding_provenance':sum(len(v) for k,v in t.items() if k!='record_provenance'),'checks':len(checks),'failed_checks':[x for x in checks if not x.get('passed',x.get('ok',False))],'injected_records':len(answers),'eligible_records':eligible,'injection_ratio_eligible':len(answers)/eligible,'injection_ratio_all_data_rows':len(answers)/sum(len(v) for k,v in t.items() if k!='record_provenance'),'duplicate_rows_added':duplicates,'row_counts':{k:len(v) for k,v in t.items()}}
    dump(out/'reports/run_summary.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='row_counts'},ensure_ascii=False),flush=True)
    if summary['failed_checks']:raise RuntimeError('Validation failed: see reports/checks.json')
    return summary

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['sample','full','all'],default='all');p.add_argument('--out',type=Path,default=ROOT);p.add_argument('--seed',type=int,default=20251031);p.add_argument('--skip-review',action='store_true');a=p.parse_args()
    cfg={'seed':a.seed,'year':2025,'mode':'sample','anomaly_ratio':.04}
    if a.mode in ['sample','all']:execute(a.out/'sample',cfg,not a.skip_review)
    if a.mode in ['full','all']:
        gate=a.out/'sample/reports/run_summary.json'
        if not gate.exists() or json.loads(gate.read_text('utf-8'))['failed_checks']:raise RuntimeError('Run passing sample first')
        cfg['mode']='full';execute(a.out,cfg,not a.skip_review)
if __name__=='__main__':main()
