"""Independent read-back acceptance, answer checks and mutation detection.

Usage: python output/generator/verify.py --out output [--skip-assets]
Never re-generates a baseline. Inputs are the serialized CSVs and saved type map.
"""
from __future__ import annotations
import argparse
import ast
from collections import Counter, defaultdict
import copy
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys

import business
import run


def decode(value, type_name):
    """Restore scalar serialization types; an empty CSV cell is an explicit null."""
    if value is None or value == '':
        return None
    if type_name == 'bool':
        if value not in ('True', 'False'):
            raise ValueError(f'Invalid boolean {value!r}')
        return value == 'True'
    if type_name == 'int':
        return int(value)
    if type_name == 'float':
        return float(value)
    if type_name in ('dict', 'list', 'tuple'):
        return ast.literal_eval(value)
    return value


def read_tables(directory, type_map, *, raw=False):
    tables = {}
    for name, columns in type_map.items():
        if raw and name == 'record_provenance':
            continue
        path = directory / f'{name}.csv'
        with path.open('r', encoding='utf-8', newline='') as handle:
            tables[name] = [
                {key: decode(value, columns.get(key, 'str')) for key, value in row.items()}
                for row in csv.DictReader(handle)
            ]
    return tables


def _check(name, passed, **detail):
    return {'check_id': name, 'passed': bool(passed), **detail}


def _canonical(row):
    # CSV cannot distinguish absent fields from empty cells on sparse rows.
    return {k: v for k, v in row.items() if v is not None}


def verify_answers(out, base, raw, types):
    path = out / 'reference' / 'answers' / 'anomaly_ledger.csv'
    with path.open('r', encoding='utf-8', newline='') as handle:
        answers = list(csv.DictReader(handle))
    baseline_index = {name: {r['id']: r for r in rows} for name, rows in base.items()}
    raw_index = {name: defaultdict(list) for name in raw}
    for name, rows in raw.items():
        for physical_index, row in enumerate(rows, 2):
            raw_index[name][row['id']].append((physical_index, row))
    wrong_values, wrong_lines, wrong_multiplicity = [], [], []
    wrong_all_lines=[]
    expected_by_record = defaultdict(list)
    for a in answers:
        name, rid, field = a['table'], a['record_id'], a['field']
        key = (name, rid)
        expected_by_record[key].append(a)
        baseline = baseline_index.get(name, {}).get(rid)
        matches = raw_index.get(name, {}).get(rid, [])
        if baseline is None or not matches:
            wrong_values.append(a['id'] + ':missing_record')
            continue
        typ = types[name].get(field, 'str')
        expected_before = decode(a['baseline_value'], typ)
        expected_after = decode(a['injected_value'], typ)
        if baseline.get(field) != expected_before or not any(row.get(field) == expected_after for _, row in matches):
            wrong_values.append(a['id'])
        expected_n = 2 if a['anomaly_type'] == 'duplicate' else 1
        if len(matches) != expected_n:
            wrong_multiplicity.append(a['id'])
        line = int(a['source_row_index'])
        if not any(i == line and row.get(field) == expected_after for i, row in matches):
            wrong_lines.append(a['id'])
        if a.get('source_physical_rows'):
            expected_lines=json.loads(a['source_physical_rows'])
            if sorted(expected_lines)!=sorted(i for i,_ in matches):wrong_all_lines.append(a['id'])
    unexplained, unrealized, extra_fields = [], [], []
    observed = set()
    for name, rows in raw.items():
        indexed = baseline_index[name]
        counts = Counter(r['id'] for r in rows)
        for row in rows:
            rid = row['id']
            baseline = indexed.get(rid)
            key = (name, rid)
            if baseline is None:
                unexplained.append(f'{name}/{rid}:unexpected_record')
                continue
            changed = {field for field in set(baseline) | set(row) if baseline.get(field) != row.get(field)}
            if changed or counts[rid] > 1:
                observed.add(key)
            allowed = set()
            for a in expected_by_record.get(key, []):
                allowed.add(a['field'])
                if a['anomaly_type'] == 'unit_mixed':
                    allowed.add(a['field'] + '_unit')
            unexpected = changed - allowed
            if unexpected:
                extra_fields.append(f'{name}/{rid}:{sorted(unexpected)}')
    expected = set(expected_by_record)
    unexplained.extend(f'{a}/{b}' for a, b in sorted(observed - expected))
    unrealized.extend(f'{a}/{b}' for a, b in sorted(expected - observed))
    return [
        _check('disk_answer_values', not wrong_values, checked=len(answers), failures=wrong_values[:20]),
        _check('disk_answer_physical_rows', not wrong_lines, checked=len(answers), failures=wrong_lines[:20]),
        _check('disk_answer_all_duplicate_locations',not wrong_all_lines,checked=len(answers),failures=wrong_all_lines[:20]),
        _check('disk_answer_multiplicity', not wrong_multiplicity, checked=len(answers), failures=wrong_multiplicity[:20]),
        _check('disk_exact_changes_only', not (unexplained or unrealized or extra_fields),
               unexplained=unexplained[:20], unrealized=unrealized[:20], extra_fields=extra_fields[:20]),
        _check('disk_no_answer_columns_in_raw', not any(
            field in row for rows in raw.values() for row in rows
            for field in ('baseline_value','injected_value','expected_action','anomaly_type'))),
    ]


def verify_extra_relationships(tables):
    checks=[]
    intervals=defaultdict(list)
    for stay in tables['pond_cohort_occupancy']:
        intervals[(stay['pond_id'],stay['cohort_id'])].append((stay['entered_at'],stay['left_at']))
    bad=[]
    for r in tables.get('growth_samples',[]):
        matching=intervals.get((r['pond_id'],r['cohort_id']),[])
        if not any(start <= r['sampled_at'] <= end for start,end in matching):bad.append(r['id'])
    checks.append(_check('disk_growth_within_cohort_stay',not bad,failures=bad[:20],checked=len(tables.get('growth_samples',[]))))
    persons={r['id'] for r in tables.get('persons',[])}
    person_fields=('recorder_id','reviewer_id','operator_id','sampler_id','advisor_id','verified_by','responsible_person_id','operation_person_id')
    bad=[]
    for name,rows in tables.items():
        for r in rows:
            for field in person_fields:
                if r.get(field) and r[field] not in persons:bad.append(f'{name}/{r["id"]}/{field}/{r[field]}')
    checks.append(_check('disk_person_references',not bad,failures=bad[:20]))
    plans={r['id'] for r in tables.get('production_plans',[])}
    bad=[r['id'] for r in tables['cohorts'] if r.get('technical_plan_id') and r['technical_plan_id'] not in plans]
    checks.append(_check('disk_cohort_plan_references',not bad,failures=bad))
    documents={r['id'] for r in tables.get('documents',[])}
    bad=[r['id'] for r in tables.get('production_plans',[]) if r.get('technical_document_id') and r['technical_document_id'] not in documents]
    checks.append(_check('disk_plan_document_references',not bad,failures=bad))
    money_fields={'amount_cny','amount_delta_cny','opening_value_cny','closing_value_cny',
                  'lot_opening_value_cny','lot_closing_value_cny','cost_cny','total_cost_cny',
                  'gross_revenue_cny','gross_sales_amount_cny','deductions_amount_cny',
                  'net_amount_cny','received_amount_cny','outstanding_amount_cny','gross_amount_cny'}
    bad=[]
    for name,rows in tables.items():
        if name not in business.TABLES:continue
        for r in rows:
            for field in money_fields:
                if r.get(field) is not None:
                    cents=Decimal(str(r[field]))*100
                    if cents!=cents.to_integral_value():bad.append(f'{name}/{r["id"]}/{field}')
    checks.append(_check('disk_money_cent_precision',not bad,failures=bad[:20]))
    provenance={(r['table'],r['record_id']):r for r in tables.get('record_provenance',[])}
    bad=[]
    for name,rows in tables.items():
        if name=='record_provenance':continue
        for row in rows:
            if row.get('is_synthetic') is False:
                sidecar=provenance.get((name,row['id']))
                if not sidecar or sidecar['is_synthetic'] is not False:
                    bad.append(f'{name}/{row["id"]}')
                elif name=='sources' and sidecar['reference_source_id']!=row['id']:
                    bad.append(f'{name}/{row["id"]}:wrong_reference_source')
    checks.append(_check('disk_external_provenance_identity',not bad,failures=bad[:20]))
    return checks


def verify_frozen_sources(out,tables):
    package_root=Path(__file__).resolve().parents[1]
    reference_root=out if (out/'public_sources/attachment/sample_manifest.json').is_file() else package_root
    manifest_path=reference_root/'public_sources/attachment/sample_manifest.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    bad=[]
    for entry in manifest['files']:
        path=reference_root/'public_sources/attachment/public_samples'/entry['relative_path']
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
            bad.append(entry['relative_path'])
    weather_meta=json.loads((reference_root/'public_sources/weather_download.json').read_text(encoding='utf-8'))
    weather_path=reference_root/'public_sources/era5_2025.json'
    if hashlib.sha256(weather_path.read_bytes()).hexdigest()!=weather_meta['sha256']:bad.append('era5_2025.json')
    return [_check('disk_frozen_public_source_hashes',not bad,checked=len(manifest['files'])+1,
                   reference_root=str(reference_root),failures=bad[:20])]


def economic_reconciliation(tables):
    def sum_money(rows,field):return sum((Decimal(str(r.get(field) or 0)) for r in rows),Decimal(0))
    gross=sum_money(tables['sales'],'gross_revenue_cny')
    deductions=sum_money(tables['settlement_deductions'],'amount_cny')
    costs=sum_money(tables['cost_entries'],'amount_cny')
    receipts=sum_money([r for r in tables['cash_transactions'] if r['direction']=='receipt'],'amount_cny')
    payments=sum_money([r for r in tables['cash_transactions'] if r['direction']=='payment'],'amount_cny')
    opening=sum_money([r for r in tables['opening_balances'] if r['balance_type']=='cash'],'amount_cny')
    closing={r['product_id']:r for r in tables['inventory_movements']}
    return {'currency':'CNY','gross_sales':str(gross),'settlement_deductions':str(deductions),
            'recognized_costs_excluding_settlement_deductions':str(costs),
            'scenario_operating_result':str(gross-deductions-costs),
            'scenario_result_scope':'synthetic management accounting, not statutory financial statements',
            'cash_receipts':str(receipts),'cash_payments':str(payments),
            'opening_cash':str(opening),'closing_cash':str(opening+receipts-payments),
            'closing_inventory_value':str(sum_money(closing.values(),'closing_value_cny')),
            'outstanding_receivables':str(sum_money(tables['settlements'],'outstanding_amount_cny'))}


def verify_mutations(tables):
    """Check the acceptance rules reject four independently broken business ledgers."""
    cases=[
        ('fish_count','fish_daily_balance','closing_count',1,'fish_count_conservation'),
        ('inventory_quantity','inventory_movements','closing_quantity',1,'inventory_conservation'),
        ('sales_allocation','harvest_sale_allocations','allocated_net_weight_kg',1,'harvest_sale_weight_conservation'),
        ('cash_receipt','cash_allocations','amount_cny',1,'cash_allocation_conservation'),
    ]
    results=[]
    # Copy the business subset, not immutable media and the large environment time series.
    subset={k: tables[k] for k in business.TABLES}
    for case,table,field,delta,expected in cases:
        damaged=copy.deepcopy(subset)
        target=next((r for r in damaged[table] if r.get('settlement_id')),damaged[table][0]) if case=='cash_receipt' else damaged[table][0]
        target[field]+=delta
        failed={r['check_id'] for r in business.validate_business(damaged) if not r['passed']}
        results.append(_check('negative_'+case,expected in failed,
                              mutation=f'{table}/{target["id"]}/{field}+{delta}',
                              expected_failure=expected,detected_failures=sorted(failed)))
    return results


def verify(out, skip_assets=False):
    out=Path(out).resolve()
    types=json.loads((out/'reports/serialization_types.json').read_text(encoding='utf-8'))
    cfg=json.loads((out/'scenario/config.json').read_text(encoding='utf-8'))
    tables=read_tables(out/'reference/baseline',types)
    raw=read_tables(out/'synthetic_raw',types,raw=True)
    checks=run.validate(tables,cfg)
    checks.extend(verify_extra_relationships(tables))
    checks.extend(verify_frozen_sources(out,tables))
    checks.extend(verify_answers(out,tables,raw,types))
    checks.extend(verify_mutations(tables))
    if not skip_assets:
        import assets
        checks.extend(assets.validate_assets(out,tables))
    else:
        checks.append(_check('asset_validation_skipped',False,reason='--skip-assets requested; incomplete acceptance'))
    summary={'verification_kind':'independent_serialized_readback',
             'regenerated_baseline':False,'mode':cfg['mode'],'seed':cfg['seed'],
             'loaded_tables':len(tables),'loaded_rows':sum(map(len,tables.values())),
             'economic_reconciliation':economic_reconciliation(tables),
             'checks_count':len(checks),'passed':all(r['passed'] for r in checks),
             'failed_checks':[r for r in checks if not r['passed']],
             'checks':checks}
    run.dump(out/'reports/independent_verification.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k!='checks'},ensure_ascii=False))
    return summary


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--skip-assets',action='store_true')
    args=p.parse_args()
    try:
        result=verify(args.out,args.skip_assets)
    except Exception as exc:
        print(f'Independent verification aborted: {type(exc).__name__}: {exc}',file=sys.stderr)
        raise
    raise SystemExit(0 if result['passed'] else 1)
