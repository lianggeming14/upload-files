# 武昌鱼知识库 L1 模拟数据 v1.0

此包为 **1个虚构场、6口塘、2025完整年度** 的可复现L1测试数据。塘口和经营主体均虚构。团头鲂、商品名武昌鱼、品系、产地、品牌/地理标志资格独立记录。天气是外部再分析；塘水、鱼群和业务均为模拟。

## 读取顺序

1. `reports/验收报告.md`：实际规模、验收结果、限制。
2. `schemas/coverage_matrix.csv`、`schemas/field_dictionary.csv`、`schemas/schema.json`：原子覆盖、字段含义、类型与约束。
3. `review/L1_review.xlsx`：审核视图；大表抽样范围和全量路径在索引内标明，CSV为权威交换文件。
4. `scenario/config.json`、`scenario/assumptions.json`：参数、随机种子、版本和规则依据。

## 目录隔离

- `synthetic_raw/`：交给L2的模拟原始输入，含已注入错误；`source_views/`为相同事件的源格式视图，按源记录ID去重，不可当新增业务量。
- `reference/baseline/`：未污染生成基准，仅用于验收。`record_provenance.csv`逐记录记录来源/运行/参数依据及通用字段。
- `reference/answers/`：异常答案，仅供验收；禁止并入L2训练输入。
- `public_sources/`：用户提供原件及新增ERA5下载、出处和哈希；独立于虚构本地观测。原件限本项目来源核对，未知开放再分发许可不因打包而获得。
- `assets/`：可打开GIS、媒体和文档格式测试样例，均有合成标记、哈希与对象关联。
- `sample/`：全量前运行的小样闭环和验证记录。
- `generator/`：生成、验证与测试代码。

## 复现

Python 3.11或更高，当前运行依赖版本见`requirements.txt`。

```powershell
python -m pip install -r requirements.txt
python generator/run.py --mode all
python generator/verify.py --out .
python -m unittest discover -s generator -p "test_*.py"
```

默认种子20251031，所有输入冻结在包中；复现无需重下载网络。先生成sample，验证通过后才生成full。不要把当前输出根目录设成任意既有数据目录；生成器将写入约定文件名。可用`--out ../reproduced --skip-review`在新目录重建CSV和资产；XLSX生成所需运行时和命令见`generator/catalog.py`。

XLSX及PDF等容器可能有运行元数据差异；核心CSV按种子确定，可使用报告中的哈希验证。媒体示意不适合训练或验证病害识别。未依据真实产品说明书施药，因此不提供真实处方或适用休药期。

公开引用以`public_sources/attachment/sample_manifest.json`和`public_sources/weather_download.json`为准。全年天气由[Open-Meteo历史接口](https://open-meteo.com/en/docs/historical-weather-api)提供，模型ERA5，数据CC BY 4.0；不是现场测站。
