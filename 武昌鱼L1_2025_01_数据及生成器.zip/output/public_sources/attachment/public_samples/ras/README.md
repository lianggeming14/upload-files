# Dataset RAS — Cómo cargar los archivos

Este depósito contiene un conjunto de datos de un Sistema de Acuicultura en Recirculación (RAS) instrumentado: series temporales automáticas, mediciones manuales de oxígeno disuelto, y una bitácora de eventos operativos.

## Archivos del dataset

- `ras_timeseries.csv` — 7,399 registros a 30 s de temperatura del agua, pH, conductividad y humedad ambiental.
- `ras_manual_measurements.csv` — 17 mediciones manuales de oxígeno disuelto con kit colorimétrico.
- `ras_incidents.csv` — 11 eventos operativos (calibraciones, dosificaciones, resets, etc.) con timestamps sincronizados.
- `data_dictionary.csv` — diccionario formal: define cada columna de los tres archivos anteriores, con tipo, unidades y rango esperado.

## Cargar en Python (pandas)

```python
import pandas as pd

ts      = pd.read_csv('ras_timeseries.csv',          parse_dates=['timestamp'])
manual  = pd.read_csv('ras_manual_measurements.csv', parse_dates=['timestamp'])
events  = pd.read_csv('ras_incidents.csv',           parse_dates=['timestamp'])
```

## Cargar en R

```r
ts     <- read.csv("ras_timeseries.csv")
manual <- read.csv("ras_manual_measurements.csv")
events <- read.csv("ras_incidents.csv")

ts$timestamp <- as.POSIXct(ts$timestamp, format = "%Y-%m-%dT%H:%M:%S", tz = "America/Mexico_City")
```

## Antes de analizar

Lee `RELEASE_NOTES.md` para conocer las particularidades metodológicas del dataset (en especial, cómo se midió el oxígeno disuelto y por qué aparece como `NaN` en la serie temporal automática). Consulta `data_dictionary.csv` para el significado preciso de cada columna.

## Licencia y cita

CC BY 4.0 (ver `LICENSE.txt`). Para citar este dataset, ver `CITATION.cff` o el bloque "Cite as" en la página del DOI.
